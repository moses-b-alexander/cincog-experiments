# C4 half-word receiver pilot

The host assigned BASELINE, SNOWDROP and STARFISH to the sender. Each model supplied nine native decisions, one per target under whole-word, retain-first-half and retain-last-half delivery. The ordered original 64-word bank and receiver settings are embedded in each record. The receiver saw the possible rules and its own clue. It chose through the native action distribution and the host used its reported argmax.

Each product has a registry, a provenance file with the exact local model digest and server version, and a complete Cincog study record containing the actual sent requests, raw received text, selected actions and scores. All five products are locally hosted Ollama System One decision checkpoints.

## Replay

Use Python 3.10+ and the framework wheel from the walkthrough's C4 reproduction kit. The required wheel SHA-256 is `09883a0a5e29a5e6ecf386ec0cf512e08783601368195c0009b0d208e02b344c`. Extract this ZIP, create a virtual environment, install the wheel with `python -m pip install --no-index --no-deps PATH_TO_WHEEL`, then run `python replay_all.py` in this directory. The script disables network connections and compares all trials against their archived responses. The local `studies/half_pilot.py` supplies the scheduled sender and reuses the registered C4 receiver workflow.

For an intentional new local run with the five listed checkpoints installed, run `python collect.py new-records`. Choose a fresh output directory. This contacts the local Ollama server.

The site's `pilot/render.py` reads the five completed record files with `python render.py records output` and regenerates the charts and numerical tables. The plotting script uses NumPy and Matplotlib.

"""Offline replay of every registered record; use the bundled 0.1.0 wheel."""
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
import json
import socket

def blocked(*args, **kwargs):
    raise RuntimeError("Replay is offline")

socket.socket.connect = blocked
socket.socket.connect_ex = blocked
socket.create_connection = blocked
from framework_lab.study import main

for name in ("Laya", "Kev", "D3", "Tev1", "Nimble"):
    path=Path(__file__).parent/"records"/(name+".json")
    with redirect_stdout(StringIO()) as output:
        main("half_pilot",["replay",str(path)])
    assert json.loads(output.getvalue())["replayed"]==3
    print(name,"replayed three target assignments")

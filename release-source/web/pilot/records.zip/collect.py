"""Run five registered Cincog bindings, preserving each independent record."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from framework_lab.ollama_decision import local_request
from framework_lab.study import main

MODELS = {
    "Laya": "laya:421m-english-bf16",
    "Kev": "kev:0.8b-q8_0",
    "D3": "d3:2b",
    "Tev1": "tev1:4b-q4_K_M",
    "Nimble": "nimble:9b-q4_K_M",
}

def get(path):
    reply = local_request(path)
    if reply["status"] != 200:
        raise RuntimeError(path)
    return json.loads(reply["response"])

def write(path, value):
    path.write_text(json.dumps(value,indent=2)+"\n", encoding="utf8")

def collect(out):
    out.mkdir(exist_ok=True,parents=True)
    tags={m["name"]:m for m in get("/api/tags")["models"]}
    version=get("/api/version")["version"]
    for name, tag in MODELS.items():
        entry={"workflow":"studies.half_pilot","version":"1",
               "parameters":{"arms":["whole","elide_second","elide_first"]},
               "provider":{"kind":"callable","factory":"scheduled_sender","seed":0},
               "agents":{"C":{"kind":"systemone","model":tag,"selection":"argmax","seed":61101}},
               "assignments":[{}, {}, {}]}
        registry=out/(name+"-registry.json")
        record=out/(name+".json")
        if record.exists():
            continue
        write(registry,{"version":1,"studies":{"half_pilot":entry}})
        meta={"product":name,"tag":tag,"digest":tags[tag]["digest"],"ollama_version":version,
              "start_utc":datetime.now(timezone.utc).isoformat()}
        print("Starting",name,flush=True)
        main("half_pilot",["run","--registry",str(registry),"--output",str(record)])
        meta["end_utc"]=datetime.now(timezone.utc).isoformat()
        write(out/(name+"-origin.json"),meta)
        main("half_pilot",["replay",str(record)])
        print("Replayed",name,flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("out",type=Path)
    collect(parser.parse_args().out)

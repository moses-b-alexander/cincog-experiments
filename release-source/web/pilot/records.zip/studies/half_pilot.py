"""Matched receiver cases on the original C4 menu; A follows the target schedule."""
import json
from studies.c4 import describe, measure, resolve, run

TARGETS = ("baseline", "snowdrop", "starfish")


def scheduled_sender(seed):
    word = TARGETS[seed]
    def choose(request):
        if request["role"] != "A":
            raise ValueError("Only A uses the fixed target schedule")
        return json.dumps({"action": "choose_word", "args": {"word": word}})
    return choose

"""Certify a bank-wide information upper bound using only integer arithmetic.

Let q(r|y) be the stored distribution over deleted-pair labels, and d(w,y)
the number of labels producing clue y for target w. Uniformity of the labels
implies H(R|W,Y) = E log2 d(W,Y). By nonnegativity of KL divergence,
H(R|Y) <= E[-log2 q(R|Y)]. Thus the bank's I(W;R|Y) is at most the
average of -log2(q(r|y)*d(w,y)) over its 48 slots. To upper-bound all
16-word banks, take the 16 largest per-word sums. With a common denominator
for q these are the words with the 16 smallest numerator products.
"""

import hashlib
import json
import math
import sys
from collections import defaultdict
from fractions import Fraction
from pathlib import Path


def clues(word):
    return word[2:], word[:2] + word[4:], word[:4]


def main():
    here = Path(__file__).resolve().parent
    lexicon = (Path(sys.argv[1]) if len(sys.argv) > 1
               else here.parent / "c4-viz-six" / "lexicon.txt")
    certificate = json.loads((here / "upper-bound.json").read_bytes())
    raw = lexicon.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == certificate["lexicon_sha256"]
    words = raw.decode("utf8").split()
    assert len(words) == len(set(words)) == certificate["word_count"] == 8255
    assert all(len(w) == 6 and w.isascii() and w.isalpha() and w.islower()
               for w in words)
    size = certificate["bank_size"]
    assert size == 16

    support = defaultdict(set)
    for word in words:
        for rule, clue in enumerate(clues(word)):
            support[clue].add(rule)

    den = certificate["denominator"]
    assert type(den) is int and den > 0
    multi = certificate["multirule_clue_numerators"]
    assert set(multi) == {y for y, rules in support.items() if len(rules) > 1}
    distributions = {}
    for clue, rules in support.items():
        numerators = multi.get(clue, [den if r in rules else 0 for r in range(3)])
        assert len(numerators) == 3 and sum(numerators) == den
        assert all(type(n) is int and n >= 0 for n in numerators)
        assert {r for r, n in enumerate(numerators) if n} == rules
        distributions[clue] = numerators

    products = []
    for word in words:
        outputs = clues(word)
        products.append(math.prod(distributions[y][r] * outputs.count(y)
                                  for r, y in enumerate(outputs)))
    smallest = math.prod(sorted(products)[:size])
    slots = size * 3
    bound = Fraction(certificate["certified_bound_bits"])
    assert bound == Fraction(201, 200)
    power = slots * bound
    assert den ** (slots * power.denominator) <= (
        2 ** power.numerator * smallest ** power.denominator)
    score = math.log2(den ** slots / smallest) / slots
    print(f"Certified min-rule and average disclosure gain <= {float(bound):.3f} bits")
    print(f"Certificate value {score:.10f} bits for {len(words):,} words")


if __name__ == "__main__":
    main()

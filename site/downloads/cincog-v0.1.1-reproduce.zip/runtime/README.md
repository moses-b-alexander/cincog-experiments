# Framework selection lab

For the 0.1 release, start with [registered studies](../../docs/registered-studies.md). The installable distribution here includes Candidate B, C2 and C4, and the historical comparison CLI.

Three runnable alternatives for authors of coordinated-task experiments. Each exports a public API for writing a new task outside the installed package. The common CLI is a convenience for comparing C4 and spatial C2. Each candidate owns its model-decision boundary and study execution. They share the public fixture data, football physics, and transport adapters. The implementation uses the Python standard library at runtime.

For a decision with a finite tool list, `cincog-lab score` runs a native System One participant or reads a local LLM's next-token probabilities. `cincog-lab show` ranks the saved choices by count or cumulative probability. See the [finite-choice guide](framework_lab/objects/AUTHOR.md#score-a-tool-list) and [example B decision](examples/elision-choice.json).

## Try it

From this directory, install with `python -m pip install .`. In a working directory of your choice:

```console
cincog-lab scripted C4 --output words.json
cincog-lab objects C2 --output football.json
cincog-lab recipes C4 --output recipe-words.json
```

A run uses a deterministic scripted responder by default. `--ollama qwen2.5:3b` chooses an already-installed model on the local Ollama service. `--config PATH` supplies baseline fixture values. For example, `{"horizon":6,"seed":7}` requests six C2 plays. To start with an assigned C4 calibration, use `{"assigned_word":"firewood"}`. The default C4 sender is free to choose. Output paths must be new. Each record carries the settings, binding, actual public requests, raw replies, admitted actions and outcomes. Live records also include the Ollama request and response bodies. These records contain private experiment data.

To run directly from this directory without installation use `python -m framework_lab objects C2`. To author another task, import one candidate and call your workflow in your own script. The baseline CLI recognizes the two comparison cases. The [four-arm external study](studies/four_arm_study.py) uses all three public APIs without registering a case with the CLI.

## Three authoring models

| | A · Scripted | B · Objects | C · Recipes |
|---|---|---|---|
| What the author writes | An ordinary Python function that hands complete legal commands to a recorder. | An ordinary Python workflow built from public views, action forms, decisions and optional effect callbacks. | A JSON sequence of steps plus a registry of named Python operations for domain behavior. |
| What is reusable | Provider invocation, exact command matching, bounded retry, decision IDs and evidence. | Those facilities plus reusable field/form descriptions, an optional host legality predicate, and a session method pairing a pending choice with its effect. | An interpreter for call, ask, conditional and collection steps, with lexical scopes and preflight checks. |
| Where errors surface | A malformed menu can fail when a decision is issued. Wrong scheduling or scoring needs an execution test. | Invalid fields/forms can fail on construction. Wire shape and an optional predicate are checked before the workflow receives a command. Calling `perform` twice with one ID fails before a second dispatch. | Bad operation names, call arity, binding and scope errors can fail before any participant call. Dynamic values, interpolated IDs, action catalogs and Python operation behavior are checked or exercised at run time. |
| How a custom effect works | The script changes its own state after admission. | `Session.perform(id, decision, effect)` calls the bound effect on an admitted command. The callback implements the actual transition. `ask` is available for decisions with no immediate effect. | A registered operation consumes the prior admitted result. The recipe explicitly sequences the operation. |
| What reaches the model | A finite enum of full legal JSON actions. | A union of action forms with field choices. Separate move forms per occupied source preserve the source/destination relationship. | A finite enum of full legal actions inside a closed JSON object schema. |
| Best fit demonstrated here | A Python author trying a new communication pattern with little ceremony. | Several workflows needing the same typed decisions, policies and application boundary. | Repeated interventions and analysis variations assembled from known domain operations. |

All three accept a legal wrong answer on its first attempt. Their job ends at a well-formed, permitted choice for the issued decision. The benchmark verifies the resulting effects and scores separately. For a caller-written workflow, the author controls the observation, public instruction, legal offerings, scheduling, hidden state, effects and objective. A public menu can leak hidden state as readily as prompt text. In B a private predicate can reject an advertised action, so its accept/retry signal can also disclose information. Mathematical JSON Schema integer equality admits `1.0` in places where the host accepts only a decoded integer. In this experiment use integer wire syntax for cell indices.

## Class and object relationships

### A · Scripted

```mermaid
classDiagram
    class StudyFunction {
        <<author function>>
    }
    class Recorder {
        choose(id, role, observation, objective, instruction, menu)
        finish(result)
    }
    class Provider {
        <<callable>>
        __call__(request)
    }
    StudyFunction --> Recorder : issues a decision
    Recorder --> Provider : checks and records reply
```

`Recorder.choose` returns a fresh action dictionary or a missing result. For the same C4 word bank the author can reuse one menu across sender and receiver. C2 computes a new menu from the visible offense, then the script updates the board and scores the plays. Read [the script author guide](framework_lab/scripted/AUTHOR.md) or [the two baseline scripts](framework_lab/scripted/cases.py).

### B · Objects

```mermaid
classDiagram
    class Workflow {
        <<author function>>
    }
    class Session {
        ask(id, decision)
        perform(id, decision, effect)
        trace(result)
    }
    class Decision {
        request()
        admit(raw)
    }
    class View
    class Form
    class Field
    class Command
    Workflow --> Session
    Workflow --> Decision : assembles
    Decision *-- View
    Decision *-- Form
    Form *-- Field
    Session --> Decision : requests and admits
    Decision ..> Command : yields on success
    Session ..> Command : passes to bound effect
```

A form can represent 64 words as one named field. For C2, grouping destinations by source prevents forming a move back to the same cell. A successfully parsed `Command` is immutable. The public constructors and callbacks are available to trusted author code. The ID guard is session-local; it does not supply authentication, database transactions or restart-safe effects. Read [the object author guide](framework_lab/objects/AUTHOR.md) and [the two workflows](framework_lab/objects/cases.py).

### C · Recipes

```mermaid
classDiagram
    class Recipe {
        _check(steps, scope)
        _execute(steps, frame, provider, trace, issued)
        run(config, provider)
    }
    class StepList {
        <<JSON data>>
    }
    class Registry {
        <<name to Python function>>
    }
    class Question {
        role
        observation
        objective
        instruction
        choices
    }
    class Provider {
        <<callable>>
    }
    Recipe o-- StepList
    Recipe o-- Registry
    Registry ..> Question : domain function builds
    Recipe --> Question : ask reads it
    Recipe --> Provider : issues and records
```

Compilation happens in the `Recipe` constructor. The compiler can establish that a referenced binding exists and an operation takes the declared number of arguments. Whether the right operation was chosen, which keys a runtime object contains, and whether a scorer implements the intended formula still require execution evidence. Read [the recipe guide](framework_lab/recipes/AUTHOR.md), the [word recipe](framework_lab/recipes/word.json), and the [board recipe](framework_lab/recipes/board.json).

## What distinguished the designs in use

* **A blank message is a delivery.** An independent researcher implemented the same fourth C4 arm in all three APIs. An empty string reached C, which still had to guess. Losing the preceding receiver to a simulated service failure left the later arms intact. A and B used the same Python loop. B's extra objects did not catch an additional error in this exercise. The original C recipe tested whether the fragment was truthy, which would have skipped the new arm. The shipped version tests whether the sender produced a word. [External study](studies/four_arm_study.py)
* **A score change and an incentive change produce different records.** Four forced moves yielded 30 gross yards. Three yard-equivalents per move rescored this trace to 18. A fresh cost-responsive scripted policy offered the announced price held, yielding 22 net. Both trajectories met the original four-play threshold. The recipe author replaced the question operation while reusing the play and score operations. The baseline QB saw prior yardages; announcing an objective does not itself deliver a net-payoff signal. This is a test policy, not a claim about model preferences. [Incentive study](studies/economic_checks.py)
* **The denominator lives above the decision loop.** Across 12 paired C2 seeds, a deliberately failing policy exhausted its second decision in two episodes. Comparing its ten completed episodes with all twelve controls suggested a gain of 0.625 yards. The ten complete paired differences were exactly zero. The first-two-play objective on the twelve saved control traces gave 8/12. All three expose enough data for this analysis when the caller knows the planned assignments. None of the three records a never-started assignment for an entire study. [Attrition study](studies/economic_checks.py)

## Reproduce the checks

Use the lab directory as the working directory. The final command uses the original published archive, retained in the enclosing repository.

```console
python -m unittest discover -v
python -m studies.four_arm_study
python -m studies.economic_checks
python replay_live.py evidence/local-smoke.zip
python qualify.py ../../examples/json_agents/evidence/records.zip
```

The archived baseline replay checks all 25 matched blocks per candidate, including 125 C4 and 125 C2 decisions. It reissues the actual role-visible observations and objective declarations, feeds in the recorded raw assistant content, and compares assigned choices, physical effects, history, deliveries and measurements. It supplies the original standard-normal shocks. New C2 runs use a different keyed shock generator. The historical prompts and schema encodings differ by design. The [live records](evidence/local-smoke.zip) are the actual requests and responses for two local models on the new interfaces. See [the qualification and committee record](../../docs/tasks/031-three-frameworks.md) for outcomes, limitations, and selection rationale.

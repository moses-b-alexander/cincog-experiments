"""Render local C4 progress from read-only receipts. --watch refreshes every 45 seconds."""
import argparse
from contextlib import closing
from datetime import datetime, timezone
from html import escape
import json
import math
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import time


CLUES = {"prefix": "fire", "suffix": "wood", "alternating": "frwo"}
INTERVAL = 45


class FinalizationBusy(Exception):
    """The receipt verifier encountered a transient file lock."""


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def atomic_text(path, text):
    with tempfile.NamedTemporaryFile("w", dir=path.parent, prefix=path.name+".", suffix=".tmp",
                                     encoding="utf-8", delete=False) as stream:
        tmp = Path(stream.name)
        stream.write(text)
    try:
        for attempt in range(5):
            try:
                os.replace(tmp, path)
                break
            except PermissionError:
                if attempt == 4:
                    raise
                time.sleep(.15 * (attempt+1))
    finally:
        tmp.unlink(missing_ok=True)


def assigned_clues(plan):
    indices = {a: [] for a in CLUES}
    for t,word in enumerate(plan["draws"],1):
        for (arm,clue),fragment in zip(CLUES.items(),(word[:4],word[-4:],word[::2])):
            if fragment == clue:
                indices[arm].append(t)
    return indices


def snapshot(path, indices, bank, draws):
    # Release the read transaction before JSON parsing or page rendering.
    with closing(sqlite3.connect(path.resolve().as_uri()+"?mode=ro", uri=True, timeout=1.5)) as db:
        db.execute("PRAGMA query_only=ON")
        db.execute("BEGIN")
        counts = dict(db.execute("SELECT arm, count(*) FROM trials GROUP BY arm"))
        if set(counts)-set(CLUES) or any(n>len(draws) for n in counts.values()):
            raise ValueError("receipt counts exceed the declared schedule")
        rows = []
        for arm, trials in indices.items():
            for start in range(0,len(trials),300):
                chunk = trials[start:start+300]
                slots = ",".join("?" for _ in chunk)
                sql = f"SELECT trial, arm, row FROM trials WHERE arm=? AND trial IN ({slots})"
                rows.extend(db.execute(sql,[arm,*chunk]).fetchall())
    samples = {a: 0 for a in CLUES}
    totals = {a: dict.fromkeys(bank,0.0) for a in CLUES}
    for trial,arm,raw in rows:
        row = json.loads(raw)
        p = row["probabilities"]
        if (row["trial"] != trial or row["arm"] != arm or row["clue"] != CLUES[arm]
                or row["target"] != draws[trial-1] or p.keys() != totals[arm].keys()
                or any(type(v) not in (int,float) or not 0 <= v <= 1 for v in p.values())
                or abs(math.fsum(p.values())-1)>1e-6):
            raise ValueError(f"inconsistent saved clue vector at trial {trial}, {arm}")
        samples[arm] += 1
        for w,v in p.items():
            totals[arm][w] += v
    tops = {a: sorted(((w,v/n) for w,v in totals[a].items()),key=lambda pair:-pair[1])[:3]
            for a,n in samples.items() if n}
    return dict(counts=counts,samples=samples,tops=tops,time=now())


def cell_table(headers,rows):
    header = "".join(f"<th scope=col>{escape(s)}</th>" for s in headers)
    body = "".join("<tr>"+"".join(f"<td>{s}</td>" for s in row)+"</tr>" for row in rows)
    return f"<div class=scroll><table><thead><tr>{header}</tr></thead><tbody>{body}</tbody></table></div>"


def render(root, plan, indices, snapshots, notes, state, reason=""):
    models, n = plan["models"], len(plan["draws"])
    counts, clue_rows = [], []
    total = sum(sum(s["counts"].values()) for s in snapshots.values())
    for i,model in enumerate(models):
        s = snapshots.get(i)
        counts.append([escape(model),*[f'{s["counts"].get(arm,0):,}' if s else "" for arm in CLUES],
                       f"{n:,}",escape(notes.get(i) or (s["time"] if s else ""))])
        displayed = []
        for arm in CLUES:
            if s is None or not s["samples"][arm]:
                displayed.append("")
                continue
            top = "<br>".join(f"{escape(w)} {v:.1%}" for w,v in s["tops"][arm])
            displayed.append(f'<strong>{s["samples"][arm]:,} / {len(indices[arm]):,} observed</strong><br>'+top)
        clue_rows.append([escape(model),*displayed])
    count_table = cell_table(["Model","Prefix completed","Suffix completed","Alternating completed",
                              "Assigned per arm","Receipt snapshot (UTC)"],counts)
    clue_table = cell_table(["Model",*[f"{clue} · {arm}" for arm,clue in CLUES.items()]],clue_rows)
    refresh = '<meta http-equiv="refresh" content="45">' if state not in ("Verified and complete","Validation failed") else ""
    link = '<a href="analysis/report.html">Open the verified final report</a>' if state=="Verified and complete" else ""
    grade = "Fixture · " if plan.get("synthetic") is True else ""
    details = f"<pre>{escape(reason)}</pre>" if reason else ""
    status = f"{grade}{state}"
    text = f"""<!doctype html><html lang=en><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">{refresh}
<title>C4 study progress</title><style>
*{{box-sizing:border-box}}body{{margin:2rem auto;max-width:80rem;padding:0 1.5rem;color:#20313b;background:#fbfcfa;font:1rem/1.5 system-ui,sans-serif}}
h1,h2{{line-height:1.2}}h1{{margin-bottom:.25rem}}h2{{margin-top:2rem;font-size:1.35rem}}p{{max-width:82ch}}.scroll{{overflow-x:auto}}
table{{border-collapse:collapse;width:100%;background:white}}td,th{{padding:.55rem .65rem;text-align:left;vertical-align:top;border-bottom:1px solid #cbd6d3}}th{{background:#e8efed}}
pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#f4e9e5;padding:1rem}}strong,a{{color:#164e5b}}progress{{width:min(35rem,100%);height:1.1rem}}small{{color:#425760}}
</style></head><body><h1>C4 study progress</h1><strong>{escape(status)}</strong> · <small>Page updated {now()}</small>
<p><b>{total:,} / {len(models)*3*n:,}</b> committed decisions in available snapshots</p><progress value="{total}" max="{len(models)*3*n}"></progress>
{details}<p>{link}</p><h2>Completed decisions by clue rule</h2>{count_table}
<h2>Observed probabilities for three fragments</h2><p>Each cell shows the three words with the highest mean reported probability across committed trials showing that fragment under its scheduled rule. The denominator is the number of planned draws with that clue. Blank cells have no available observations. Models may have completed different trials.</p>
{clue_table}<p><small>The page reloads every 45 seconds while the watcher is active. Final analysis begins once every model has exported its decisions and binding.</small></p></body></html>"""
    atomic_text(root/"live.html",text)


def final_ready(root, models):
    return all((root/"decisions"/f"{i}.jsonl").is_file() and (root/f"binding-{i}.json").is_file()
               for i in range(len(models)))


def finalize(root, python, status):
    for script,stage in [("verify_evidence.py","Verifying original receipts"),("analyze.py","Building the verified report")]:
        status(stage)
        proc = subprocess.run([python,str(Path(__file__).with_name(script).resolve()),"--input",str(root)],capture_output=True,
                              text=True,encoding="utf-8",errors="replace")
        if proc.returncode:
            output = (proc.stderr or proc.stdout)[-4000:]
            if any(s in output.lower() for s in ("database is locked","database table is locked","[winerror 32]")):
                raise FinalizationBusy(f"{script} encountered a file lock. The watcher will retry.")
            raise ValueError(f"{script} exited with status {proc.returncode}\n"+output)
        if script=="verify_evidence.py":
            atomic_text(root/"verified-evidence.json",proc.stdout)
    if not (root/"analysis"/"report.html").is_file():
        raise ValueError("analysis finished without its report")


def run(args):
    root = args.input.resolve()
    plan = json.loads((root/"manifest.json").read_bytes())
    indices = assigned_clues(plan)
    snapshots = {}
    while True:
        notes = {}
        def status(label,reason=""):
            render(root,plan,indices,snapshots,notes,label,reason)
        try:
            for i,model in enumerate(plan["models"]):
                db = root/f"receipts-{i}.sqlite"
                if not db.is_file():
                    continue
                try:
                    snapshots[i] = snapshot(db,indices,plan["word_bank"],plan["draws"])
                except sqlite3.OperationalError as exc:
                    if not any(msg in str(exc).lower() for msg in ("locked","busy","no such table","unable to open")):
                        raise
                    old = snapshots.get(i)
                    notes[i] = "Retrying · "+(old["time"] if old else "snapshot pending")
            marker = root/"live-final.json"
            if marker.is_file() and not args.watch:
                saved = json.loads(marker.read_bytes())
                status(saved["state"],saved.get("reason",""))
                return int(saved["state"]=="Validation failed")
            if args.watch and final_ready(root,plan["models"]):
                finalize(root,args.analysis_python,status)
                status("Verified and complete")
                atomic_text(marker,json.dumps({"state":"Verified and complete","updated":now()}))
                return 0
            status("Partial · awaiting final verification")
        except FinalizationBusy as exc:
            status("Partial · final verification pending",str(exc))
        except (OSError,ValueError,KeyError,TypeError,sqlite3.Error) as exc:
            status("Validation failed",str(exc))
            if args.watch:
                atomic_text(root/"live-final.json",json.dumps({"state":"Validation failed","reason":str(exc),"updated":now()}))
            return 1
        if not args.watch:
            return 0
        time.sleep(INTERVAL)


if __name__=="__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",required=True,type=Path)
    parser.add_argument("--watch",action="store_true")
    parser.add_argument("--analysis-python",default=sys.executable,help="Python installation with NumPy and Matplotlib")
    sys.exit(run(parser.parse_args()))

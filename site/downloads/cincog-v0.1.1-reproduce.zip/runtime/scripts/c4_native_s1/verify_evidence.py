"""Independently verify the C4 native decision sweep. Reads files only, using the standard library."""
import argparse
import base64
from collections import Counter
from contextlib import closing
import hashlib
from itertools import zip_longest
import json
import math
from pathlib import Path
import random
import re
import sqlite3
import sys


MODELS = ["kev:0.8b-q8_0", "d3:2b", "d3:4b-q8_0", "kev:4b-q8_0", "kev:9b-q4_K_M"]
ARMS = ["prefix", "suffix", "alternating"]
SEED = 20261123
N = 1000
BANK_DIGEST = "87c76f1cc99a45a4765ddb853f281c223215784d872275eace26d873649e1d88"
INSTRUCTION = (
    "An eight-letter word was selected from the word bank. Your clue contains either "
    "the whole word, its first four letters, its last four letters, or its letters at "
    "positions 1, 3, 5 and 7 in that order (counting from 1). Choose the original "
    "word from the bank. Recovery succeeds when your guess matches it exactly."
)
OBJECTIVE = {"metric": "exact_recovery", "direction": "maximize", "horizon": 1}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_object(items):
    obj = dict(items)
    require(len(obj) == len(items), "duplicate JSON key")
    return obj


def reject_constant(value):
    raise ValueError(f"invalid JSON number {value}")


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique_object, parse_constant=reject_constant)


def read(path):
    return parse(path.read_bytes())


def same(left, right):
    # Enforce JSON scalar types even when Python considers False and 0 equal.
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def validate_manifest(plan):
    bank = plan["word_bank"]
    require(isinstance(bank, list) and len(bank) == 64 and len(set(bank)) == 64, "invalid word bank")
    require(hashlib.sha256(" ".join(bank).encode("ascii")).hexdigest() == BANK_DIGEST,
            "word bank content or order differs from the C4 bank")
    expected = {
        "version": 1, "models": MODELS, "arms": ARMS, "seed": SEED,
        "draws": random.Random(SEED).choices(bank, k=N),
        "sampling": "uniform with replacement, shared across all cells",
        "selection": "one seeded categorical draw from each issued receipt", "arm_visible": False,
        "transport": "native local Ollama POST /v1/systemone", "cache_model_responses": False,
    }
    for key, value in expected.items():
        require(same(plan[key], value), f"manifest {key} disagrees with the design")
    form = {"type": "object", "required": ["action", "args"], "additionalProperties": False,
            "properties": {"action": {"const": "choose_word"},
                           "args": {"type": "object", "required": ["word"], "additionalProperties": False,
                                    "properties": {"word": {"type": "string", "enum": bank}}}}}
    template = {"role": "C", "observation": {"fragment": "CLUE"}, "objective": OBJECTIVE,
                "instruction": INSTRUCTION, "schema": {"anyOf": [form]}}
    require(same(plan["receiver"], template), "receiver manifest does not match its authorized view and form")


def verify_body(wire, model, clue, bank):
    expected = {"model": model, "state": {"role": "C", "observation": {"fragment": clue}, "objective": OBJECTIVE},
                "questions": {"decision": {"type": "choice", "instructions": INSTRUCTION,
                                           "criteria": dict.fromkeys(bank)}}}
    require(same(wire["body"], expected), "issued body differs from the authorized receiver input")
    require(list(wire["body"]["questions"]["decision"]["criteria"]) == bank, "issued menu order changed")


def probability(value):
    return type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1


def response_answer(raw, model, bank, context=None):
    envelope = parse(raw)
    require("error" not in envelope and envelope["model"] == model, "provider error or response model mismatch")
    require(set(envelope["answers"]) == {"decision"}, "unexpected response questions")
    if context is not None:
        usage = envelope["usage"]
        require(type(usage["input_tokens"]) is int and 0 < usage["input_tokens"] < context
                and type(usage["output_tokens"]) is int and usage["output_tokens"] == 0,
                "raw decision token usage is outside its verified context")
    answer = envelope["answers"]["decision"]
    require(answer["type"] == "choice", "response is not a choice")
    weights = answer["probabilities"]
    require(set(weights) == set(bank), "raw response does not contain the 64 bank words")
    require(all(probability(p) for p in weights.values()), "invalid raw probability")
    require(abs(math.fsum(weights.values()) - 1) <= 1e-6, "probabilities do not sum to one")
    require(weights[answer["choice"]] == max(weights.values()), "provider choice is not a maximum")
    require(probability(answer["confidence"]), "invalid provider confidence")
    return answer


def check_retry(wire, model, bank):
    require("invalid_response" in wire and "selected_option" not in wire, "unexplained retry")
    if "response_base64" in wire:
        data = base64.b64decode(wire["response_base64"], validate=True)
        try:
            data.decode("utf-8")
        except UnicodeDecodeError:
            return
        raise ValueError("retry labels valid UTF-8 as invalid")
    try:
        response_answer(wire["response"], model, bank)
    except (ValueError, KeyError, TypeError, AttributeError):
        return
    raise ValueError("retry followed a valid native response")


def check_wires(wires, model, clue, bank, seed, context=None):
    require(isinstance(wires, list) and 1 <= len(wires) <= 2, "wrong number of issued attempts")
    for idx, wire in enumerate(wires):
        verify_body(wire, model, clue, bank)
        require(wire.get("status") == 200 and "transport_error" not in wire, "wire transport failure")
        if idx < len(wires) - 1:
            check_retry(wire, model, bank)
    accepted = wires[-1]
    require("invalid_response" not in accepted and "response_base64" not in accepted,
            "accepted wire is marked invalid")
    answer = response_answer(accepted["response"], model, bank, context)
    weights = answer["probabilities"]
    selected = random.Random(seed).choices(bank, weights=[weights[w] for w in bank], k=1)[0]
    require(weights[selected] > 0, "selected a zero-mass outcome")
    copies = {"resolved_model": model, "reported_choice": answer["choice"], "selected_option": selected,
              "probabilities": weights, "confidence": answer["confidence"]}
    for key, value in copies.items():
        require(same(accepted[key], value), f"parsed wire {key} disagrees with the raw response or seed")
    return answer, selected


def verify_gpu(gpu, binding):
    require(gpu["name"] == binding["tag"] and gpu["digest"] == binding["digest"],
            "resident model name or digest differs from binding")
    require(type(gpu["size"]) is int and gpu["size"] > 0 and type(gpu["size_vram"]) is int
            and gpu["size_vram"] >= .99 * gpu["size"], "GPU snapshot below the run's 99% residency criterion")
    if "runtime_provenance" in binding:
        require(gpu["context_length"] == binding["runtime_provenance"]["runtime"]["parameters"]["num_ctx"],
                "GPU snapshot context differs from the authenticated runtime setting")


def verify_runtime(model, binding):
    """Authenticate the two manifests, all effective layers and the parameter payloads offline."""
    provenance = binding.get("runtime_provenance")
    if provenance is None:
        require(binding["tag"] == model, "alias requires source provenance")
        return binding["tag"], None
    source, runtime = provenance["source"], provenance["runtime"]
    require(source["tag"] == model and runtime["tag"] == binding["tag"] and runtime["tag"] != model
            and runtime["digest"] == binding["digest"], "canonical or runtime identity mismatch")
    # These source hashes identify the three published checkpoints qualified before alias creation.
    pinned = {"d3:4b-q8_0": "2c571f91caf64c47b6ca6bd3adc1daa07dbb84ead8e9489758498cc7e11e533d",
              "kev:4b-q8_0": "46203beabf65d133ff2291c5482f37c9ce210175d162b2d49fc3c5f2ae3a83f8",
              "kev:9b-q4_K_M": "96375189a97f7bafb378fa99e7afe4d95b356168f147b79eba04d31ecfd016ab"}
    if model in pinned:
        require(source["digest"] == pinned[model], "canonical digest differs from the qualified source")
    normalized = []
    weights = []
    for snap in (source, runtime):
        manifest_bytes = snap["manifest"].encode("utf8")
        require(hashlib.sha256(manifest_bytes).hexdigest() == snap["digest"], "manifest hash mismatch")
        package = parse(manifest_bytes)
        layers = package.pop("layers")
        manifest_parts = []
        weight_parts = []
        param_descriptors = []
        for layer in layers:
            media = layer["mediaType"]
            require(re.fullmatch(r"sha256:[0-9a-f]{64}", layer["digest"])
                    and type(layer["size"]) is int and layer["size"] >= 0, "invalid layer descriptor")
            if media == "application/vnd.ollama.image.params":
                param_descriptors.append(layer)
                ignored = {"from", "digest", "size"}
            else:
                ignored = {"from"}
                if media in {f"application/vnd.ollama.image.{kind}" for kind in ("model", "projector", "adapter")}:
                    weight_parts.append({k: layer[k] for k in ("mediaType", "digest", "size")})
            manifest_parts.append({k: v for k, v in layer.items() if k not in ignored})
        require(len(param_descriptors) == 1, "expected exactly one parameter layer")
        desc = param_descriptors[0]
        raw = snap["parameter_blob"].encode("utf8")
        require(len(raw) == desc["size"] and "sha256:" + hashlib.sha256(raw).hexdigest() == desc["digest"],
                "parameter layer size or SHA-256 mismatch")
        require(same(parse(raw), snap["parameters"]), "derived parameters disagree with raw layer")
        normalized.append((package, manifest_parts))
        weights.append(weight_parts)
    require(same(*normalized), "alias changed config, layer order or non-parameter content")
    require(any(x["mediaType"].endswith(".model") for x in weights[0]) and same(*weights)
            and same(weights[0], provenance["weight_layers"]), "weight-layer identity mismatch")
    settings = [dict(snap["parameters"]) for snap in (source, runtime)]
    for values in settings:
        for k in ("num_ctx", "num_batch"):
            values.pop(k, None)
    require(same(*settings), "alias changes settings beyond context or batch size")
    runtime_settings = runtime["parameters"]
    for k in {"num_ctx", "num_batch"} & runtime_settings.keys():
        require(type(runtime_settings[k]) is int and runtime_settings[k] > 0, "invalid alias sizing setting")
    return runtime["tag"], runtime_settings["num_ctx"]


def verify_model(root, plan, index):
    model, bank = plan["models"][index], plan["word_bank"]
    database = root / f"receipts-{index}.sqlite"
    binding = read(root / f"binding-{index}.json")
    require(re.fullmatch(r"(?:sha256:)?[0-9a-f]{64}", binding["digest"]), "missing SHA-256 model identity")
    runtime_tag, context = verify_runtime(model, binding)
    require("decision" in binding["capabilities"] and binding["size_bytes"] > 0 and binding["ollama_version"],
            "incomplete native model identity")
    progress = read(root / f"progress-{index}.json")
    require(progress["model"] == model and progress["complete"] == N * 3, "incomplete final progress receipt")
    verify_gpu(progress["gpu"], binding)
    probe_path = root / f"probe-{index}.json"
    probe_attempts = None
    if probe_path.exists():
        probe = read(probe_path)
        require(same(probe["binding"], binding), "pre-run and final binding differ")
        verify_gpu(probe["gpu"], binding)
        _, selected = check_wires(probe["wire"], runtime_tag, "fire", bank, SEED, context)
        require(probe["selected"] == selected, "probe selection differs from its raw response")
        probe_attempts = len(probe["wire"])

    counts = Counter()
    seen = set()
    retries = 0
    max_mass_error = 0.0
    export_digest = hashlib.sha256()
    export = root / "decisions" / f"{index}.jsonl"
    with closing(sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True)) as db, export.open("rb") as lines:
        db.execute("PRAGMA query_only = ON")
        require(db.execute("PRAGMA quick_check").fetchall() == [("ok",)], "database integrity check failed")
        settings = db.execute("SELECT binding FROM settings").fetchall()
        require(len(settings) == 1 and same(parse(settings[0][0]), binding), "SQLite binding mismatch")
        rows = db.execute("SELECT trial, arm, row, wire FROM trials ORDER BY trial, arm")
        for record, line in zip_longest(rows, lines):
            require(record is not None and line is not None, "SQLite and analysis export lengths differ")
            trial, arm, data, raw_wires = record
            try:
                require(type(trial) is int and 1 <= trial <= N and arm in ARMS, "unexpected trial/arm")
                require((trial, arm) not in seen, "duplicate scheduled decision")
                seen.add((trial, arm))
                target = plan["draws"][trial - 1]
                arm_index = ARMS.index(arm)
                clue = (target[:4], target[-4:], target[::2])[arm_index]
                seed = SEED + 10000 * index + 3 * trial + arm_index
                wires = parse(raw_wires)
                answer, selected = check_wires(wires, runtime_tag, clue, bank, seed, context)
                result = {"trial": trial, "arm": arm, "target": target, "clue": clue, "selection_seed": seed,
                          "selected": selected, "reported_choice": answer["choice"], "confidence": answer["confidence"],
                          "probabilities": answer["probabilities"], "attempts": len(wires)}
                require(same(parse(data), result), "SQLite analysis row differs from raw response or schedule")
                require(same(parse(line), result), "exported analysis row differs from raw response or schedule")
                export_digest.update(line)
                counts[arm] += 1
                retries += len(wires) - 1
                max_mass_error = max(max_mass_error, abs(1 - math.fsum(answer["probabilities"].values())))
            except (KeyError, TypeError, ValueError, AttributeError, IndexError) as exc:
                raise ValueError(f"{model}, trial {trial}, {arm}: {exc}") from exc
    require(counts == Counter({arm: N for arm in ARMS}), "each arm requires 1,000 distinct completed trials")
    return {"index": index, "model": model, "digest": binding["digest"], "ollama": binding["ollama_version"],
            **({"runtime_tag": runtime_tag, "source_digest": binding["runtime_provenance"]["source"]["digest"],
                "weight_layers": binding["runtime_provenance"]["weight_layers"],
                "runtime_parameters": binding["runtime_provenance"]["runtime"]["parameters"]} if context else {}),
            "trials_by_arm": dict(counts), "verified_vectors": len(seen),
            "issued_attempts_in_completed_trials": len(seen) + retries, "recorded_retries": retries,
            "probe_status": "qualified" if probe_attempts is not None else "missing",
            "probe_attempts": probe_attempts, "last_reported_gpu_fraction": progress["gpu"]["size_vram"] / progress["gpu"]["size"],
            "max_abs_mass_error": max_mass_error, "analysis_jsonl_sha256": export_digest.hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="directory containing manifest.json and receipts")
    parser.add_argument("--index", type=int, choices=range(len(MODELS)), help="verify one completed model (0 through 4)")
    args = parser.parse_args()
    root = args.input.resolve()
    manifest = (root / "manifest.json").read_bytes()
    plan = parse(manifest)
    validate_manifest(plan)
    indices = range(len(MODELS)) if args.index is None else [args.index]
    models = [verify_model(root, plan, i) for i in indices]
    require(len({m["digest"] for m in models}) == len(models), "model digests repeat across the panel")
    qualified = all(m["probe_status"] == "qualified" for m in models)
    print(json.dumps({"scope": "full sweep" if args.index is None else "one model",
                      "manifest_sha256": hashlib.sha256(manifest).hexdigest(), "models": models,
                      "total_verified_vectors": sum(m["verified_vectors"] for m in models),
                      "all_probes_qualified": qualified,
                      "coverage": "Counts cover saved attempts and probes; aborted calls before a committed row "
                                  "are outside this evidence. GPU records are snapshots."}, indent=2))
    return 0 if qualified else 2


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, TypeError, KeyError, AttributeError, IndexError, sqlite3.Error) as exc:
        sys.exit(f"Evidence verification failed: {exc}")

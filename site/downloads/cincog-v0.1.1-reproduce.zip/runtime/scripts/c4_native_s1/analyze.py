"""Analyze completed C4 finite-choice vectors. Run with --input STUDY_DIRECTORY.

Required: Python 3.10+, NumPy, Matplotlib. No model, service or browser is used.
Synthetic fixtures must set manifest.synthetic=true and be run with --synthetic.
"""

import argparse
from collections import Counter, defaultdict
from contextlib import closing
import csv
from decimal import Decimal
import hashlib
import html
import itertools
import json
import math
import os
import sqlite3
import tempfile
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "c4-mpl-cache"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np


ARMS = ("prefix", "suffix", "alternating")
COLORS = ("#0072B2", "#C34E00", "#00815D", "#96539A", "#745100", "#585858")
MARKERS = ("o", "s", "^", "D", "v", "X")
EPS = 1e-6
P_TOL = 1e-6
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.facecolor": "white"})


def fragments(word):
    return (word[:4], word[-4:], word[::2])


def reject_dupes(items):
    values = dict(items)
    if len(values) != len(items):
        raise ValueError("duplicate JSON property")
    return values


def read_source(path):
    return json.loads(path.read_bytes(), object_pairs_hook=reject_dupes)


def validate(root, synthetic):
    manifest_path = root / "manifest.json"
    manifest = read_source(manifest_path)
    if synthetic != (manifest.get("synthetic") is True):
        raise ValueError("Synthetic status must agree between manifest and --synthetic")
    bank, models, draws = (manifest[k] for k in ("word_bank", "models", "draws"))
    if (not isinstance(bank, list) or not bank or len(set(bank)) != len(bank)
            or any(not isinstance(w, str) or len(w) != 8 or not w.isalpha() for w in bank)):
        raise ValueError("Expected a nonempty ordered bank of unique eight-letter words")
    if (not isinstance(models, list) or not models or len(set(models)) != len(models)
            or not all(isinstance(m, str) and m for m in models)):
        raise ValueError("Expected a unique ordered list of model names")
    if not isinstance(draws, list) or not draws or any(w not in bank for w in draws):
        raise ValueError("Manifest draw list must contain bank words")
    if not synthetic and len(draws) != 1000:
        raise ValueError("Expected exactly 1,000 scheduled real target draws")
    indices = {w: i for i, w in enumerate(bank)}
    n = len(draws)
    probabilities = np.empty((len(models), 3, n, len(bank)))
    selected = np.full((len(models), 3, n), -1, dtype=int)
    sources = {"manifest.json": hashlib.sha256(manifest_path.read_bytes()).hexdigest()}
    max_sum_error = 0.0
    for m, model in enumerate(models):
        path = root / "decisions" / f"{m}.jsonl"
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for line, raw in enumerate(stream, 1):
                digest.update(raw)
                try:
                    record = json.loads(raw, object_pairs_hook=reject_dupes)
                    trial = record["trial"]
                    if type(trial) is not int or not 1 <= trial <= n:
                        raise ValueError("Invalid trial index")
                    t, a = trial - 1, ARMS.index(record["arm"])
                    if selected[m, a, t] != -1:
                        raise ValueError("Duplicate decision")
                    target = draws[t]
                    if target != record["target"] or fragments(target)[a] != record["clue"]:
                        raise ValueError("Wrong target or clue for this cell")
                    if "model" in record and record["model"] != model:
                        raise ValueError("Incorrect model attribution")
                    vector = record["probabilities"]
                    if vector.keys() != indices.keys():
                        raise ValueError("Vector must have exactly one entry for every bank word")
                    values = [vector[w] for w in bank]
                    if any(type(p) not in (int, float) or not 0 <= p <= 1 for p in values):
                        raise ValueError("Probability outside [0,1]")
                    total = math.fsum(values)
                    max_sum_error = max(max_sum_error, abs(total - 1))
                    if abs(total - 1) > P_TOL:
                        raise ValueError(f"Probability mass totals {total}")
                    index = indices[record["selected"]]
                    if values[index] == 0:
                        raise ValueError("Sampled word has zero reported probability")
                    if "reported_choice" in record and vector[record["reported_choice"]] < max(values):
                        raise ValueError("Reported winner is not a maximum-weight word")
                    probabilities[m, a, t] = np.asarray(values) / total
                    selected[m, a, t] = index
                except (KeyError, ValueError, TypeError, AttributeError) as e:
                    raise ValueError(f"{path.name} line {line}: {e}") from e
        sources[path.relative_to(root).as_posix()] = digest.hexdigest()
    missing = np.argwhere(selected < 0)
    if len(missing):
        m, a, t = missing[0]
        raise ValueError(f"{len(missing)} decisions missing, first {models[m]}, {ARMS[a]}, trial {t+1}")
    return bank, models, draws, probabilities, selected, sources, max_sum_error


def kl(p, q):
    """One result per matched row. A support mismatch gives positive infinity."""
    with np.errstate(divide="ignore", invalid="ignore"):
        contributions = np.where(p > 0, p * (np.log2(p) - np.log2(q)), 0)
    return np.maximum(0.0, contributions.sum(axis=-1))


def entropy(p):
    with np.errstate(divide="ignore", invalid="ignore"):
        return -np.where(p > 0, p * np.log2(p), 0).sum(axis=-1)


def pairwise(models, probs):
    rows = []
    for a, arm in enumerate(ARMS):
        for i, j in itertools.product(range(len(models)), repeat=2):
            p, q = probs[i, a], probs[j, a]
            raw = kl(p, q)
            mid = (p + q) / 2
            js = (kl(p, mid) + kl(q, mid)) / 2
            if np.max(js) > 1 + 1e-12:
                raise ValueError("Jensen–Shannon divergence exceeds one bit")
            width = p.shape[-1]
            smoothed = kl((1-EPS)*p + EPS/width, (1-EPS)*q + EPS/width)
            finite = np.isfinite(raw)
            rows.append(dict(arm=arm, source=models[i], reference=models[j], matched_trials=len(p),
                             mean_kl_bits=float(raw.mean()), infinite_kl_trials=int((~finite).sum()),
                             finite_only_mean_kl_bits=float(raw[finite].mean()) if finite.any() else "",
                             uniform_mixture_epsilon=EPS, smoothed_mean_kl_bits=float(smoothed.mean()),
                             mean_js_bits=float(np.minimum(1, js).mean())))
    return rows


def metrics(bank, models, draws, probs, selected):
    projected = np.array([fragments(w) for w in bank])
    targets = np.array([bank.index(w) for w in draws])
    summaries, groups = [], []
    for a, arm in enumerate(ARMS):
        clues = projected[targets, a]
        compatible = clues[:,None] == projected[:,a]
        any_rule = (clues[:,None,None] == projected[None,:,:]).any(axis=-1)
        counts = compatible.sum(axis=1)
        for m, model in enumerate(models):
            p, choices = probs[m,a], selected[m,a]
            t = np.arange(len(draws))
            stats = dict(entropy_bits=entropy(p), rule_compatible_mass=(p*compatible).sum(axis=1),
                         any_rule_compatible_mass=(p*any_rule).sum(axis=1),
                         target_mass=p[t,targets], selected_exact=(choices == targets),
                         selected_rule_compatible=compatible[t,choices])
            summaries.append(dict(model=model, arm=arm, trials=len(t),
                                  distinct_clues=len(set(clues)), **{k: v.mean() for k,v in stats.items()}))
            for k in np.unique(counts):
                mask = counts == k
                groups.append(dict(model=model, arm=arm, compatible_words=int(k), trials=int(mask.sum()),
                                   distinct_clues=len(set(clues[mask])),
                                   **{name: v[mask].mean() for name,v in stats.items()}))
    return projected, targets, summaries, groups


def content_hash(obj):
    canonical = json.dumps(obj,sort_keys=True,separators=(",",":"),allow_nan=False)
    return hashlib.sha256(canonical.encode()).hexdigest()


def repeat_inputs(root, plan, m):
    """Read the accepted native reply and the corresponding model-facing request."""
    dbpath = root/f"receipts-{m}.sqlite"
    model = plan["models"][m]
    runtime = model
    binding_path = root/f"binding-{m}.json"
    binding = read_source(binding_path) if binding_path.is_file() else None
    if binding is not None:
        if "runtime_provenance" in binding:
            if __package__:
                from .verify_evidence import verify_runtime
            else:
                from verify_evidence import verify_runtime
            runtime, _ = verify_runtime(model,binding)
        elif binding["tag"] != model:
            raise ValueError("Repeatability binding model mismatch")
    if dbpath.is_file():
        with closing(sqlite3.connect(dbpath.resolve().as_uri()+"?mode=ro",uri=True)) as db:
            db.execute("PRAGMA query_only=ON")
            if binding is not None:
                settings = db.execute("SELECT binding FROM settings").fetchall()
                if len(settings) != 1 or json.loads(settings[0][0],object_pairs_hook=reject_dupes) != binding:
                    raise ValueError("Repeatability SQLite and exported model bindings differ")
            for trial,arm,wires in db.execute("SELECT trial,arm,wire FROM trials"):
                wire = json.loads(wires,object_pairs_hook=reject_dupes)[-1]
                body = wire["body"]
                order = list(body["questions"]["decision"]["criteria"])
                clue = body["state"]["observation"]["fragment"]
                native = json.loads(wire["response"],parse_float=Decimal,object_pairs_hook=reject_dupes)
                if body["model"] != runtime or native["model"] != body["model"]:
                    raise ValueError("Repeatability receipt model mismatch")
                yield trial,arm,clue,body,order,native["answers"]["decision"]["probabilities"]
        return
    # Portable exports lack per-call wire bodies. Use the declared public design.
    with (root/"decisions"/f"{m}.jsonl").open("rb") as stream:
        for line in stream:
            row = json.loads(line,parse_float=Decimal,object_pairs_hook=reject_dupes)
            clue,arm = row["clue"],row["arm"]
            body = {"model":runtime,"fragment":clue,"template":plan.get("receiver")}
            if plan.get("arm_visible") is not False:
                body["arm"] = arm
            yield row["trial"],arm,clue,body,row.get("menu_order",plan["word_bank"]),row["probabilities"]


def repeatability(root, plan):
    group_rows, model_rows = [], []
    bank,draws = plan["word_bank"],plan["draws"]
    vocabulary = set(bank)
    for m,model in enumerate(plan["models"]):
        counters, arms, seen = defaultdict(Counter),defaultdict(Counter),set()
        for trial,arm,clue,body,order,weights in repeat_inputs(root,plan,m):
            if (type(trial) is not int or not 1 <= trial <= len(draws) or (trial,arm) in seen
                    or clue != fragments(draws[trial-1])[ARMS.index(arm)] or len(order) != len(bank)
                    or set(order) != vocabulary or set(weights) != vocabulary):
                raise ValueError(f"Inconsistent repeatability input for {model}, trial {trial}, {arm}")
            seen.add((trial,arm))
            # Sorting JSON properties ignores recorder metadata order. The explicit menu
            # list retains order wherever it affects the actual options seen by the model.
            key = (clue,content_hash([body,order]),content_hash(order))
            vector = tuple(weights[word] for word in bank)
            if any(type(v) not in (int,Decimal) or not 0 <= v <= 1 for v in vector):
                raise ValueError("Invalid exact-decimal probability")
            counters[key][vector] += 1
            arms[key][arm] += 1
        if len(seen) != 3*len(draws):
            raise ValueError(f"Incomplete repeatability observations for {model}")
        source = "accepted native receipts" if (root/f"receipts-{m}.sqlite").is_file() else "declared design and decision exports"
        per_model = []
        for key,counts in sorted(counters.items()):
            n = sum(counts.values())
            multiplicities = list(counts.values())
            matrix = np.asarray(list(counts),dtype=float)
            totals = np.array([math.fsum(v) for v in matrix])
            if np.max(np.abs(totals-1)) > P_TOL:
                raise ValueError("Repeatability vector mass differs from one beyond tolerance")
            matrix /= totals[:,None]
            # Center at an observed vector first. Exact repeats then yield exact zero TV.
            delta = matrix-matrix[0]
            center = np.average(delta,axis=0,weights=multiplicities)
            tv = .5*np.abs(delta-center).sum(axis=1)
            pairs = math.comb(n,2)
            equal = sum(math.comb(k,2) for k in multiplicities)
            row = dict(model=model,clue=key[0],public_request_sha256=key[1],menu_order_sha256=key[2],
                       source=source,calls=n,prefix_calls=arms[key]["prefix"],suffix_calls=arms[key]["suffix"],
                       alternating_calls=arms[key]["alternating"],distinct_exact_vectors=len(counts),
                       identical_pairs=equal,all_pairs=pairs,fraction_identical_pairs=equal/pairs if pairs else "",
                       mean_tv_to_group_mean=float(np.average(tv,weights=multiplicities)) if n>1 else "",
                       max_tv_to_group_mean=float(tv.max()) if n>1 else "")
            group_rows.append(row)
            if n>1:
                per_model.append(row)
        ncalls = sum(r["calls"] for r in per_model)
        npairs = sum(r["all_pairs"] for r in per_model)
        equal = sum(r["identical_pairs"] for r in per_model)
        model_rows.append(dict(model=model,source=source,all_input_groups=len(counters),repeated_input_groups=len(per_model),
                               invariant_repeated_groups=sum(r["distinct_exact_vectors"]==1 for r in per_model),
                               repeated_group_calls=ncalls,identical_pairs=equal,all_pairs=npairs,
                               fraction_identical_pairs=equal/npairs if npairs else "",
                               mean_tv_to_group_mean=sum(r["calls"]*r["mean_tv_to_group_mean"] for r in per_model)/ncalls if ncalls else "",
                               max_tv_to_group_mean=max((r["max_tv_to_group_mean"] for r in per_model),default="")))
    return model_rows,group_rows


def save_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)


def stamp(fig, synthetic, caption):
    fig.text(.025,.016, ("SYNTHETIC FIXTURE   |   " if synthetic else "") + caption,
             fontsize=8, color="#434B50", va="bottom")


def legend(fig, models):
    handles = [Line2D([0],[0],marker=MARKERS[i%len(MARKERS)],color=COLORS[i%len(COLORS)],
                      linestyle="none",markersize=6,label=name) for i,name in enumerate(models)]
    fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(.025,.927), frameon=False,
               ncol=min(len(models),3), handletextpad=.25, columnspacing=1.3, fontsize=9)


def overlay_specs(bank, draws, projected, targets):
    specs = []
    for fixed in (True, False):
        panels = []
        for a, fragment in enumerate(fragments("firewood")):
            mask = targets == bank.index("firewood") if fixed and "firewood" in bank else (
                np.zeros(len(draws), dtype=bool) if fixed else projected[targets,a] == fragment)
            if mask.any():
                panels.append((a, fragment, mask))
        if panels:
            specs.append(("firewood_fixed" if fixed else "firewood_fragments",
                          "When the hidden target was firewood" if fixed else "Every trial showing a firewood fragment", panels))
    panels = []
    for a in range(3):
        clues = projected[targets,a]
        families = [(int((clues == c).sum()),c) for c in set(clues)
                    if c != fragments("firewood")[a] and (projected[:,a] == c).sum() > 1]
        if families:
            _, c = sorted(families,key=lambda x:(-x[0],x[1]))[0]
            panels.append((a,c,clues == c))
    if panels:
        specs.append(("other_families","Other clues with several compatible words",panels))
    return specs


def rank_curves(out, models, panels, synthetic):
    title = "How many words carry the probability?"
    fig, axes = plt.subplots(1, len(panels), sharex=True, sharey=True, squeeze=False,
                             figsize=(max(7, 4.3 * len(panels)), 5.15))
    rows = []
    for ax, (a, clue, n, means, _) in zip(axes[0], panels):
        for m, model in enumerate(models):
            strongest_first = np.sort(means[m])[::-1]
            mass = np.r_[0., strongest_first.cumsum()]
            k = np.arange(len(mass))
            ax.step(k, mass, where="post", color=COLORS[m % len(COLORS)], lw=1.7)
            ticks = [t for t in (1, 4, 8, 16, 32, 64) if t < len(k)]
            ax.scatter(ticks, mass[ticks], s=13, color=COLORS[m % len(COLORS)],
                       marker=MARKERS[m % len(MARKERS)])
            rows.extend(dict(arm=ARMS[a], clue=clue, model=model, trials_per_model=n,
                             top_words=int(rank), cumulative_mass=float(cum)) for rank, cum in zip(k, mass))
        ax.set(title=f"{clue} · {ARMS[a]}\n{n} matched trials per model",
               xlabel="Highest-probability words included", xlim=(0, len(means[0])), ylim=(0, 1.02))
        ax.set_xticks([t for t in (0, 8, 16, 32, 48, 64) if t <= len(means[0])])
        ax.grid(color=".89", lw=.6)
    axes[0, 0].set_ylabel("Cumulative probability mass")
    fig.suptitle(title, x=.025, y=.99, ha="left", fontweight="bold", fontsize=16)
    legend(fig, models)
    stamp(fig, synthetic, "Each model orders its own mean probabilities from largest to smallest. At k words, the curve gives their combined mass.")
    fig.tight_layout(rect=(.01, .095, 1., .75))
    name = "fragment_rank_curves.png"
    fig.savefig(out / name, dpi=150)
    plt.close(fig)
    save_csv(out / "fragment_rank_curves.csv", rows)
    return name, title


def overlays(out, bank, models, probs, selected, projected, specs, synthetic):
    rows, figures = [], []
    for slug, title, panels in specs:
        panel_info = []
        for a, clue, mask in panels:
            means = probs[:,a,mask,:].mean(axis=1)
            shares = np.array([np.bincount(s[a,mask],minlength=len(bank))/mask.sum() for s in selected])
            compatible = projected[:,a] == clue
            for m, model in enumerate(models):
                for w,word in enumerate(bank):
                    rows.append(dict(view=slug, arm=ARMS[a], clue=clue, model=model, word=word,
                                     trials_per_model=int(mask.sum()), rule_compatible=bool(compatible[w]),
                                     mean_reported_weight=means[m,w], sampled_share=shares[m,w]))
            panel_info.append((a,clue,int(mask.sum()),means,compatible))
        # Keep all structurally compatible words when feasible, then the strongest alternatives.
        compat = np.logical_or.reduce([p[4] for p in panel_info])
        strongest = np.max([p[3].max(axis=0) for p in panel_info],axis=0)
        rank = sorted(range(len(bank)),key=lambda w:(not compat[w],-strongest[w],w))
        limit = min(len(bank), max(10, min(16,int(compat.sum())+4)))
        keep = rank[:limit]
        labels = [bank[w] for w in keep]
        rest = sorted(set(range(len(bank))) - set(keep))
        if rest:
            labels.append(f"Other ({len(rest)} words)")
        fig, axes = plt.subplots(1,len(panels),sharex=True,sharey=True,squeeze=False,
                                 figsize=(max(8,4.9*len(panels)),max(6.3,.33*len(labels)+3)))
        for ax,(a,clue,n,means,compatible) in zip(axes[0],panel_info):
            y = np.arange(len(labels))
            for ix,w in enumerate(keep):
                if compatible[w]:
                    ax.axhspan(ix-.45,ix+.45,color="#E8F1EC",zorder=0)
            for m,model in enumerate(models):
                v = list(means[m,keep])
                if rest:
                    v.append(means[m,rest].sum())
                offset = (m-(len(models)-1)/2)*min(.12,.60/len(models))
                ax.scatter(v,y+offset,marker=MARKERS[m%len(MARKERS)],color=COLORS[m%len(COLORS)],
                           s=32,linewidth=.4,edgecolors="white",zorder=3)
            ax.set(yticks=y,yticklabels=labels,xlim=(-.025,1.035),xticks=[0,.25,.5,.75,1],
                   xlabel="Mean probability mass",title=f"{clue}  ·  {ARMS[a]}\n{n:,} matched trials per model")
            ax.grid(axis="x",color=".87",linewidth=.7)
            ax.tick_params(axis="y",length=0)
        axes[0,0].invert_yaxis()
        fig.suptitle(title,x=.025,y=.985,ha="left",fontweight="bold",fontsize=17)
        legend(fig,models)
        stamp(fig,synthetic,"Green rows match the panel’s clue rule. Other combines the remaining bank words. Full distributions are in the CSV.")
        fig.tight_layout(rect=(.015,.065,.995,.81))
        name = slug + ".png"
        fig.savefig(out/name,dpi=150)
        plt.close(fig)
        figures.append((name,title))
        if slug == "firewood_fragments":
            figures.append(rank_curves(out, models, panel_info, synthetic))
    if rows:
        save_csv(out/"clue_distributions.csv",rows)
    return figures


def heatmaps(out, models, pairs, synthetic):
    figures = []
    labels = [str(i+1) for i in range(len(models))]
    for key, name, title in [
        ("mean_kl_bits","directional_kl","How much do two models' distributions differ?"),
        ("smoothed_mean_kl_bits","smoothed_kl","Directional KL after uniform smoothing"),
        ("mean_js_bits","jensen_shannon","Bounded disagreement between models"),
    ]:
        vals = np.array([r[key] for r in pairs]).reshape(3,len(models),len(models))
        finite = vals[np.isfinite(vals)]
        vmax = 1 if key == "mean_js_bits" else max(.001, np.max(finite))
        cmap = plt.get_cmap("Blues").copy()
        cmap.set_bad("#E4D6E6")
        fig, axes = plt.subplots(1,3,figsize=(14,5.7))
        for a,ax in enumerate(axes):
            v = vals[a]
            img = ax.imshow(np.ma.masked_invalid(v),cmap=cmap,vmin=0,vmax=vmax)
            ax.set(xticks=range(len(models)),xticklabels=labels,yticks=range(len(models)),
                   yticklabels=labels,title=ARMS[a].capitalize(),xlabel="Reference model")
            if a == 0:
                ax.set_ylabel("Source model")
            for i,j in np.ndindex(v.shape):
                z = v[i,j]
                txt = "∞" if np.isinf(z) else ("0" if z == 0 else (f"{z:.2g}" if z < .01 else f"{z:.2f}"))
                ax.text(j,i,txt,va="center",ha="center",fontsize=10,
                        color="white" if np.isfinite(z) and z/vmax > .55 else "#142833")
        fig.subplots_adjust(left=.058,right=.92,bottom=.18,top=.73,wspace=.26)
        cb = fig.colorbar(img,cax=fig.add_axes([.94,.26,.012,.40]))
        cb.set_label("Mean bits")
        fig.suptitle(title,x=.025,y=.976,ha="left",fontweight="bold",fontsize=17)
        modelnames = [f"{i+1}  {m}" for i,m in enumerate(models)]
        fig.text(.025,.885,"      ".join(modelnames[:3]),fontsize=10)
        fig.text(.025,.837,"      ".join(modelnames[3:]),fontsize=10)
        caption = {"mean_kl_bits":"KL(source ∥ reference), in bits. ∞ means at least one matched trial assigned positive mass where the reference assigned zero.",
                   "smoothed_mean_kl_bits":"Sensitivity analysis only. Each reported vector is mixed with one part per million of the uniform bank distribution before KL.",
                   "mean_js_bits":"Equal-weight Jensen–Shannon divergence lies between 0 and 1 bit. Symmetric cells compare the same pair."}[key]
        stamp(fig,synthetic,caption)
        fig.savefig(out/(name+".png"),dpi=145)
        plt.close(fig)
        figures.append((name+".png",title))
    return figures


def ambiguity_figure(out, models, bank, groups, synthetic):
    fig, axes = plt.subplots(2,3,figsize=(14.0,8.0),sharey="row")
    for a, arm in enumerate(ARMS):
        subset = [r for r in groups if r["arm"] == arm]
        sizes = sorted({r["compatible_words"] for r in subset})
        counts = {r["compatible_words"]:r["trials"] for r in subset}
        for m, model in enumerate(models):
            cells = [r for r in subset if r["model"] == model]
            off = (m-(len(models)-1)/2)*min(.14,.65/len(models))
            x = np.arange(len(cells)) + off
            for row,key in enumerate(("entropy_bits","rule_compatible_mass")):
                axes[row,a].scatter(x,[r[key] for r in cells],color=COLORS[m%len(COLORS)],
                                    marker=MARKERS[m%len(MARKERS)],s=44,zorder=3)
        for row,ax in enumerate(axes[:,a]):
            ax.set_xlim(-.55,len(sizes)-.45)
            ax.set_xticks(range(len(sizes)),[f"{k}\n({counts[k]})" for k in sizes] if row else [""]*len(sizes))
            ax.grid(axis="y",color=".87")
            ax.set_ylim((-.03,1.04) if row else (-.08,max(.5,math.log2(len(bank))*1.035)))
        axes[0,a].set_title(arm.capitalize(),fontsize=13,fontweight="bold")
        axes[1,a].set_xlabel("Compatible bank words\n(trials per model)")
    axes[0,0].set_ylabel("Mean entropy (bits)")
    axes[1,0].set_ylabel("Mean mass on compatible words")
    fig.suptitle("Uncertainty and clue compatibility",x=.025,y=.983,ha="left",fontweight="bold",fontsize=17)
    legend(fig,models)
    stamp(fig,synthetic,"Compatibility uses the scheduled clue rule. A four-letter clue can identify one or several eight-letter words, depending on the bank.")
    fig.tight_layout(rect=(.015,.073,.995,.82))
    fig.savefig(out/"ambiguity.png",dpi=150)
    plt.close(fig)
    return "ambiguity.png","Uncertainty and clue compatibility"


def table(headers, rows):
    def escaped(x):
        return html.escape(str(x))
    labels = "".join(f"<th scope=col>{escaped(h)}</th>" for h in headers)
    body = "".join("<tr>"+"".join(f"<td>{escaped(c)}</td>" for c in row)+"</tr>" for row in rows)
    return f"<div class=scroll><table><thead><tr>{labels}</tr></thead><tbody>{body}</tbody></table></div>"


def fmt_bits(v):
    if math.isinf(v):
        return "∞"
    if v == 0:
        return "0"
    return f"{v:.3g}"


def esc(text):
    return html.escape(str(text))


def target_explorer(out, bank, models, draws, probabilities, synthetic):
    draw_words = np.asarray(draws)
    cells = []
    for word in bank:
        mask = draw_words == word
        n = int(mask.sum())
        # A fragment can occur under several hidden targets. Select the target before averaging.
        means = probabilities[:,:,mask,:].mean(axis=2).transpose(1,0,2).tolist() if n else None
        cells.append({"n":n,"fragments":fragments(word),"means":means})
    data = dict(bank=bank,models=models,arms=ARMS,colors=COLORS,cells=cells,synthetic=synthetic)
    document = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>C4 target word explorer</title><style>
*{box-sizing:border-box}body{max-width:76rem;margin:0 auto;padding:2rem clamp(1rem,4vw,3rem);font:1rem/1.5 system-ui,sans-serif;color:#23363f;background:#fbfcfa}h1,h2{line-height:1.15;color:#183644}h1{margin:.8rem 0;font-size:clamp(2rem,4vw,3rem)}h2{margin:2rem 0 .7rem;font-size:1.35rem}a{color:#005b86}p{max-width:84ch}.controls,.legend{display:flex;gap:1rem 1.5rem;flex-wrap:wrap;align-items:flex-end}.controls label{font-weight:650}select{font:inherit;color:inherit;background:white;padding:.35rem 2rem .35rem .55rem;margin-top:.25rem;display:block;border:1px solid #72868c;border-radius:.25rem}.legend{gap:.4rem 1.2rem;margin:1rem 0;font-size:.94rem}.legend span{display:inline-flex;align-items:center;gap:.32rem}.legend svg{width:16px;height:16px}.check{display:inline-flex;gap:.4rem;align-items:center}.plot{width:100%;background:white;display:block}.scroll{max-width:100%;overflow:auto}table{width:100%;border-collapse:collapse;font-size:.93rem;font-variant-numeric:tabular-nums;background:white}th,td{padding:.45rem .6rem;text-align:right;white-space:nowrap;border-bottom:1px solid #d8e0df}th:first-child{text-align:left}thead th{background:#e8efed}td{font-family:ui-monospace,monospace}caption{text-align:left;padding:0 0 .5rem}#fixture{color:#824e02}.hint{font-size:.9rem;color:#435961}.status{min-height:1.5rem}.plot text{font-family:system-ui,sans-serif;fill:#263c46}.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}
[hidden]{display:none!important}
</style></head><body><a href="report.html">Back to the study report</a><p id="fixture" hidden>Synthetic fixture · software check only</p>
<h1>Target word explorer</h1><p>Choose a hidden target and clue rule to see the probability each model assigned to every candidate word.</p>
<noscript>This offline explorer requires JavaScript to update the plot and table.</noscript>
<div class="controls"><label for="target-word">Hidden target<select id="target-word"></select></label>
<label for="clue-arm">Clue rule<select id="clue-arm"></select></label></div>
<p class="status" id="denominator" role="status" aria-live="polite"></p>
<section id="results"><h2>Mean reported probability</h2><div id="legend" class="legend"></div>
<label class="check" id="all-control"><input type="checkbox" id="all-candidates">Show every candidate in the plot</label>
<p id="plot-note" class="hint"></p><svg id="plot" class="plot" role="img" aria-labelledby="plot-title plot-desc"></svg>
<h2>Full values table</h2><div class="scroll"><table><caption id="table-caption"></caption><thead id="head"></thead><tbody id="values"></tbody></table></div></section>
<script type="application/json" id="study">_C4_DATA_</script><script>
"use strict";
const study = JSON.parse(document.getElementById("study").textContent);
const byId = id => document.getElementById(id);
const target = byId("target-word"), arm = byId("clue-arm"), plot = byId("plot");
const svgns = "http://www.w3.org/2000/svg";
function svg(tag, attrs, value) {
  const node = document.createElementNS(svgns, tag);
  Object.entries(attrs).forEach(([k,v]) => node.setAttribute(k,v));
  if (value !== undefined) node.textContent=value;
  return node;
}
function marker(i,x,y) {
  const color=study.colors[i%study.colors.length];
  const shapes=[
    ["circle",{cx:x,cy:y,r:3.5}],
    ["rect",{x:x-3.3,y:y-3.3,width:6.6,height:6.6}],
    ["path",{d:"M "+x+" "+(y-4.2)+" l 4 7.3 h -8 z"}],
    ["path",{d:"M "+x+" "+(y-4.3)+" l 4.1 4.3 -4.1 4.3 -4.1 -4.3 z"}],
    ["path",{d:"M "+x+" "+(y+4.2)+" l 4 -7.3 h -8 z"}],
    ["path",{d:"M "+(x-4)+" "+y+" h 8 M "+x+" "+(y-4)+" v 8",stroke:color,"stroke-width":2}]
  ];
  const [tag,attrs]=shapes[i%shapes.length];
  return svg(tag,{...attrs,fill:color});
}
function options(select,items) {
  items.forEach((value,i) => {
    const opt=document.createElement("option"); opt.value=String(i); opt.textContent=value;
    select.append(opt);
  });
}
function tableCell(tr,tag,text,scope) {
  const item=document.createElement(tag); item.textContent=text;
  if (scope) item.scope=scope;
  tr.append(item);
}
function render() {
  const wi=Number(target.value), ai=Number(arm.value), word=study.bank[wi], rule=study.arms[ai];
  const cell=study.cells[wi], clue=cell.fragments[ai], n=cell.n;
  byId("results").hidden=!n;
  byId("denominator").textContent=n ? "Visible fragment “"+clue+"” · "+n+" matched "+(n===1?"draw":"draws")+" per model. Each mean uses only draws with hidden target "+word+" and rule "+rule+"." :
    "No scheduled draws had the hidden target "+word+". Probabilities for this target are unavailable.";
  if (!n) { plot.replaceChildren(); byId("values").replaceChildren(); return; }
  const means=cell.means[ai];
  const maxima=study.bank.map((_,i)=>Math.max(...means.map(row=>row[i])));
  const rank=study.bank.map((_,i)=>i).sort((i,j)=>maxima[j]-maxima[i] || i-j);
  const full=byId("all-candidates").checked || rank.length<=10;
  const visible=full?rank:rank.slice(0,10);
  if (!full && !visible.includes(wi)) visible.push(wi);
  byId("all-control").hidden=rank.length<=10;
  byId("plot-note").textContent=full?"All candidates share one probability scale.":"The plot shows the ten highest-ranked candidates and the hidden target. Candidates are ranked by their highest mean across models.";
  byId("table-caption").textContent=study.bank.length+" candidate words, ordered by highest mean across models. Probabilities range from 0 to 1.";
  const body=document.createDocumentFragment();
  rank.forEach(i => {
    const tr=document.createElement("tr");
    tableCell(tr,"th",study.bank[i],"row");
    means.forEach(vector=>tableCell(tr,"td",String(vector[i])));
    body.append(tr);
  });
  byId("values").replaceChildren(body);
  const width=Math.max(285,plot.clientWidth || 900), left=90, right=width-19;
  const step=Math.max(34,study.models.length*5.5+7), base=55;
  const height=base+step*visible.length+8;
  plot.setAttribute("viewBox","0 0 "+width+" "+height); plot.setAttribute("height",height);
  plot.replaceChildren(svg("title",{id:"plot-title"},"Probability by candidate for "+word+", "+rule),
    svg("desc",{id:"plot-desc"},n+" matched draws per model. The full candidate probabilities appear in the values table."));
  const x=p=>left+p*(right-left);
  [0,.25,.5,.75,1].forEach(t=>{
    plot.append(svg("line",{x1:x(t),x2:x(t),y1:23,y2:height-8,stroke:"#cfdbda"}),
      svg("text",{x:x(t),y:16,"text-anchor":"middle","font-size":11},(100*t)+"%"));
  });
  visible.forEach((w,r)=>{
    const y=base+r*step;
    plot.append(svg("text",{x:left-10,y:y+4,"text-anchor":"end","font-size":12},study.bank[w]));
    means.forEach((vec,i)=>{
      const dot=marker(i,x(vec[w]),y+(i-(means.length-1)/2)*5.5);
      dot.append(svg("title",{},study.models[i]+" · "+study.bank[w]+" · "+vec[w]));
      plot.append(dot);
    });
  });
}
options(target,study.bank); options(arm,study.arms);
target.value=String(Math.max(0,study.bank.indexOf("firewood"))); arm.value="0";
byId("fixture").hidden=!study.synthetic;
const heading=document.createElement("tr"); tableCell(heading,"th","Candidate","col");
study.models.forEach((name,i)=>{
  const entry=document.createElement("span"), icon=svg("svg",{viewBox:"0 0 16 16","aria-hidden":true});
  icon.append(marker(i,8,8)); entry.append(icon,document.createTextNode(name)); byId("legend").append(entry);
  tableCell(heading,"th",name,"col");
});
byId("head").append(heading);
[target,arm,byId("all-candidates")].forEach(control=>control.addEventListener("change",render));
window.addEventListener("resize",render);
render();
</script></body></html>"""
    payload = json.dumps(data,separators=(",",":"),allow_nan=False).replace("<","\\u003c")
    (out/"target_explorer.html").write_text(document.replace("_C4_DATA_",payload),encoding="utf-8")


def detail(out, bank, models, draws, projected, targets, summary, groups, pairs, specs, figures,
           repeats, max_error, synthetic):
    n = len(draws)
    summary_table = table(
        ["Model","Arm","Trials","Entropy (bits)","Rule-compatible mass","Any-rule compatible mass","Target mass","Sampled exact"],
        [[r["model"],r["arm"],r["trials"],f'{r["entropy_bits"]:.3f}']+
         [f'{r[k]:.2%}' for k in ("rule_compatible_mass","any_rule_compatible_mass","target_mass","selected_exact")]
         for r in summary])
    linkmap = {v:k for k,v in figures}
    def pic(title):
        return f'<img src="{esc(linkmap[title])}" alt="{esc(title)}">'
    family_parts = []
    if "How many words carry the probability?" in linkmap:
        family_parts.append(pic("How many words carry the probability?") +
                            '<p><a href="fragment_rank_curves.csv">Cumulative mass by model, fragment and rank</a></p>')
    for slug,title,panels in specs:
        families = []
        for a,clue,mask in panels:
            candidates = [w for w,p in zip(bank,projected) if p[a] == clue]
            families.append([ARMS[a],clue,int(mask.sum()),", ".join(candidates)])
        family_parts.append(f"<h3>{esc(title)}</h3>"+pic(title)+table(
            ["Scheduled arm","Visible fragment","Trials per model","Compatible words in this bank"],families))
    if not any(slug == "firewood_fixed" for slug,_,_ in specs):
        family_parts.insert(0,"<p>No target draw was firewood. Fixed-target estimates are unavailable.</p>")
    if not any(slug == "other_families" for slug,_,_ in specs):
        family_parts.append("<p>No additional observed clue had multiple compatible bank words within its arm.</p>")
    family_desc = ("Dots show mean model-reported weight. Shading marks words whose letters fit the panel’s scheduled rule. "
                   "Within each figure all models and panels share the same categories and probability scale. Named words are ordered "
                   "by whether they fit any panel, then by the highest mean mass in any model and panel. The last row sums omitted words. "
                   "The pooled views include every draw yielding that arm and clue. The extra families are the most frequent ambiguous "
                   "clue in each arm after excluding firewood’s fragment. Alphabetical order breaks ties.")
    metric_notes = ("Entropy is computed for each full vector and averaged over trials. Compatible mass sums the probabilities of all words "
                    "that generate the displayed letters using the scheduled arm. Any-rule mass permits any of the three clue rules. "
                    "Target mass is the probability on the hidden word. Sampled exact is the observed share of local selections matching it.")
    pair_table = table(["Arm","Source → reference","Paired trials","KL (bits)","Infinite trials","Smoothed KL (bits)","JS (bits)"],
           [[r["arm"],f'{r["source"]} → {r["reference"]}',r["matched_trials"],fmt_bits(r["mean_kl_bits"]),
             r["infinite_kl_trials"],fmt_bits(r["smoothed_mean_kl_bits"]),fmt_bits(r["mean_js_bits"])] for r in pairs
            if r["source"] != r["reference"]])
    ambiguous_table = table(["Arm","Compatible words","Trials per model","Distinct fragments"],
                          [[r["arm"],r["compatible_words"],r["trials"],r["distinct_clues"]] for r in groups if r["model"]==models[0]])
    repeat_table = table(["Model","Repeated public inputs","Groups always identical","Calls in repeated groups",
                          "Exact matches / within-input pairs","Mean TV from group mean","Max TV from group mean"],
        [[r["model"],r["repeated_input_groups"],r["invariant_repeated_groups"],r["repeated_group_calls"],
          f'{r["identical_pairs"]:,} / {r["all_pairs"]:,} ({r["fraction_identical_pairs"]:.4%})' if r["all_pairs"] else "—",
          *[f'{r[k]:.5g}' if r[k]!="" else "—" for k in ("mean_tv_to_group_mean","max_tv_to_group_mean")]] for r in repeats])
    repeat_source = ("Native receipts identify the accepted request body, including the order of its menu, and the original response."
                     if all(r["source"]=="accepted native receipts" for r in repeats) else
                     "For models without native receipts, request identity follows the declared template and ordered menu. The CSV identifies the source for each model.")
    title = "C4 receiver distributions"
    badge = "<strong class=fixture>SYNTHETIC FIXTURE · software check only</strong>" if synthetic else ""
    text = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{badge and "Synthetic fixture · "}{title}</title>
<style>
:root{{color-scheme:light}}*{{box-sizing:border-box}}body{{margin:0 auto;padding:2.5rem clamp(1rem,4vw,4rem);max-width:90rem;color:#20343e;background:#fafaf8;font:1rem/1.5 system-ui,sans-serif}}h1,h2,h3{{line-height:1.16;color:#152f3d}}h1{{font-size:clamp(2rem,4vw,3.3rem);margin:.8rem 0}}h2{{margin:2.8rem 0 .8rem;border-top:1px solid #c8d2d2;padding-top:1.2rem}}h3{{margin:1.7rem 0 .6rem}}p{{max-width:85ch}}img{{display:block;width:100%;height:auto;max-width:88rem;margin:1rem 0;background:white}}.scroll{{overflow-x:auto}}table{{border-collapse:collapse;font-size:.91rem;background:white}}th,td{{padding:.45rem .65rem;border-bottom:1px solid #d8dddf;text-align:left}}th{{color:#164251;background:#e9efed}}a{{color:#005b8b}}.fixture{{color:#753d00}}summary{{cursor:pointer;font-weight:600}}footer{{margin-top:3rem;color:#455c65}}@media print{{body{{background:white}}img,tr{{break-inside:avoid}}}}
</style></head><body>{badge}<h1>{title}</h1>
<p><strong>{len(models):,} models · {len(bank):,} eight-letter bank words · {n:,} matched target draws · {len(models)*3*n:,} decisions</strong></p>
<p>Each target was evaluated with its first four letters, last four letters, and letters in positions 1, 3, 5 and 7. All models share these draws. The estimates give each scheduled trial equal weight, including repeated targets.</p>
<p><a href="target_explorer.html">Explore model probabilities for any target word and clue rule</a></p>
<h2>Reported weights and sampled recovery</h2><p>{metric_notes}</p>{summary_table}
<h2>Did identical requests produce the same probabilities?</h2><p>{repeat_source} Each group contains one model and public input. Hidden targets and clue rules may differ across trials that show the same fragment through an identical request. Each exact match requires numerical equality of every returned weight, before rounding or rescaling. Decimal notation and JSON property order do not affect equality. Sampled actions are excluded.</p>{repeat_table}
<p>The pair fraction counts unordered pairs within repeated groups, so more frequent inputs contribute more pairs. Total variation (TV) is half the sum of the absolute probability differences between a call and its group mean, after normalization to unit mass in floating-point arithmetic. Mean TV gives each call in a repeated group equal weight. Zero indicates agreement at the precision of that calculation. <a href="repeatability_by_input.csv">Per-input vector counts and dispersion</a> · <a href="repeatability_by_model.csv">Model summaries</a></p>
<h2>Where the probability went</h2><p>{family_desc}</p>{''.join(family_parts)}
<h2>Agreement on the same trial</h2><p>Each cell averages divergence between two full word distributions for the same trial and arm. The row is the source and the column is the reference. Exact zero against positive source mass gives infinite directional KL, including when it occurs in a single trial. Two identical vectors contribute zero. The standalone CSV also reports a finite-trials-only mean and its denominator is matched trials minus infinite trials.</p>
{pic("How much do two models' distributions differ?")}
<p>For a sensitivity check each vector is mixed with 0.000001 uniform mass over the full bank. This changes the estimand and makes the divergence finite. The equal-weight Jensen–Shannon divergence uses the original vectors and ranges from zero to one bit.</p>
{pic("Directional KL after uniform smoothing")}{pic("Bounded disagreement between models")}
<details><summary>Pairwise numerical results</summary>{pair_table}</details>
<h2>What changes with clue ambiguity?</h2><p>Ambiguity counts the words in this bank that could yield the clue under the scheduled rule. Word length is fixed at eight letters. Each point averages the individual vectors in its group. A sparse group can be dominated by one fragment or target. Differences between groups are descriptive.</p>
{pic("Uncertainty and clue compatibility")}{ambiguous_table}
<h2>Files and validation</h2><p><a href="summary.csv">Model and arm means</a> · <a href="divergence.csv">Matched divergences</a> · <a href="ambiguity.csv">Ambiguity groups</a> · <a href="fragment_inventory.csv">Complete fragment and target counts</a>{' · <a href="clue_distributions.csv">Full plotted distributions</a>' if specs else ''} · <a href="validation.json">Input hashes and matrix checks</a></p>
<footer>Every declared model contributed exactly one decision to each planned trial and arm. Every vector contained all bank options. Vectors within {P_TOL:g} of unit total were scaled to exactly one for analysis. Largest recorded total-mass error was {max_error:.2g}. Digests identify the files analyzed.</footer></body></html>"""
    (out/"report.html").write_text(text,encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",type=Path,required=True)
    parser.add_argument("--output",type=Path)
    parser.add_argument("--synthetic",action="store_true",help="mark figures and report as synthetic, requires matching manifest flag")
    args = parser.parse_args()
    root = args.input.resolve()
    out = (args.output or root/"analysis").resolve()
    bank,models,draws,p,s,sources,max_error = validate(root,args.synthetic)
    projected,targets,summary,groups = metrics(bank,models,draws,p,s)
    pairs = pairwise(models,p)
    repeat_rows,repeat_inputs_rows = repeatability(root,read_source(root/"manifest.json"))
    specs = overlay_specs(bank,draws,projected,targets)
    out.mkdir(parents=True,exist_ok=True)
    save_csv(out/"summary.csv",summary)
    save_csv(out/"ambiguity.csv",groups)
    save_csv(out/"divergence.csv",pairs)
    save_csv(out/"repeatability_by_input.csv",repeat_inputs_rows)
    save_csv(out/"repeatability_by_model.csv",repeat_rows)
    target_explorer(out,bank,models,draws,p,args.synthetic)
    inventory = []
    for a,arm in enumerate(ARMS):
        for clue in sorted(set(projected[:,a])):
            compatible = [w for w,proj in zip(bank,projected) if proj[a] == clue]
            union = [w for w,proj in zip(bank,projected) if clue in proj]
            inventory.append(dict(arm=arm,clue=clue,compatible_words=len(compatible),compatible=" ".join(compatible),
                                  any_rule_compatible=" ".join(union),trials_per_model=int((projected[targets,a]==clue).sum())))
    save_csv(out/"fragment_inventory.csv",inventory)
    figures = overlays(out,bank,models,p,s,projected,specs,args.synthetic)
    figures.extend(heatmaps(out,models,pairs,args.synthetic))
    figures.append(ambiguity_figure(out,models,bank,groups,args.synthetic))
    (out/"validation.json").write_text(json.dumps(dict(synthetic=args.synthetic,models=models,bank_size=len(bank),
        target_draws=len(draws),total_decisions=int(s.size),sha256=sources,
        max_raw_probability_total_error=max_error,sum_tolerance=P_TOL),indent=2)+"\n",encoding="utf-8")
    detail(out,bank,models,draws,projected,targets,summary,groups,pairs,specs,figures,repeat_rows,max_error,args.synthetic)
    print(out/"report.html")


if __name__ == "__main__":
    main()

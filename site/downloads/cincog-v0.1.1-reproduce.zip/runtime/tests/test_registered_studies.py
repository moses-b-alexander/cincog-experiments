"""Release regressions at the registry, participant and replay boundaries."""
from contextlib import redirect_stderr, redirect_stdout
from copy import deepcopy
from io import StringIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from framework_lab.objects import Decision, Form, View
from framework_lab.study import bundle, execute_trial, main, registry_entry, resolve
from framework_lab.study_providers import live, replay_participant
from studies import c2, c4


class RegisteredStudies(unittest.TestCase):
    def test_assignment_changes_only_appearance_and_pairs_shocks(self):
        entry = registry_entry("c2", None)
        entry["assignments"] = [{"seed": 22}, {"seed": 23}]
        plan = resolve("c2", entry, c2)
        record = bundle(plan, c2)
        self.assertEqual(record["summary"]["paired_difference"]["observed"], 2)
        for trial in record["trials"]:
            control = trial["result"]["control"]["plays"]
            altered = trial["result"]["alternate"]["plays"]
            self.assertEqual([p["shock"] for p in control], [p["shock"] for p in altered])
            self.assertEqual([p["defense"] for p in control], [p["defense"] for p in altered])
            for decision in trial["decisions"]:
                obs = decision["attempts"][0]["request"]["observation"]
                self.assertNotIn("defense", obs)
                self.assertNotIn("shock", obs)

    def test_word_fixture_uses_only_disclosed_deliveries(self):
        entry = registry_entry("c4", None)
        entry["parameters"] = {"arms": ["whole", "elide_second"], "word_bank": ["bushfire", "firewood"]}
        plan = resolve("c4", entry, c4)
        trial, = bundle(plan, c4)["trials"]
        self.assertEqual(trial["result"]["arms"]["elide_second"]["guess"], "firewood")
        for row in trial["decisions"]:
            req = row["attempts"][0]["request"]
            self.assertIn("first four letters", req["instruction"])
            self.assertNotIn("last four letters", req["instruction"])
            self.assertEqual(req["observation"]["possible_deliveries"], ["whole", "elide_second"])

    def test_only_scheduled_arms_contribute_to_the_denominator(self):
        entry = registry_entry("c4", None)
        entry["assignments"] = [{"arms": ["whole"]}, {"arms": ["whole", "alternating"]}]
        plan = resolve("c4", entry, c4)
        record = bundle(plan, c4)
        self.assertEqual(record["summary"]["whole"]["planned"], 2)
        self.assertEqual(record["summary"]["alternating"]["planned"], 1)
        self.assertEqual(record["summary"]["alternating"]["missing"], 0)
        self.assertEqual(record, bundle(plan, c4, record["trials"]))

    def test_receipts_bind_text_policy_and_model_input_order(self):
        req = c4.decision("A", c4.resolve({})).request()
        cfg = {"kind":"callable","factory":"respondent","seed":12}
        actor = live(cfg, c4)
        answer = actor(req)
        with replay_participant(cfg, actor.wire) as participant:
            self.assertEqual(participant(req), answer)
        with self.assertRaises(ValueError), replay_participant({"kind":"first_legal"}, actor.wire) as participant:
            participant(req)
        rec = deepcopy(actor.wire)
        rec[0]["request"] = dict(reversed(req.items()))
        with self.assertRaises(ValueError), replay_participant(cfg, rec) as participant:
            participant(req)

    def test_invalid_replay_cannot_fall_back_to_live(self):
        with TemporaryDirectory() as tmp, redirect_stdout(StringIO()), redirect_stderr(StringIO()):
            path = Path(tmp,"run.json")
            self.assertEqual(main("c4", ["run", "--output", str(path)]), 0)
            original = json.loads(path.read_text())
            with patch("framework_lab.study.live", side_effect=AssertionError("called a participant")):
                for trials in (None, [None], [], [{}]):
                    path.write_text(json.dumps({**original,"trials":trials}))
                    with self.subTest(trials=trials), self.assertRaises(SystemExit):
                        main("c4", ["replay", str(path)])
                original["summary"]["whole"]["value"] = True
                path.write_text(json.dumps(original))
                with self.assertRaises(SystemExit):
                    main("c4", ["replay", str(path)])

    def test_unused_invalid_receipt_is_rejected(self):
        plan = resolve("c4", registry_entry("c4", None), c4)
        rows = bundle(plan, c4)["trials"]
        rows[0]["receipts"]["shared"]["A"].append(None)
        with self.assertRaises(ValueError):
            bundle(plan, c4, rows)

    def test_many_independent_participants_replay_without_recursive_binding(self):
        streams = {f"panel-{i}": ["judge"] for i in range(350)}
        decision = Decision(View("judge", {}, {"horizon": 1}, "Record a vote."), (Form("vote"),))

        def run(session, settings):
            votes = 0
            for name in streams:
                with session.stream(name):
                    votes += int(session.ask(name, decision) is not None)
            return {"votes": votes}

        module = SimpleNamespace(run=run, measure=lambda result, settings: {
            "votes": {"numerator": result["votes"], "observed": 350, "planned": 350}})
        trial = {"id": "panel/1", "settings": {}, "design": {"streams": streams},
                 "agents": {"judge": {"kind": "first_legal"}}}
        recorded = execute_trial(module, trial)
        self.assertEqual(recorded["result"], {"votes": 350})
        with patch("framework_lab.study.live", side_effect=AssertionError("replay called a participant")):
            self.assertEqual(execute_trial(module, trial, recorded), recorded)

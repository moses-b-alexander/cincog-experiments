"""Qualified model edits, their receipt provenance and legacy opt-out."""
from copy import deepcopy
from contextlib import redirect_stderr
import hashlib
from io import StringIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from framework_lab import model_prompts
from framework_lab.__main__ import replay_choice_record
from framework_lab.decision_spec import run_spec
from framework_lab.llama_decision import LlamaCppDecision
from .test_scored_choices import SPEC


MODEL = "baidu-ernie-4.5-0.3b-pt"
PROMPT = "User: preserve my text\nAssistant: here\nAssistant: "


def runtime(template, blob=None):
    return {"model_metadata": {"n_params": 360748032, "n_vocab": 103424},
            "blob_digest_from_name": blob, "template_sha256": template}


class ModelEdits(unittest.TestCase):
    def test_changing_a_failed_study_policy_preserves_its_evidence(self):
        from studies import c4_durability as study
        with TemporaryDirectory() as tmp:
            out = Path(tmp)
            job = study.plan(out)[0]
            folder = study.model_dir(out, MODEL)
            folder.mkdir()
            study.save(folder / (job["id"] + ".failure.json.gz"), {"binding": {"codebook": "ascii64"}})
            failure = folder / "unavailable.json"
            study.save(failure, {"reason": "original preflight failed"})
            original = {p: p.read_bytes() for p in out.rglob("*") if p.is_file()}
            for models in (["--model", MODEL, "--weights", "local.gguf"],
                           ["--model", MODEL],
                           ["--model", "fresh", "--model", MODEL]):
                args = ["study", "llm", "--out", tmp, *models, "--prompt-edits", "auto"]
                with self.subTest(models=models), patch("sys.argv", args), patch.object(study, "server") as server:
                    with patch.object(study, "model_file", side_effect=FileNotFoundError("weights moved")) as lookup:
                        error = StringIO()
                        with self.assertRaises(SystemExit), redirect_stderr(error):
                            study.main()
                        self.assertIn("new output directory", error.getvalue())
                        lookup.assert_not_called()
                    server.assert_not_called()
                self.assertEqual({p: p.read_bytes() for p in out.rglob("*") if p.is_file()}, original)
                self.assertFalse((out / "fresh").exists())

    def test_study_resumes_with_recorded_controls(self):
        from studies import c4_durability as study
        with TemporaryDirectory() as tmp:
            folder = Path(tmp)
            self.assertEqual(study.resume_options(folder, None), {"prompt_edits": "off"})
            self.assertEqual(study.resume_options(folder, "auto"), {"prompt_edits": "auto"})
            study.save(folder / "r1-w1-prefix.json.gz",
                       {"binding": {"prompt_policy": model_prompts.POLICY_V1, "join_separator": True}})
            expected = {"prompt_edits": model_prompts.POLICY_V1, "canonical_echo": False, "join_separator": True}
            self.assertEqual(study.resume_options(folder, None), expected)
            self.assertEqual(study.resume_options(folder, "auto"), expected)
            with self.assertRaises(ValueError):
                study.resume_options(folder, "off")

    def test_exact_model_template_and_terminal_cue(self):
        original = runtime(model_prompts.ERNIE_ORIGINAL_TEMPLATE)
        edited, audit = model_prompts.edit_rendered_prompt(MODEL, original, PROMPT)
        self.assertEqual(edited, "User: preserve my text\nAssistant: here\nAssistant:\n")
        self.assertEqual(audit["status"], "applied")
        self.assertEqual(audit["rendered_sha256"], hashlib.sha256(PROMPT.encode()).hexdigest())
        self.assertEqual(audit["effective_sha256"], hashlib.sha256(edited.encode()).hexdigest())
        self.assertEqual(model_prompts.edit_rendered_prompt(MODEL, original, edited)[0], edited)
        for model, info in [(MODEL + "-other", original), (MODEL, runtime(model_prompts.ERNIE_ORIGINAL_TEMPLATE, "0"*64)),
                            (MODEL, {**original, "model_metadata": {"n_params": 1, "n_vocab": 103424}})]:
            self.assertEqual(model_prompts.edit_rendered_prompt(model, info, PROMPT), (PROMPT, None))
        renamed = runtime(model_prompts.ERNIE_ORIGINAL_TEMPLATE, model_prompts.ERNIE_WEIGHTS)
        self.assertEqual(model_prompts.edit_rendered_prompt("other-local-alias", renamed, PROMPT)[0], edited)
        self.assertEqual(model_prompts.edit_rendered_prompt(MODEL, runtime("custom"), PROMPT)[0], PROMPT)
        same, audit = model_prompts.edit_rendered_prompt(MODEL, runtime(model_prompts.ERNIE_NEWLINE_TEMPLATE), edited)
        self.assertEqual(same, edited)
        self.assertEqual(audit["status"], "already_compatible")

    def test_edit_precedes_tokenization_and_replays_from_original_text(self):
        def transport(path, body):
            outputs = {
                "/v1/models": {"data": [{"id": MODEL, "meta": {"n_params": 360748032, "n_vocab": 103424}}]},
                "/props": {"default_generation_settings": {"n_ctx": 64}, "chat_template": "TEST",
                           "model_path": "model.gguf", "build_info": "test"},
                "/apply-template": {"prompt": PROMPT},
            }
            if path == "/tokenize":
                # Split the test's first label so the preflight stops without a vocabulary-sized fixture.
                output = {"tokens": [1] if body["content"][-1] in " \n" else [1, 2, 3]}
            else:
                output = outputs[path]
            return {"status": 200, "text": json.dumps(output)}

        with patch.object(model_prompts, "ERNIE_ORIGINAL_TEMPLATE", hashlib.sha256(b"TEST").hexdigest()):
            for policy in ("auto", "off"):
                p = LlamaCppDecision(MODEL, codebook="ascii64", transport=transport, prompt_edits=policy)
                trace = run_spec(SPEC, p)
                record = {"candidate": "objects", "case": "spec", "spec": SPEC, "binding": p.identity(),
                          "wire": p.wire, **trace}
                wire, = p.wire
                first = next(c["body"]["content"] for c in wire["calls"] if c["path"] == "/tokenize")
                self.assertEqual(first, PROMPT[:-1] + "\n" if policy == "auto" else PROMPT)
                self.assertEqual(replay_choice_record(record), trace)
                if policy == "auto":
                    self.assertEqual(wire["prompt_edit"]["status"], "applied")
                    altered = deepcopy(record)
                    altered["wire"][0]["prompt_edit"]["effective_sha256"] = "0" * 64
                    with self.assertRaises(ValueError):
                        replay_choice_record(altered)
                else:
                    self.assertNotIn("prompt_policy", record["binding"])
                    self.assertNotIn("prompt_edit", wire)
        self.assertNotIn("prompt_policy", LlamaCppDecision(MODEL, codebook="decimal").identity())

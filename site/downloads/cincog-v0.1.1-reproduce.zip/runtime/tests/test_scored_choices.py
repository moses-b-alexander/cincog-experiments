"""Finite decisions, native token scores and display-only filters."""
from contextlib import redirect_stderr, redirect_stdout
from copy import deepcopy
from io import StringIO
import gzip
import json
import math
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from framework_lab.__main__ import main, replay_choice_record
from framework_lab.choices import ChoiceView, action_catalog, choice_reports
from framework_lab.decision_spec import from_spec, run_spec
from framework_lab.llama_decision import LlamaCppDecision, replay
from framework_lab.ollama_decision import OllamaDecision
from framework_lab.objects import AsciiTextField, Decision, Form, Session


def tool(name, **properties):
    return {"type": "function", "function": {"name": name, "parameters": {
        "type": "object", "properties": properties, "required": list(properties), "additionalProperties": False}}}


SPEC = {"role": "keeper", "observation": {"lamp": "off"}, "objective": {"metric": "light"},
        "instruction": "Choose an action.", "tools": [
            tool("wait"), tool("set_light", level={"type": "integer", "enum": [1, 2]})]}


class Server:
    def __init__(self, mutate=None):
        self.mutate = mutate
        self.messages = []
        self.calls = []

    def __call__(self, path, body):
        self.calls.append(path)
        if path == "/v1/models":
            out = {"data": [{"id": "test", "meta": {"n_vocab": 8}}]}
        elif path == "/props":
            out = {"default_generation_settings": {"n_ctx": 16}, "chat_template": "TEST",
                   "model_path": "model.gguf", "build_info": "test"}
        elif path == "/apply-template":
            self.messages.append(body["messages"])
            out = {"prompt": "PROMPT"}
        elif path == "/tokenize":
            suffix = body["content"].removeprefix("PROMPT")
            out = {"tokens": [0, 1] + ([int(suffix) + 2] if suffix else [])}
        else:
            assert path == "/completion"
            # Token 0 wins in the full vocabulary. Codes 1, 2 and 3 correspond to IDs 3, 4 and 5.
            probs = [.40, .10, .05, .10, .20, .10, .025, .025]
            scores = [{"id": i, "bytes": list(str(i - 2).encode()), "logprob": math.log(p)}
                      for i, p in enumerate(probs)]
            out = {"model": "test", "prompt": "PROMPT", "tokens_predicted": 1, "tokens_evaluated": 2,
                   "truncated": False, "content": "unoffered", "generation_settings": {
                       k: v for k, v in body.items() if k != "prompt"},
                   "completion_probabilities": [{"top_logprobs": scores}]}
        if self.mutate:
            self.mutate(path, out)
        return {"status": 200, "text": json.dumps(out)}


def execute(server, spec=SPEC, **settings):
    provider = LlamaCppDecision("test", transport=server, **settings)
    trace = run_spec(spec, provider)
    return {"version": 1, "case": "spec", "candidate": "objects", "spec": spec,
            "binding": provider.identity(), "wire": provider.wire, **trace}


class Filters(unittest.TestCase):
    def test_phrases_and_boundaries(self):
        labels = dict.fromkeys("abc")
        probs = dict(a=.4, b=.3, c=.3)
        def shown(phrase):
            return ChoiceView.from_prompt(phrase).apply(labels, probs)
        self.assertEqual(shown("show me the top 10 choices")["offered_count"], 3)
        self.assertEqual([r["option"] for r in shown("top 2")["choices"]], ["a", "b"])
        self.assertEqual(shown("show me the choices with cumulative probability up to 60%")["shown_mass"], .4)
        self.assertEqual(shown("choices with cumulative up to 70%")["omitted_mass"], .3)
        self.assertEqual(shown("up to 30%")["choices"], [])
        self.assertEqual(shown("up to 100%")["shown_mass"], 1)
        self.assertEqual(shown("cover 60%")["shown_mass"], .7)
        self.assertEqual(shown("cover 0%")["choices"], [])
        self.assertFalse(ChoiceView(top_k=1, cover_prob=.6).apply(labels, probs)["coverage_met"])
        self.assertTrue(shown("cover 60%")["coverage_met"])
        for cfg in [{"top_k": True}, {"top_k": 0}, {"cover_prob": float("nan")},
                    {"top_k_prob": 1.1}, {"top_k_prob": .4, "cover_prob": .5}]:
            with self.subTest(cfg=cfg), self.assertRaises(ValueError):
                ChoiceView(**cfg)
        with self.assertRaises(ValueError):
            ChoiceView().apply(labels, {"a": .9})


class NativeScoring(unittest.TestCase):
    def test_ascii_control_matches_the_native_menu_and_seeded_action(self):
        class AsciiServer(Server):
            def __call__(self, path, body):
                if path == "/tokenize":
                    body = dict(body)
                    for i, ch in enumerate("ABC", 1):
                        if body["content"] == "PROMPT" + ch:
                            body["content"] = "PROMPT" + str(i)
                result = super().__call__(path, body)
                if path == "/completion":
                    data = json.loads(result["text"])
                    for row in data["completion_probabilities"][0]["top_logprobs"]:
                        if 3 <= row["id"] <= 5:
                            row["bytes"] = [ord("ABC"[row["id"] - 3])]
                    result["text"] = json.dumps(data)
                return result

        scored = execute(AsciiServer(), codebook="ascii64", selection="sample", seed=19)
        labels = list(action_catalog(from_spec(SPEC).request()["schema"]))
        weights = dict(zip(labels, [.25, .50, .25]))
        def native(body):
            answer = {"type": "choice", "choice": labels[1], "confidence": .5, "probabilities": weights}
            return {"status": 200, "response": json.dumps({"model": "native", "answers": {"decision": answer}})}
        provider = OllamaDecision("native", selection="sample", seed=19, transport=native)
        trace = run_spec(SPEC, provider)
        self.assertEqual(scored["result"], trace["result"])
        self.assertEqual(replay_choice_record(scored)["result"], trace["result"])
        llm_row, = choice_reports(scored)
        s1_row, = choice_reports({**trace, "wire": provider.wire, "binding": provider.identity()})
        for left, right in zip(llm_row["choices"], s1_row["choices"], strict=True):
            self.assertEqual(left["command"], right["command"])
            self.assertAlmostEqual(left["probability"], right["probability"])
        self.assertAlmostEqual(llm_row["menu_mass"], .4)

    def test_decimal_byte_error_preserves_legacy_receipt(self):
        def corrupt(path, out):
            if path == "/completion":
                out["completion_probabilities"][0]["top_logprobs"][4]["bytes"] = [90]
        record = execute(Server(corrupt))
        for wire in record["wire"]:
            self.assertEqual(wire["invalid_response"], "code token bytes disagree with its decimal label")
        self.assertNotIn("codebook", record["binding"])
        replay_choice_record(record)

    def test_space_joined_codes_and_canonical_token_echo(self):
        class BoundaryServer(Server):
            def __init__(self, canonical):
                super().__init__()
                self.canonical = canonical

            def __call__(self, path, body):
                def reply(obj):
                    return {"status": 200, "text": json.dumps(obj)}
                if path == "/apply-template":
                    return reply({"prompt": "PROMPT "})
                if path == "/tokenize":
                    tokens = {"PROMPT ": [0, 1, 7], "PROMPT": [0, 1], "canonical": [7, 1]}
                    for i, code in enumerate("ABC", 3):
                        tokens["PROMPT " + code] = [0, 1, i]
                    return reply({"tokens": tokens[body["content"]]})
                if path == "/detokenize":
                    assert body["tokens"] == [0, 1]
                    return reply({"content": self.canonical})
                result = super().__call__(path, body)
                if path == "/props":
                    data = json.loads(result["text"])
                    # The original prefix fills the slot. The shared joined boundary has room.
                    data["default_generation_settings"]["n_ctx"] = 3
                    return reply(data)
                if path == "/completion":
                    data = json.loads(result["text"])
                    data["prompt"] = "canonical"
                    for row in data["completion_probabilities"][0]["top_logprobs"]:
                        if 3 <= row["id"] <= 5:
                            row["bytes"] = [32, ord("ABC"[row["id"] - 3])]
                    result = reply(data)
                return result

        record = execute(BoundaryServer("canonical"), codebook="ascii64")
        self.assertEqual(record["decisions"][0]["status"], "accepted")
        self.assertEqual(record["wire"][0]["code_separator"], " ")
        self.assertEqual(replay_choice_record(record)["result"], record["result"])
        wrong = execute(BoundaryServer("different"), codebook="ascii64")
        self.assertEqual(wrong["decisions"][0]["status"], "exhausted")
        replay_choice_record(wrong)

    def test_generic_tool_menu_and_native_conditional(self):
        server = Server()
        record = execute(server, {**SPEC, "display": {"top_k": 1}})
        result = choice_reports(record, ChoiceView(top_k=1))[0]
        self.assertEqual(result["choices"][0]["command"], {"action": "set_light", "args": {"level": 1}})
        self.assertAlmostEqual(result["shown_mass"], .5)
        self.assertAlmostEqual(result["menu_mass"], .4)
        self.assertEqual(result["score_source"], "next_token_given_menu")
        self.assertEqual(result["selected_option"], "option_2")
        self.assertTrue(result["admitted"])
        visible = json.loads(server.messages[0][1]["content"])
        self.assertEqual(set(visible), {"role", "observation", "objective", "instruction", "choices"})
        self.assertEqual(visible["choices"]["1"], {"action": "wait", "args": {}})
        self.assertEqual(replay_choice_record(record)["result"], record["result"])
        self.assertEqual(server.calls.count("/completion"), 1)

    def test_filters_do_not_change_sampling_or_the_prompt(self):
        a, b = Server(), Server()
        full = execute(a, selection="sample", seed=19)
        filtered = execute(b, {**SPEC, "display": {"top_k_prob": .05}}, selection="sample", seed=19)
        self.assertEqual(a.messages, b.messages)
        self.assertEqual(full["wire"], filtered["wire"])
        self.assertEqual(full["result"], filtered["result"])
        self.assertEqual(choice_reports(filtered, ChoiceView(top_k_prob=.05))[0]["choices"], [])
        self.assertEqual(replay_choice_record(filtered)["result"], full["result"])

    def test_rejects_incomplete_and_sampler_modified_readouts(self):
        def corrupt(path, out):
            if path == "/completion":
                self.damage(out)
        for damage in (lambda o: o["completion_probabilities"][0]["top_logprobs"].pop(),
                       lambda o: o["completion_probabilities"][0]["top_logprobs"][3].update(bytes=[90]),
                       lambda o: o["completion_probabilities"][0]["top_logprobs"][1].update(logprob=-100),
                       lambda o: o["generation_settings"].update(post_sampling_probs=True),
                       lambda o: o.update(prompt="DIFFERENT")):
            with self.subTest(damage=damage):
                self.damage = damage
                record = execute(Server(corrupt))
                self.assertEqual(record["decisions"][0]["status"], "exhausted")
                self.assertEqual(len(record["wire"]), 2)
                self.assertTrue(all(not row["scored"] for row in choice_reports(record)))
                replay_choice_record(record)

    def test_unsupported_needs_no_model_completion(self):
        def split(path, out):
            if path == "/tokenize" and len(out["tokens"]) == 3:
                out["tokens"].append(0)
        server = Server(split)
        record = execute(server)
        self.assertEqual(record["decisions"][0]["status"], "unsupported_form")
        self.assertEqual(record["decisions"][0]["attempts"], [])
        self.assertIn("single token", choice_reports(record)[0]["error"])
        self.assertNotIn("/completion", server.calls)
        replay_choice_record(record)
        provider = LlamaCppDecision("test", transport=server)
        form = Decision(from_spec(SPEC).view, (Form("say", (AsciiTextField("text", 12),)),))
        self.assertIsNone(Session(provider).ask("open", form))
        self.assertEqual(provider.wire, [])

    def test_private_veto_preserves_scored_attempts(self):
        public = from_spec(SPEC)
        decision = Decision(public.view, public.forms, legal=lambda _: False)
        provider = LlamaCppDecision("test", transport=Server())
        def play(p):
            s = Session(p)
            s.ask("private-id", decision)
            return s.trace({})
        trace = play(provider)
        rows = choice_reports({**trace, "binding": provider.identity(), "wire": provider.wire})
        self.assertEqual([r["admitted"] for r in rows], [False, False])
        self.assertEqual(replay(provider.identity(), provider.wire, play), trace)

    def test_display_uses_verified_order_for_compound_actions(self):
        spec = {**SPEC, "tools": [tool("move", x={"type": "integer", "enum": [1, 2]},
                                       y={"type": "integer", "enum": [3, 4]})]}
        record = execute(Server(), spec)
        form = record["decisions"][0]["attempts"][0]["request"]["schema"]["anyOf"][0]
        fields = form["properties"]["args"]["properties"]
        fields["x"] = fields.pop("x")
        with TemporaryDirectory() as tmp:
            file = Path(tmp, "record.json")
            file.write_text(json.dumps(record), encoding="utf-8")
            output = StringIO()
            with redirect_stdout(output):
                self.assertEqual(main(["show", str(file), "--top-k", "1"]), 0)
            shown = json.loads(output.getvalue())[0]["choices"][0]["command"]
            self.assertEqual(shown, record["result"]["action"])
            self.assertEqual(shown["args"], {"x": 1, "y": 4})

    def test_score_output_round_trips_and_legacy_filenames_still_replay(self):
        with TemporaryDirectory() as tmp, redirect_stdout(StringIO()):
            spec = Path(tmp, "spec.json")
            spec.write_text(json.dumps(SPEC), encoding="utf-8")
            provider = LlamaCppDecision("test", transport=Server())
            record = Path(tmp, "receipt.JSON.GZ")
            with patch("framework_lab.__main__.LlamaCppDecision", return_value=provider):
                self.assertEqual(main(["score", str(spec), "--llama-model", "test", "--output", str(record)]), 0)
            plain = gzip.decompress(record.read_bytes())
            self.assertEqual(main(["replay", str(record)]), 0)
            self.assertEqual(main(["show", str(record), "--top-k", "1"]), 0)
            with self.assertRaises(SystemExit), redirect_stderr(StringIO()):
                main(["score", str(spec), "--llama-model", "test", "--output", str(record)])
            self.assertEqual(gzip.decompress(record.read_bytes()), plain)
            record.write_bytes(plain)
            self.assertEqual(main(["replay", str(record)]), 0)

    def test_offline_cli_detects_tampering_before_display(self):
        record = execute(Server())
        with TemporaryDirectory() as tmp:
            file = Path(tmp, "record.json")
            file.write_text(json.dumps(record), encoding="utf-8")
            output = StringIO()
            with redirect_stdout(output):
                self.assertEqual(main(["show", str(file), "--show", "top 1"]), 0)
            self.assertEqual(len(json.loads(output.getvalue())[0]["choices"]), 1)
            compressed = Path(tmp, "record.json.gz")
            compressed.write_bytes(gzip.compress(file.read_bytes()))
            with redirect_stdout(StringIO()):
                self.assertEqual(main(["replay", str(compressed)]), 0)
            record["wire"][0]["probabilities"] = {"option_1": 1, "option_2": 0, "option_3": 0}
            file.write_text(json.dumps(record), encoding="utf-8")
            with self.assertRaises(SystemExit), redirect_stderr(StringIO()):
                main(["show", str(file)])


class ToolSpecs(unittest.TestCase):
    def test_model_tag_names_a_folder_within_the_study(self):
        from studies.c4_durability import model_dir
        out = Path("study")
        self.assertEqual(model_dir(out, "org/model.3:q4"), out / "org_model.3_q4")
        for tag in ("", ".", "..", "org/../model", "org/model:.."):
            with self.subTest(tag=tag), self.assertRaises(ValueError):
                model_dir(out, tag)

    def test_resume_checks_later_existing_assignments_before_scoring(self):
        from studies.c4_durability import model_dir, plan, run_cells, save
        with TemporaryDirectory() as tmp:
            out = Path(tmp)
            jobs = plan(out)
            folder = model_dir(out, "test")
            folder.mkdir()
            save(folder / (jobs[-1]["id"] + ".json.gz"), {"assignment": jobs[0]})
            server = Server()
            with self.assertRaisesRegex(ValueError, "wrong assignment"):
                run_cells(out, "test", lambda seed: LlamaCppDecision("test", seed=seed, transport=server))
            self.assertEqual(server.calls, [])

    def test_same_action_in_correlated_forms(self):
        spec = deepcopy(SPEC)
        spec["tools"] = [tool("send", size={"type": "integer", "enum": [i]},
                              urgent={"type": "boolean", "enum": [flag]}) for i, flag in [(1, True), (3, False)]]
        catalog = action_catalog(from_spec(spec).request()["schema"])
        self.assertEqual([cmd["args"] for cmd in catalog.values()],
                         [{"size": 1, "urgent": True}, {"size": 3, "urgent": False}])

    def test_rejects_unbounded_and_partial_tool_specs(self):
        for arg in ({"type": "string"}, {"type": "number", "enum": [.5]}, {"type": "integer", "enum": [True]}):
            with self.subTest(arg=arg), self.assertRaises(ValueError):
                from_spec({**SPEC, "tools": [tool("send", x=arg)]})
        incomplete = tool("send", x={"type": "string", "enum": ["a"]})
        incomplete["function"]["parameters"]["required"] = []
        with self.assertRaises(ValueError):
            from_spec({**SPEC, "tools": [incomplete]})

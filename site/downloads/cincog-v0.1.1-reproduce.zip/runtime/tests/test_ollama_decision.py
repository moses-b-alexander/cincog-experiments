"""Offline protocol and replay tests. All probability vectors here are fixtures."""
from contextlib import redirect_stdout
from copy import deepcopy
import io
from http.client import IncompleteRead
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from framework_lab.__main__ import main
from framework_lab.domain import WORDS
from framework_lab.ollama_decision import OllamaDecision, replay
from framework_lab.objects import AsciiTextField, Decision, Field, Form, Session, View
from replay_live import verify
from studies import distribution as study


MODEL = "native:fixture"


def answer(body):
    labels = list(body["questions"]["decision"]["criteria"])
    probs = dict.fromkeys(labels, 0)
    probs[labels[0]] = 0.5
    probs[labels[-1]] = 0.5
    return {"model": MODEL, "answers": {"decision": {"type": "choice", "choice": labels[-1],
            "confidence": 0.25, "probabilities": probs}}, "usage": {"input_tokens": 10, "output_tokens": 3}}


def fixture(body):
    return {"status": 200, "response": json.dumps(answer(body))}


class NativeChoiceContractTests(unittest.TestCase):
    def test_session_separates_capability_veto_and_outage(self):
        view = View("C", {}, {}, "choose")
        free = Decision(view, (Form("say", (AsciiTextField("text", 16),)),))
        finite = (Form("vote", (Field("side", ("heads", "tails")),)),)
        veto = Decision(view, finite, legal=lambda _: False)
        for decision, transport, status, calls in (
                (free, fixture, "unsupported_form", 0), (veto, fixture, "exhausted", 2),
                (veto, lambda b: {"status": 503, "response": "{}"}, "service_failure", 1)):
            provider = OllamaDecision(MODEL, transport=transport)
            def play(participant):
                session = Session(participant)
                session.perform("private-turn-id", decision, lambda _: self.fail("unexpected effect"))
                return session.trace({"guess": None, "exact": None})
            trace = play(provider)
            event, = trace["decisions"]
            self.assertEqual((event["status"], len(event["attempts"]), len(provider.wire)),
                             (status, calls, calls))
            self.assertEqual(replay(provider.identity(), provider.wire, play), trace)
            counts = study.summarize([({}, trace)])
            self.assertEqual((counts[status], counts["attempts"], counts["failed"]), (1, calls, 1))
            if status == "unsupported_form":
                self.assertEqual(event["request"], free.request())
            if status == "exhausted":
                first, second = provider.wire
                self.assertEqual(first["body"], second["body"])
                self.assertEqual(first["probabilities"], second["probabilities"])
                self.assertNotIn("private-turn-id", json.dumps(first["body"]))

    def test_unreadable_http_body_preserves_status_and_replay(self):
        with patch("framework_lab.ollama_decision.HTTPConnection") as factory:
            response = factory.return_value.getresponse.return_value
            for code, payload, status, calls in (
                    (200, b"\xff", "exhausted", 2),
                    (429, b"\xff", "service_failure", 1),
                    (403, IncompleteRead(b""), "service_failure", 1)):
                response.status = code
                response.read.side_effect = payload if isinstance(payload, Exception) else None
                response.read.return_value = payload
                provider = OllamaDecision(MODEL)
                run = lambda p: study.execute({"id": "trial", "fragment": "fire"}, p)
                trace = run(provider)
                self.assertEqual((trace["decisions"][0]["status"], len(provider.wire)), (status, calls))
                self.assertTrue(all(w["status"] == code for w in provider.wire))
                if isinstance(payload, bytes):
                    self.assertEqual(provider.wire[0]["response_base64"], "/w==")
                wires = [dict(reversed(list(w.items()))) for w in provider.wire]
                self.assertEqual(replay(provider.identity(), wires, run), trace)
            response.status = 429
            response.read.side_effect = None
            response.read.return_value = b"\xff"
            with TemporaryDirectory() as tmp:
                summary = study.run(Path(tmp, "receipts"), MODEL)
            cells = summary["by_model"][MODEL].values()
            self.assertEqual(sum(c["service_failure"] for c in cells), 1)
            self.assertEqual(sum(c["not_started_or_unrecorded"] for c in cells), 31)

    def test_typed_choice_and_host_legality(self):
        raw = ('{"model":"native:fixture","answers":{"decision":{"type":"choice","choice":"returns",'
               '"confidence":1.0,"probabilities":{"returns":1.0,"shipping":0.0,"billing":0.0}}},'
               '"usage":{"input_tokens":357,"output_tokens":38}}')
        provider = OllamaDecision(MODEL, transport=lambda _: {"status": 200, "response": raw})
        form = Form("route", (Field("team", ("returns", "shipping", "billing")),))
        view = View("router", {"ticket": "wrong shoe size"}, {}, "Select the team")
        decision = Decision(view, (form,))
        cmd = Session(provider).ask("one", decision)
        self.assertEqual(cmd.as_dict(), {"action": "route", "args": {"team": "returns"}})
        session = Session(provider)
        self.assertIsNone(session.ask("two", Decision(view, (form,), legal=lambda c: False)))
        self.assertEqual(session.trace({})["decisions"][0]["status"], "exhausted")

    def test_c4_wire_and_selection(self):
        provider = OllamaDecision(MODEL, transport=fixture)
        result = study.execute({"id": "private-assignment", "fragment": "frwo"}, provider)
        wire, = provider.wire
        body = wire["body"]
        self.assertEqual(body["state"], {"role": "C", "observation": {"fragment": "frwo"},
                                         "objective": study.decision("frwo").view.objective})
        self.assertEqual(set(body), {"state", "model", "questions"})
        question = body["questions"]["decision"]
        self.assertEqual(question["instructions"], study.INSTRUCTION)
        self.assertEqual(list(question["criteria"]), list(WORDS))
        self.assertEqual(question["criteria"], dict.fromkeys(WORDS))
        self.assertEqual(result["result"]["guess"], WORDS[-1])
        self.assertEqual(wire["probabilities"][WORDS[0]], 0.5)
        self.assertIsNone(provider.identity()["selection_seed"])

    def test_invalid_reply_retry_and_exhaustion(self):
        def nonfinite(a):
            a["probabilities"][WORDS[0]] = float("nan")

        def wrong_max(a):
            a["choice"] = WORDS[1]

        for mutate in (nonfinite, wrong_max, lambda a: a["probabilities"].pop(WORDS[3]),
                       lambda a: a["probabilities"].update(extra=0),
                       lambda a: a["probabilities"].update({WORDS[0]: 0.4}),
                       lambda a: a["probabilities"].update({WORDS[0]: True}),
                       lambda a: a.update(confidence=2), lambda a: a.update(type="score")):
            def invalid(body):
                response = answer(body)
                mutate(response["answers"]["decision"])
                return {"status": 200, "response": json.dumps(response)}
            provider = OllamaDecision(MODEL, transport=invalid)
            trace = study.execute({"id": "id", "fragment": "wood"}, provider)
            self.assertEqual(trace["decisions"][0]["status"], "exhausted")
            self.assertEqual(len(provider.wire), 2)
            self.assertTrue(all("invalid_response" in w for w in provider.wire))
            self.assertIsNone(trace["result"]["guess"])
        calls = iter([{"status": 200, "response": "{}"}, None])
        provider = OllamaDecision(MODEL, transport=lambda body: next(calls) or fixture(body))
        trace = study.execute({"id": "id", "fragment": "wood"}, provider)
        self.assertEqual(trace["decisions"][0]["status"], "accepted")
        self.assertEqual(len(trace["decisions"][0]["attempts"]), 2)

    def test_transport_model_id_and_free_text(self):
        for receipt in ({"status": 503, "response": "temporarily unavailable"},
                        {"transport_error": "TimeoutError"}):
            provider = OllamaDecision(MODEL, transport=lambda _: receipt)
            run = lambda p: study.execute({"id": "id", "fragment": "wood"}, p)
            trace = run(provider)
            self.assertEqual(trace["decisions"][0]["status"], "service_failure")
            self.assertEqual(len(provider.wire), 1)
            self.assertEqual(replay(provider.identity(), provider.wire, run), trace)
            with self.assertRaises(ValueError):
                replay(provider.identity(), [], run)
        for model, status in [(MODEL, "accepted"), ("native:other", "exhausted")]:
            provider = OllamaDecision(model, transport=fixture)
            trace = study.execute({"id": "id", "fragment": "wood"}, provider)
            self.assertEqual(trace["decisions"][0]["status"], status)
        provider = OllamaDecision(MODEL, transport=lambda _: self.fail("free text dispatched"))
        decision = Decision(View("A", {}, {}, "send"), (Form("send", (AsciiTextField("text", 16),)),))
        with self.assertRaisesRegex(ValueError, "finite"):
            provider(decision.request())

    def test_http_request_uses_local_ollama(self):
        with patch("framework_lab.ollama_decision.HTTPConnection") as factory:
            conn = factory.return_value
            response = conn.getresponse.return_value
            response.status = 200
            def send(method, url, data, headers):
                self.assertEqual((method, url), ("POST", "/v1/systemone"))
                self.assertEqual(headers, {"Content-Type": "application/json"})
                response.read.return_value = json.dumps(answer(json.loads(data))).encode()
            conn.request.side_effect = send
            provider = OllamaDecision(MODEL)
            trace = study.execute({"id": "id", "fragment": "fire"}, provider)
            self.assertEqual(trace["decisions"][0]["status"], "accepted")
            factory.assert_called_once_with("127.0.0.1", 11434, timeout=180)
            conn.close.assert_called_once()

    def test_baseline_cli_and_replay(self):
        with TemporaryDirectory() as tmp, redirect_stdout(io.StringIO()), patch(
                "framework_lab.ollama_decision.native_choice", side_effect=fixture):
            for case in ("C2", "C4"):
                path = Path(tmp, case + ".json")
                self.assertEqual(main(["objects", case, "--ollama-s1", MODEL, "--output", str(path)]), 0)
                record = study.load(path)
                self.assertTrue(verify(record)["accepted"])
                if case == "C2":
                    for wire in record["wire"]:
                        body = wire["body"]
                        board = body["state"]["observation"]["offense"]
                        criteria = body["questions"]["decision"]["criteria"]
                        moves = [json.loads(text) for text in criteria.values()]
                        self.assertIn({"action": "do_nothing", "args": {}}, moves)
                        self.assertEqual({(m["args"]["from_cell"], m["args"]["to_cell"])
                                          for m in moves if m["args"]},
                                         {(i, j) for i, n in enumerate(board) if n
                                          for j in range(9) if i != j})
                tampered = deepcopy(record)
                tampered["wire"][0]["selected_option"] = "changed"
                with self.assertRaises(ValueError):
                    verify(tampered)

    def test_four_arm_workflow_and_tampered_replay(self):
        with TemporaryDirectory() as tmp:
            out = Path(tmp, "receipts")
            summary = study.run(out, MODEL, "sample", transport=fixture)
            self.assertEqual(study.check(out), summary)
            self.assertEqual(len(study.load(out / "manifest.json")["assignments"]), 32)
            outcomes = set()
            for cell in summary["by_model"][MODEL].values():
                self.assertEqual((cell["accepted_first"], cell["vector_count"]), (8, 8))
                self.assertEqual(cell["mean_probabilities"], answer(
                    {"questions": {"decision": {"criteria": dict.fromkeys(WORDS)}}}
                )["answers"]["decision"]["probabilities"])
                outcomes.update(cell["guess_counts"])
            self.assertEqual(outcomes, {WORDS[0], WORDS[-1]})
            path = out / "trial-001.json"
            record = study.load(path)
            criteria = record["wire"][0]["body"]["questions"]["decision"]["criteria"]
            first = next(iter(criteria))
            criteria[first] = criteria.pop(first)
            study.save(path, record)
            with self.assertRaisesRegex(ValueError, "trial-001"):
                study.check(out)

    def test_partial_sweep_accounts_for_missing_assignments(self):
        with TemporaryDirectory() as tmp:
            out = Path(tmp, "receipts")
            result = study.run(out, MODEL, transport=lambda _: {"status": 401, "response": "{}"})
            cells = result["by_model"][MODEL].values()
            self.assertEqual(sum(c["service_failure"] for c in cells), 1)
            self.assertEqual(sum(c["not_started_or_unrecorded"] for c in cells), 31)
            self.assertTrue(all(c["mean_probabilities"] is None for c in cells))


class NativeDecisionTests(unittest.TestCase):
    def test_native_choice_preserves_full_menu_and_replays_without_credentials(self):
        model = "test-native:fixture"

        def fixture(body):
            question = body["questions"]["decision"]
            self.assertEqual(question["criteria"], dict.fromkeys(study.WORDS))
            self.assertEqual(body["state"]["observation"], {"fragment": "fire"})
            probs = {w: float(w == "firework") for w in question["criteria"]}
            answer = {"type": "choice", "choice": "firework", "probabilities": probs, "confidence": 1}
            return {"status": 200, "response": json.dumps({"model": model, "answers": {"decision": answer}})}

        provider = OllamaDecision(model, selection="sample", seed=4, transport=fixture)
        run = lambda p: study.execute({"id": "trial", "fragment": "fire"}, p)
        trace = run(provider)
        self.assertEqual(trace["result"]["guess"], "firework")
        self.assertEqual(provider.identity()["provider"], "local_ollama_systemone")
        self.assertEqual(replay(provider.identity(), provider.wire, run), trace)

import json
import unittest
from importlib import import_module

from framework_lab.__main__ import CANDIDATES
from framework_lab.domain import DEFENSE, OFFENSE, WORDS, settings, yards

HOLD = '{"action":"do_nothing","args":{}}'


def word(text):
    return json.dumps({"action": "choose_word", "args": {"word": text}})


class CommonBoundaryTests(unittest.TestCase):
    def test_visibility_includes_schema_and_retry(self):
        for candidate in CANDIDATES:
            run = import_module("framework_lab." + candidate).run
            def football(defense):
                return run("C2", lambda _: "{}", {"defense": defense})["decisions"]
            self.assertEqual(football(list(DEFENSE)), football(list(reversed(DEFENSE))))
            def receiver(target):
                return run("C4", lambda req: word(target) if req["role"] == "A" else "{}",
                           {"arms": ["elide_second"]})["decisions"][1]
            a, b = receiver("firewood"), receiver("firework")
            self.assertEqual(a, b)
            self.assertEqual(a["status"], "exhausted")
            self.assertEqual(len(a["attempts"]), 2)

    def test_legal_miss_is_final_and_exhaustion_stops(self):
        for candidate in CANDIDATES:
            run = import_module("framework_lab." + candidate).run
            c4 = run("C4", lambda _: word("firewood"), {"assigned_word": "baseline"})
            self.assertIs(c4["result"]["calibration"], False)
            self.assertEqual(len(c4["decisions"][0]["attempts"]), 1)
            for bad in (
                '{"action":"move_person","args":{"from_cell":true,"to_cell":3}}',
                '{"action":"do_nothing","action":"do_nothing","args":{}}',
                '{"action":"move_person","args":{"from_cell":1.0,"to_cell":3}}',
                '{"action":"move_person","args":{"from_cell":2,"to_cell":3}}',
                '{"action":"do_nothing","args":{"extra":0}}'):
                with self.subTest(candidate=candidate, bad=bad):
                    trace = run("C2", lambda _: bad)
                    self.assertEqual(len(trace["decisions"]), 1)
                    self.assertEqual(trace["decisions"][0]["status"], "exhausted")
                    self.assertIsNone(trace["result"]["score"])
                    self.assertEqual(trace["result"]["plays"], [])

    def test_offline_window_rescoring_has_no_policy_calls(self):
        for candidate in CANDIDATES:
            cfg = {"horizon": 5, "shocks": [-100.0, -100.0, -100.0, -100.0, 100.0]}
            trace = import_module("framework_lab." + candidate).run("C2", lambda _: HOLD, cfg)
            gains = [r["yards"] for r in trace["result"]["plays"]]
            self.assertEqual(gains, [0, 0, 0, 0, 10])
            self.assertEqual(trace["result"]["score"], 0.5)
            self.assertEqual(sum(gains), 10)
            self.assertEqual(len(trace["decisions"]), 5)

    def test_words_and_transport_extremes(self):
        self.assertEqual(len(WORDS), 64)
        self.assertEqual(len(set(WORDS)), 64)
        self.assertTrue(all(len(w) == 8 and w.isascii() and w.islower() for w in WORDS))
        a, b = [5] + [0]*8, [6] + [0]*8
        self.assertEqual(yards(a, b, 0), 0)
        self.assertEqual(yards(a, b[::-1], 0), 10)
        self.assertEqual(yards(OFFENSE, DEFENSE, 0), 5.5)
        for cfg in ({"horizon": True}, {"offense": [False] + [0]*7 + [5]},
                    {"shocks": [0]*3}, {"seed": 1.0}, {"shocks": [float("nan")]*4}):
            with self.assertRaises(ValueError):
                settings("C2", cfg)


if __name__ == "__main__":
    unittest.main()

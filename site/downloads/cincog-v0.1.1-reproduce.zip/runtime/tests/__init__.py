"""Black-box qualification of installed public APIs."""

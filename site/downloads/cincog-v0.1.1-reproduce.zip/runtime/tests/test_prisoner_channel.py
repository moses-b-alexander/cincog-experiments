import json
import unittest

from framework_lab.objects import AsciiTextField
from studies.prisoner_channel import SEATS, run


def play(moves=("cooperate", "cooperate"), text="", deliver=True, order=SEATS, horizon=3):
    requests = {}

    def respond(request):
        seat = request["role"]
        turn = request["observation"]["round"]
        speaking = "history" in request["observation"] and not (
            {"sent", "received"} & request["observation"].keys())
        key = (seat, turn, speaking, request["attempt"])
        requests[key] = json.dumps(request)
        if speaking:
            message = text(request["attempt"]) if callable(text) else text
            return json.dumps({"action": "send", "args": {"text": message}})
        return json.dumps({"action": moves[SEATS.index(seat)], "args": {}})

    trace = run(dict.fromkeys(SEATS, respond), deliver=deliver, horizon=horizon, order=order)
    return trace, requests


class PrisonerChannelTests(unittest.TestCase):
    def test_private_moves_and_history_order(self):
        normal, inputs = play()
        reverse, reordered = play(order=SEATS[::-1])
        self.assertEqual(normal["result"], reverse["result"])
        self.assertEqual(inputs, reordered)
        _, changed = play(moves=("defect", "cooperate"))
        self.assertEqual(inputs["right", 1, False, 1], changed["right", 1, False, 1])
        self.assertNotEqual(inputs["right", 2, False, 1], changed["right", 2, False, 1])

    def test_payoffs(self):
        for left, right, points in [
            ("cooperate", "cooperate", (3, 3)), ("cooperate", "defect", (0, 5)),
            ("defect", "cooperate", (5, 0)), ("defect", "defect", (1, 1))]:
            trace, _ = play((left, right), horizon=1)
            self.assertEqual(trace["result"]["total_points"], dict(zip(SEATS, points)))

    def test_distinguishes_empty_from_withheld_and_hides_arm_from_sender(self):
        _, sent = play(horizon=1)
        _, withheld = play(horizon=1, deliver=False)
        self.assertEqual(json.loads(sent["right", 1, False, 1])["observation"]["received"], "")
        self.assertIsNone(json.loads(withheld["right", 1, False, 1])["observation"]["received"])
        self.assertEqual(sent["left", 1, False, 1], withheld["left", 1, False, 1])

    def test_retry_preserves_exact_text_and_exhaustion_has_no_payoff(self):
        trace, requests = play(text=lambda attempt: "x" * 17 if attempt == 1 else " " * 16)
        self.assertEqual(trace["result"]["rounds"][0]["sent"], " " * 16)
        self.assertEqual(len(trace["decisions"][0]["attempts"]), 2)
        failed, requests = play(moves=("missing", "defect"))
        self.assertIn(("right", 1, False, 1), requests)
        self.assertFalse(failed["result"]["complete"])
        self.assertIsNone(failed["result"]["rounds"][0]["payoffs"])
        self.assertIsNone(failed["result"]["total_points"])

    def test_decoded_message_bounds(self):
        field = AsciiTextField("text", 16)
        for value in ("", " ", "~" * 16, 'say "yes"'):
            self.assertTrue(field.accepts(value))
        for value in ("x" * 17, "end\n", "tab\t", "\x7f", "é", 1, None):
            self.assertFalse(field.accepts(value))

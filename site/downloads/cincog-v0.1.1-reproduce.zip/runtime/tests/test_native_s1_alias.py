"""Offline checks for parameter-only runtime aliases."""
import copy
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from scripts.c4_native_s1 import verify_evidence as audit
from studies import native_s1_sweep as sweep


def install(store, tag, params, *, projector="1"):
    raw = json.dumps(params).encode()
    param_hash = hashlib.sha256(raw).hexdigest()
    (store / "blobs").mkdir(exist_ok=True)
    (store / "blobs" / ("sha256-" + param_hash)).write_bytes(raw)
    layers = [{"mediaType": "application/vnd.ollama.image." + kind,
               "digest": "sha256:" + digit * 64, "size": 42, "from": tag}
              for kind, digit in (("projector", projector), ("model", "2"))]
    layers.append({"mediaType": sweep.PARAMS, "digest": "sha256:" + param_hash, "size": len(raw)})
    raw = json.dumps({"schemaVersion": 2, "config": {"digest": "sha256:" + "3" * 64},
                      "layers": layers}).encode()
    path = store / "manifests-v2/ollama.com/library" / Path(*tag.split(":"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    return {"tag": tag, "digest": hashlib.sha256(raw).hexdigest()}


class RuntimeAliasTests(unittest.TestCase):
    def test_source_and_alias_require_the_same_config_and_all_weights(self):
        source, tag = "original:fixture", "tuned:fixture"
        with TemporaryDirectory() as name:
            store = Path(name)
            bindings = {source: install(store, source, {"num_ctx": 4096})}
            with patch.object(sweep, "identity", side_effect=bindings.__getitem__):
                self.assertEqual(sweep.alias_binding(source, source, store=store), bindings[source])
                bindings[tag] = install(store, tag, {"num_ctx": 2048, "num_batch": 512})
                bound = sweep.alias_binding(source, tag, store=store)
                self.assertEqual(audit.verify_runtime(source, bound), (tag, 2048))
                self.assertEqual(len(bound["runtime_provenance"]["weight_layers"]), 2)
                for section, field in (("source", "manifest"), ("runtime", "parameter_blob")):
                    tampered = copy.deepcopy(bound)
                    tampered["runtime_provenance"][section][field] += " "
                    with self.assertRaises(ValueError):
                        audit.verify_runtime(source, tampered)
                tampered = copy.deepcopy(bound)
                tampered["runtime_provenance"]["weight_layers"].pop()
                with self.assertRaises(ValueError):
                    audit.verify_runtime(source, tampered)
                for params, projector in (({"num_ctx": 2048, "temperature": 0.4}, "1"),
                                          ({"num_ctx": 2048}, "4"), ({"num_ctx": True}, "1")):
                    bindings[tag] = install(store, tag, params, projector=projector)
                    with self.assertRaises(ValueError):
                        sweep.alias_binding(source, tag, store=store)

    def test_verified_usage_and_runtime_identity(self):
        alias = "tuned:fixture"
        answer = {"choice": "a", "type": "choice", "confidence": 1, "probabilities": {"a": 1, "b": 0}}
        bound = {"runtime_provenance": {"runtime": {"parameters": {"num_ctx": 2048}}}}
        for n, good in ((12, True), (0, False), (2048, False), (2049, False), (True, False)):
            raw = json.dumps({"model": alias, "answers": {"decision": answer},
                              "usage": {"input_tokens": n, "output_tokens": 0}})
            if good:
                sweep.check_runtime_usage({"response": raw}, bound)
                self.assertEqual(audit.response_answer(raw, alias, ["a", "b"], 2048), answer)
                with self.assertRaises(ValueError):
                    audit.response_answer(raw, "original:fixture", ["a", "b"], 2048)
            else:
                with self.assertRaises(ValueError):
                    sweep.check_runtime_usage({"response": raw}, bound)
                with self.assertRaises(ValueError):
                    audit.response_answer(raw, alias, ["a", "b"], 2048)

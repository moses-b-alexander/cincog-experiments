"""Re-execute the published C2/C4 stimuli offline against each independent API.

Run from this directory: python qualify.py ../../examples/json_agents/evidence/records.zip
"""
from __future__ import annotations

import argparse
from collections import Counter
from hashlib import sha256
from importlib import import_module
import json
import math
from pathlib import Path
from zipfile import ZipFile

from framework_lab.__main__ import CANDIDATES

ORIGINAL = "25b9792154b566a517c5363a8375804396a8a46a416b9594c2c776231cdc903f"


def compare(actual, expected, at=""):
    if type(actual) is not type(expected):
        raise ValueError(f"{at}: types differ: {type(actual)} vs {type(expected)}")
    if isinstance(expected, dict):
        if actual.keys() != expected.keys():
            raise ValueError(f"{at}: keys differ")
        for k in expected:
            compare(actual[k], expected[k], f"{at}/{k}")
    elif isinstance(expected, list):
        if len(actual) != len(expected):
            raise ValueError(f"{at}: lengths differ")
        for i, (a, e) in enumerate(zip(actual, expected)):
            compare(a, e, f"{at}/{i}")
    elif isinstance(expected, float):
        if not math.isclose(actual, expected, rel_tol=0, abs_tol=1e-12):
            raise ValueError(f"{at}: {actual} != {expected}")
    elif actual != expected:
        raise ValueError(f"{at}: {actual!r} != {expected!r}")


def check_effect(current, original, at):
    for k in ("before", "after"):
        compare(current[k], original[k], f"{at}/{k}")
    compare(current["yards"], original["play"]["yards"], at + "/yards")


def replay(candidate, record, case):
    trial = record["trial"]
    src = [e for e in trial["events"] if e["id"].split("/", 1)[1].startswith(case + "/")]
    cfg = ({"assigned_word": src[0]["assigned"]["args"]["word"]} if case == "C4" else {
        "offense": record["spec"]["spatial"]["offense"],
        "defense": record["spec"]["spatial"]["defense"],
        "appearance": record["spec"]["spatial"]["defensive_appearance"],
        "assigned_qb": src[0]["assigned"], "seed": trial["world_seed"],
        "shocks": [p["play"]["sampling"]["standard_normal"] for p in trial["c2"]["plays"]],
    })
    tape = [json.loads(a["wire"])["message"]["content"] for e in src for a in e["attempts"]]
    seen = []
    def provider(request):
        seen.append(request)
        return tape[len(seen) - 1]
    trace = candidate.run(case, provider, cfg)
    path = f"{candidate.__name__}/{trial['id']}/{case}"
    compare(len(seen), len(tape), path + "/calls")
    compare(len(trace["decisions"]), len(src), path + "/decisions")
    for out, original in zip(trace["decisions"], src):
        key = original["id"].split("/", 1)[1]
        compare(out["id"], key, path + "/id")
        compare(out["status"], original["status"], key)
        compare(out["action"], original["command"], key)
        compare(len(out["attempts"]), len(original["attempts"]), key)
        for attempt, old in zip(out["attempts"], original["attempts"]):
            compare(attempt["raw"], json.loads(old["wire"])["message"]["content"], key)
            compare(attempt["request"]["observation"], original["view"], key + "/view")
            old_prompt = json.loads(json.loads(old["request"])["messages"][1]["content"])
            compare(attempt["request"]["objective"], old_prompt["objective"], key + "/objective")
    result = trace["result"]
    compare(result["calibration"], trial[case.lower()]["calibration"], path + "/assignment")
    if case == "C4":
        compare(result["word"], src[1]["command"]["args"]["word"], path)
        compare(list(result["arms"]), list(trial["c4"]["arms"]), path + "/conditions")
        for i, (arm, saved) in enumerate(trial["c4"]["arms"].items(), 2):
            branch = result["arms"][arm]
            compare(branch["fragment"], saved["fragment"], path + "/delivery")
            compare(branch["guess"], src[i]["command"]["args"]["word"], path + "/guess")
            compare(branch["score"], saved["score"], path + "/recovery")
    else:
        check_effect(result["calibration_effect"], trial["c2"]["calibration_effect"], path + "/calibration")
        compare(result["score"], trial["c2"]["objective"], path + "/score")
        compare(len(result["plays"]), len(trial["c2"]["plays"]), path + "/plays")
        for i, (out, old) in enumerate(zip(result["plays"], trial["c2"]["plays"])):
            check_effect(out, old, f"{path}/plays/{i}")
    return len(seen)


def qualify(archive):
    if sha256(archive.read_bytes()).hexdigest() != ORIGINAL:
        raise ValueError("archive is not the published task 029 fixture")
    summary = {}
    with ZipFile(archive) as bundle:
        for name in CANDIDATES:
            counts = Counter()
            candidate = import_module("framework_lab." + name)
            for item in bundle.namelist():
                record = json.loads(bundle.read(item))
                for case in ("C4", "C2"):
                    counts[case + "_decisions"] += replay(candidate, record, case)
                    counts[case + "_trials"] += 1
            summary[name] = dict(counts)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    print(json.dumps(qualify(parser.parse_args().archive), indent=2))

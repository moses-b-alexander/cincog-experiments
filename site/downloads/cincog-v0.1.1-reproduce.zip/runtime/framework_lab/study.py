"""Resolve, preview, execute and replay researcher-owned study modules."""
import argparse
from contextlib import ExitStack, contextmanager, nullcontext
from copy import deepcopy
import hashlib
from importlib import import_module, resources
import json
import math
import os
from pathlib import Path
from uuid import uuid4

from . import __version__
from .records import read_json
from .objects import Session
from .study_providers import live, provider_settings, replay_participant, same


def registry_entry(name, path):
    default = resources.files("framework_lab").joinpath("study_registry.json")
    with (resources.as_file(default) if path is None else nullcontext(Path(path))) as src:
        registry = read_json(src)
    if set(registry) != {"version", "studies"} or type(registry["version"]) is not int or registry["version"] != 1:
        raise ValueError("expected version 1 study registry")
    if not isinstance(registry["studies"], dict) or name not in registry["studies"]:
        raise ValueError(f"registry has no entry for {name!r}")
    return registry["studies"][name]


def resolve(name, entry, module):
    if not isinstance(entry, dict) or set(entry) - {"workflow", "version", "parameters", "assignments", "provider", "agents"}:
        raise ValueError("invalid registry entry fields")
    if entry.get("workflow") != "studies." + name or not isinstance(entry.get("version"), str) or not entry["version"]:
        raise ValueError("expected this study's module and a nonempty version string")
    parameters = entry.get("parameters", {})
    assignments = entry.get("assignments", [{}])
    overrides = entry.get("agents", {})
    if not isinstance(parameters, dict) or not isinstance(assignments, list) or not assignments or not isinstance(overrides, dict):
        raise ValueError("expected parameters, role overrides and a nonempty list of assignments")
    trials = []
    for i, patch in enumerate(assignments):
        if not isinstance(patch, dict):
            raise ValueError("each assignment must override a set of study parameters")
        settings = module.resolve(deepcopy({**parameters, **patch}))
        design = module.describe(deepcopy(settings))
        if not isinstance(settings, dict) or not isinstance(design, dict) or not {"state","roles","interventions","outcome"} <= design.keys():
            raise ValueError("study must resolve its settings and describe state, roles, interventions and outcome")
        roles = design["roles"]
        if not isinstance(roles, dict) or not roles or set(overrides) - roles.keys():
            raise ValueError("invalid study roles or agent overrides")
        streams = design.setdefault("streams", {"shared": list(roles)})
        if (not isinstance(streams, dict) or not streams
                or any(not isinstance(key, str) or not key or not isinstance(members, list) or not members
                       or len(set(members)) != len(members) for key, members in streams.items())
                or {role for members in streams.values() for role in members} != set(roles)):
            raise ValueError("participant streams must name the declared roles")
        agents = {}
        for role in roles:
            if not isinstance(role, str) or not role:
                raise ValueError("each role needs a nonempty name")
            cfg = provider_settings(overrides.get(role, entry.get("provider", {"kind":"first_legal"})), module)
            if "seed" in cfg:
                cfg["seed"] += i
            agents[role] = cfg
        trials.append({"id": f"{name}/{i+1}", "settings": settings, "design": design, "agents": agents})
    source = Path(module.__file__).read_bytes().replace(b"\r\n", b"\n")
    return {"name": name, "workflow": entry["workflow"], "version": entry["version"], "framework_version": __version__,
            "workflow_sha256": hashlib.sha256(source).hexdigest(), "entry": deepcopy(entry),
            "protocol": {"attempt_limit": 2, "effect": "Only an admitted command may trigger a Session.perform effect.",
                         "seed_schedule": "base participant seed plus zero-based assignment index"},
            "assignments": trials}


def measurement(numerator, observed, planned):
    if (type(numerator) not in (int, float) or not math.isfinite(numerator)
            or type(observed) is not int or type(planned) is not int or not 0 <= observed <= planned
            or observed == 0 and numerator != 0):
        raise ValueError("invalid measurement numerator or denominators")
    return {"numerator": numerator, "observed": observed, "planned": planned,
            "missing": planned - observed, "value": numerator / observed if observed else None}


class StudySession(Session):
    """A session can route turns to fresh participants without exposing the condition label."""

    def __init__(self, dispatch, streams):
        self.current_stream = "shared"
        self.streams = streams
        super().__init__(lambda request: dispatch(self.current_stream, request))

    @contextmanager
    def stream(self, name):
        if name not in self.streams:
            raise ValueError(f"unknown participant stream {name!r}")
        previous, self.current_stream = self.current_stream, name
        try:
            yield
        finally:
            self.current_stream = previous


def execute_trial(module, trial, archived=None):
    specs = trial["agents"]
    streams = trial["design"]["streams"]
    participants = {}
    unexpected_role = []

    def dispatch(stream, request):
        role = request["role"]
        if (stream, role) not in participants:
            unexpected_role.append((stream, role))
            raise ValueError(f"undeclared role {role!r}")
        return participants[stream, role](request)

    def play():
        session = StudySession(dispatch, streams)
        result = module.run(session, deepcopy(trial["settings"]))
        if unexpected_role or not isinstance(result, dict):
            raise ValueError(f"workflow returned invalid data or used undeclared roles {unexpected_role!r}")
        return session.trace(result)

    if archived is None:
        participants.update({(stream, role): live(specs[role], module)
                             for stream, roles in streams.items() for role in roles})
        trace = play()
        wire = {stream: {role: participants[stream, role].wire for role in roles}
                for stream, roles in streams.items()}
    else:
        wire = archived["receipts"]
        if (not isinstance(wire, dict) or set(wire) != set(streams)
                or any(not isinstance(wire[key], dict) or set(wire[key]) != set(roles)
                       or any(not isinstance(wire[key][role], list)
                              or any(not isinstance(row, dict) for row in wire[key][role]) for role in roles)
                       for key, roles in streams.items())):
            raise ValueError("unexpected roles or receipts in trial")
        with ExitStack() as replay:
            for stream, roles in streams.items():
                for role in roles:
                    participant = replay_participant(specs[role], wire[stream][role])
                    participants[stream, role] = replay.enter_context(participant)
            trace = play()
    raw = module.measure(deepcopy(trace["result"]), deepcopy(trial["settings"]))
    if not isinstance(raw, dict) or not raw:
        raise ValueError("study needs at least one named measurement")
    metrics = {k: measurement(**v) for k, v in raw.items()}
    return {"id": trial["id"], **trace, "receipts": wire, "metrics": metrics}


def bundle(plan, module, saved=None):
    if saved is not None and (not isinstance(saved, list) or len(saved) != len(plan["assignments"])
                              or any(not isinstance(trial, dict) for trial in saved)):
        raise ValueError("saved trials differ from the assignment schedule")
    trials = [execute_trial(module, t, None if saved is None else saved[i]) for i,t in enumerate(plan["assignments"])]
    names = dict.fromkeys(name for trial in trials for name in trial["metrics"])
    summary = {}
    for name in names:
        rows = [t["metrics"][name] for t in trials if name in t["metrics"]]
        summary[name] = measurement(math.fsum(r["numerator"] for r in rows),
                                    sum(r["observed"] for r in rows), sum(r["planned"] for r in rows))
    return {"format": "cincog.study.v1", "config": plan, "trials": trials, "summary": summary}


def main(name, argv=None):
    parser = argparse.ArgumentParser(prog="python -m studies." + name)
    parser.add_argument("operation", nargs="?", choices=("preview","run","replay"), default="run")
    parser.add_argument("record", nargs="?", type=Path)
    parser.add_argument("--registry", type=Path, help="local JSON registry (or CINCOG_REGISTRY)")
    parser.add_argument("--output", type=Path, help="new JSON run record (default runs/<name>-<id>.json)")
    args = parser.parse_args(argv)
    if not name.isidentifier() or name.startswith("_"):
        parser.error("invalid study name")
    try:
        module = import_module("studies." + name)
        if args.operation == "replay":
            if not args.record or args.output or args.registry:
                raise ValueError("replay takes a saved record and uses its own configuration")
            archived = read_json(args.record)
            if archived.get("format") != "cincog.study.v1":
                raise ValueError("unknown study record format")
            if not isinstance(archived.get("trials"), list):
                raise ValueError("replay requires a list of recorded trials")
            plan = resolve(name, archived["config"]["entry"], module)
            if not same(plan, archived["config"]):
                raise ValueError("resolved study or installed workflow differs from the record")
            replayed = bundle(plan, module, archived["trials"])
            if not same(replayed, archived):
                raise ValueError("saved decisions, results or summary differ from offline replay")
            output = {"replayed": len(replayed["trials"]), "summary": replayed["summary"]}
        else:
            if args.record or (args.operation == "preview" and args.output):
                raise ValueError("preview takes no output path; use run --output FILE to save")
            entry = registry_entry(name, args.registry or os.environ.get("CINCOG_REGISTRY"))
            plan = resolve(name, entry, module)
            if args.operation == "preview":
                output = plan
            else:
                path = args.output or Path("runs", f"{name}-{uuid4().hex}.json")
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("x", encoding="utf-8") as stream:
                    try:
                        data = bundle(plan, module)
                        json.dump(data, stream, allow_nan=False, indent=2)
                        stream.write("\n")
                        stream.flush()
                    except BaseException:
                        stream.close()
                        path.unlink(missing_ok=True)
                        raise
                output = {"record": str(path.resolve()), "trials": [t["id"] for t in data["trials"]], "summary": data["summary"]}
        print(json.dumps(output, allow_nan=False, indent=2))
        return 0
    except (OSError, ValueError, TypeError, KeyError, AttributeError, EOFError, ImportError) as exc:
        parser.exit(2, f"{parser.prog}: {exc}\n")

"""Public objects for experiment-authored, synchronous agent decisions."""

from __future__ import annotations

import json
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping


Scalar = str | int | bool
Provider = Callable[[dict], str]


@dataclass(frozen=True)
class Field:
    """A named choice from a finite public set of same-type scalar values."""

    name: str
    choices: tuple[Scalar, ...]

    def __post_init__(self):
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("field name must be a nonempty string")
        object.__setattr__(self, "choices", tuple(self.choices))
        if not self.choices or type(self.choices[0]) not in (str, int, bool):
            raise ValueError("choices must be nonempty strings, integers, or booleans")
        if any(type(x) is not type(self.choices[0]) for x in self.choices):
            raise ValueError("choices must share one scalar type")
        if len(set(self.choices)) != len(self.choices):
            raise ValueError("choices must be unique")

    def accepts(self, value):
        return type(value) is type(self.choices[0]) and value in self.choices

    def schema(self):
        names = {str: "string", int: "integer", bool: "boolean"}
        return {"type": names[type(self.choices[0])], "enum": list(self.choices)}


def _record(properties):
    return {"type": "object", "properties": properties,
            "required": list(properties), "additionalProperties": False}


@dataclass(frozen=True)
class AsciiTextField:
    """A bounded, freely composed message. Spaces count; the empty string is valid."""

    name: str
    max_length: int

    def __post_init__(self):
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("field name must be a nonempty string")
        if type(self.max_length) is not int or self.max_length < 0:
            raise ValueError("expected nonnegative integer max_length")

    def accepts(self, value):
        return (type(value) is str and len(value) <= self.max_length
                and all(" " <= ch <= "~" for ch in value))

    def schema(self):
        # 'not' also rules out a final newline in regex implementations where $
        # can match immediately before one. The host checks every decoded character.
        return {"type": "string", "maxLength": self.max_length, "pattern": "^[ -~]*$",
                "not": {"pattern": "[^ -~]"}}


@dataclass(frozen=True)
class Form:
    """A wire action and its exact argument signature."""

    name: str
    fields: tuple[Field | AsciiTextField, ...] = ()

    def __post_init__(self):
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("action name must be a nonempty string")
        object.__setattr__(self, "fields", tuple(self.fields))
        if len({f.name for f in self.fields}) != len(self.fields):
            raise ValueError("duplicate field names")

    def schema(self):
        return _record({"action": {"const": self.name},
                        "args": _record({f.name: f.schema() for f in self.fields})})

    def accepts(self, reply):
        if type(reply) is not dict or reply.keys() != {"action", "args"}:
            return False
        args = reply["args"]
        return (reply["action"] == self.name and type(args) is dict
                and args.keys() == {f.name for f in self.fields}
                and all(f.accepts(args[f.name]) for f in self.fields))


@dataclass(frozen=True)
class View:
    role: str
    observation: Mapping[str, Any]
    objective: Mapping[str, Any]
    instruction: str


@dataclass(frozen=True)
class Command:
    """Admitted command. Immutable scalar pairs can be unpacked with as_dict()."""

    name: str
    arguments: tuple[tuple[str, Scalar], ...]

    def as_dict(self):
        return {"action": self.name, "args": dict(self.arguments)}


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def _invalid(token):
    raise ValueError(f"non-JSON constant {token}")


@dataclass(frozen=True)
class Decision:
    view: View
    forms: tuple[Form, ...]
    legal: Callable[[Command], bool] = field(default=lambda command: True)

    def __post_init__(self):
        object.__setattr__(self, "forms", tuple(self.forms))

    def request(self):
        v = self.view
        if not self.forms:
            raise ValueError("a decision needs a public command form")
        return deepcopy({"role": v.role, "observation": dict(v.observation),
                         "objective": dict(v.objective), "instruction": v.instruction,
                         "schema": {"anyOf": [form.schema() for form in self.forms]}})

    def admit(self, raw: str):
        if type(raw) is not str:
            return None
        try:
            reply = json.loads(raw, object_pairs_hook=_unique, parse_constant=_invalid)
        except (ValueError, RecursionError):
            return None
        if not any(form.accepts(reply) for form in self.forms):
            return None
        command = Command(reply["action"], tuple(reply["args"].items()))
        return command if self.legal(command) else None


class UnsupportedDecision(ValueError):
    """A provider cannot score this form. No action was requested."""

    has_preflight_receipt = False


class Session:
    """Owns transport and evidence only. The caller owns time and world state."""

    def __init__(self, provider: Provider):
        self._provider = provider
        self._decisions = []
        self._used_ids = set()

    def perform(self, decision_id: str, decision: Decision, effect: Callable[[Command], Any]):
        """Bind an author-selected effect to this actor's turn before admission."""
        command = self.ask(decision_id, decision)
        return None if command is None else effect(command)

    def ask(self, decision_id: str, decision: Decision) -> Command | None:
        if decision_id in self._used_ids:
            raise ValueError(f"decision id already used in this session: {decision_id}")
        request = decision.request()
        self._used_ids.add(decision_id)
        entry = {"id": decision_id, "status": "exhausted", "attempts": [], "action": None}
        self._decisions.append(entry)
        for attempt in (1, 2):
            sent = deepcopy(request)
            sent["attempt"] = attempt
            record = {"request": deepcopy(sent), "raw": None}
            try:
                raw = self._provider(sent)
            except UnsupportedDecision as exc:
                entry.update(status="unsupported_form", request=request, error=str(exc))
                if exc.has_preflight_receipt:
                    entry["provider_preflight"] = True
                return None
            except Exception as exc:
                record["error"] = type(exc).__name__
                entry["attempts"].append(record)
                entry["status"] = "service_failure"
                return None
            entry["attempts"].append(record)
            if type(raw) is str:
                record["raw"] = raw
            else:
                record["error"] = "provider returned non-text"
            command = decision.admit(raw)
            if command is not None:
                entry.update(status="accepted", action=command.as_dict())
                return command
            record.setdefault("error", "action failed form or legality checks")
        return None

    def trace(self, result: dict) -> dict:
        return deepcopy({"decisions": self._decisions, "result": result})

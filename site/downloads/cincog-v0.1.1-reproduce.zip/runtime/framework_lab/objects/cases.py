"""Two experiments authored with ordinary Python branches and loops."""

from copy import deepcopy
from math import fsum

from framework_lab import domain

from .core import Command, Decision, Field, Form, Session, View


def _objective(metric, horizon):
    return {"metric": metric, "direction": "maximize", "horizon": horizon}


def _word_decision(role, fragment=None, assigned=None):
    observation = {"role": role}
    if role == "C":
        observation["fragment"] = fragment
    instruction = ("A chooses one eight-letter word. C sees the whole word, its first four "
                   "letters, or its last four letters and chooses a word from the same bank. "
                   "Recovery succeeds when both choices match exactly.")
    objective = _objective("exact_recovery", 1)
    if assigned is not None:
        instruction += f" Calibration: choose the assigned word {assigned}."
        objective = _objective("exact_assigned_action", 1)
    return Decision(View(role, observation, objective, instruction),
                    (Form("choose_word", (Field("word", tuple(domain.WORDS)),)),))


def _word(command):
    return dict(command.arguments)["word"] if command is not None else None


def word_channel(session, config):
    calibration = None
    if "assigned_word" in config:
        assigned = config["assigned_word"]
        choice = session.ask("C4/calibration", _word_decision("A", assigned=assigned))
        if choice is not None:
            calibration = _word(choice) == assigned
    word = _word(session.ask("C4/A", _word_decision("A")))
    arms = {}
    for arm in config["arms"]:
        fragment = guess = None
        if word is not None:
            fragment = {"whole": word, "elide_first": word[4:], "elide_second": word[:4]}[arm]
            guess = _word(session.ask(f"C4/C/{arm}", _word_decision("C", fragment)))
        arms[arm] = {"fragment": fragment, "guess": guess,
                     "score": guess == word if guess is not None else None}
    return {"word": word, "arms": arms, "calibration": calibration}


def _qb_decision(config, play, history, assigned=None):
    before = config["offense"]
    forms = [Form("do_nothing")]
    for source, count in enumerate(before):
        if count:
            destinations = tuple(i for i in range(len(before)) if i != source)
            forms.append(Form("move_person", (Field("from_cell", (source,)),
                                              Field("to_cell", destinations))))
    observation = {"role": "QB", "offense": list(before),
                   "defensive_appearance": list(config["appearance"]),
                   "play": play, "last_three_yards": list(history[-3:])}
    instruction = domain.C2_RULES
    objective = _objective("fraction_of_four_play_windows_at_least_10_yards", config["horizon"])
    if assigned is not None:
        instruction += f" Calibration: choose {assigned['action']} with arguments {assigned['args']}."
        objective = _objective("exact_assigned_action", 1)
    else:
        instruction += (" Maximize the fraction of consecutive four-play windows totaling "
                        "at least ten yards.")
    return Decision(View("QB", observation, objective, instruction), tuple(forms))


def apply_qb(before, command: Command):
    after = list(before)
    if command.name == "move_person":
        args = dict(command.arguments)
        after[args["from_cell"]] -= 1
        after[args["to_cell"]] += 1
    return after


def resolve_play(config, play, choice):
    before = config["offense"]
    after = apply_qb(before, choice)
    z = (domain.shock(config["seed"], play) if config["shocks"] is None
         else config["shocks"][play - 1])
    return {"before": list(before), "after": after, "yards": domain.yards(after, config["defense"], z),
            "defense": list(config["defense"]), "shock": z, "action": choice.as_dict()}


def possession(session, config, *, prefix="C2"):
    calibration = calibration_effect = None
    if "assigned_qb" in config:
        assigned = config["assigned_qb"]
        calibration_effect = session.perform(f"{prefix}/calibration", _qb_decision(config, 1, [], assigned),
                                             lambda choice: resolve_play(config, 1, choice))
        if calibration_effect is not None:
            calibration = calibration_effect["action"] == assigned
    plays, history = [], []
    score = None
    for play in range(1, config["horizon"] + 1):
        outcome = session.perform(f"{prefix}/free/{play}", _qb_decision(config, play, history),
                                  lambda choice: resolve_play(config, play, choice))
        if outcome is None:
            break
        history.append(outcome["yards"])
        plays.append(outcome)
    else:
        windows = [fsum(history[i:i + 4]) >= 10 for i in range(len(history) - 3)]
        score = sum(windows) / len(windows)
    return {"plays": plays, "score": score, "calibration": calibration,
            "calibration_effect": calibration_effect}


def run(case, provider, config=None):
    config = domain.settings(case, config)
    conditions = deepcopy(config)
    session = Session(provider)
    experiment = {"C2": possession, "C4": word_channel}[case]
    trace = session.trace(experiment(session, config))
    trace["conditions"] = conditions
    return trace

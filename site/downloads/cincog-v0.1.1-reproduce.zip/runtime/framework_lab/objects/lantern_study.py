"""Standalone author file. Run with the lab installed or on PYTHONPATH."""

import json

from framework_lab.objects import Decision, Form, Session, View


def trial(provider, goal):
    """One participant decides whether to spend a battery charge to light a trail."""
    if goal not in ("lit", "charge_left"):
        raise ValueError("unknown measurement")
    session = Session(provider)
    view = View("keeper", {"role": "keeper", "charge": 1},
                {"metric": goal, "direction": "maximize", "horizon": 1},
                "Lighting the trail uses the one battery charge. Waiting saves it.")
    turn = Decision(view, (Form("light"), Form("wait")))

    def use_battery(command):
        lit = command.name == "light"
        return {"lit": lit, "charge_left": int(not lit)}

    event = session.perform("trail/keeper/1", turn, use_battery)
    return session.trace({"event": event})


def measure(trace, metric):
    event = trace["result"]["event"]
    return None if event is None else int(event[metric])


def experiment():
    calls = []

    def participant(request):
        metric = request["objective"]["metric"]
        calls.append(metric)
        return json.dumps({"action": "light" if metric == "lit" else "wait", "args": {}})

    light_trial = trial(participant, "lit")
    archived_scores = [measure(light_trial, name) for name in ("lit", "charge_left")]
    assert archived_scores == [1, 0] and calls == ["lit"]
    reserve_trial = trial(participant, "charge_left")
    assert measure(reserve_trial, "charge_left") == 1 and calls == ["lit", "charge_left"]
    return {"original_event": light_trial["result"]["event"], "offline_scores": archived_scores,
            "new_event": reserve_trial["result"]["event"], "participant_calls": calls}


if __name__ == "__main__":
    print(json.dumps(experiment(), indent=2))

# Author an experiment with decision objects

In your own Python file, import the public objects from `framework_lab.objects`.
Own the state, turns and scoring in an ordinary function. Create a `Session(provider)`
for a trial. For each turn, construct a `View(role, observation, objective, instruction)`
from information that participant can see. Declare a tuple of `Form` objects using
`Field(name, choices)` for arguments with finite string, integer or boolean choices.
The forms drive both the public schema and the exact wire checks. Use multiple
forms with the same action name for correlated argument choices.

```python
from framework_lab.objects import Decision, Form, Session, View

def lantern(provider, charged):
    session = Session(provider)
    view = View("keeper", {"role": "keeper"}, {"metric": "light"},
                "Choose light or wait.")
    turn = Decision(view, (Form("light"), Form("wait")),
                    legal=lambda command: charged or command.name == "wait")
    choice = session.ask("lantern/keeper", turn)
    lit = choice.name == "light" if choice is not None else None
    return session.trace({"lit": lit})
```

The provider accepts one request dictionary and returns JSON text. A private
legality predicate can check hidden state without changing the schema. Rejection
can itself reveal information on retry. Keep the predicate pure and stable for
the duration of a decision. `ask` returns an immutable admitted command or
`None` on exhaustion or service failure. Inspect the decision status to distinguish
these outcomes. Only the experiment applies effects and computes measurements.
`trace(result)` returns a detached snapshot with the raw attempts and actions.

The two comparison cases use `run("C2" or "C4", provider, config)`. Custom
experiments can call their own functions directly. To run them by name and
persist a resolved plan, expose a trusted `studies.<name>` module and a local
JSON registry entry. The repository's `docs/registered-studies.md` gives the
author protocol and an independently installable example.
This synchronous API supports named actions with a flat record of finite scalar
arguments. Branch cloning, agent memory, streaming and persistence are the
author's responsibility. JSON Schema treats integral decimal numbers as integers,
so admission additionally enforces strict JSON scalar representation.

For a physical effect, call `session.perform(turn_id, decision, effect)`.
This binds one actor's request to the supplied effect before the provider runs.
Only an admitted reply invokes the effect, and reusing a turn ID raises an error
in that session, including after a failed decision. An effect that raises may
have partially changed author state. Model effects as pure transformations when
you need all-or-nothing updates. This is a synchronous in-process API for trusted
experiment code. The provider receives copied request data. Python code with
independent access to the experiment can still mutate its state.
Each call supplies a fresh request. The host controls the provider's internal
memory and conversation history. For independent branches, use a stateless
adapter or initialize a fresh conversation per call. The baseline trace stores
the private resolved settings in `conditions`, even if the provider fails before
any play resolves. Restrict access to full traces when observations are private.

`lantern_study.py` is a portable author file. Run it directly with the package
installed. It records a battery event, scores the same event for lighting and
saving charge, then runs a new trial with saving charge as the participant goal.
The recorded call count distinguishes the offline analysis from the rerun.

## Use a native Ollama decision participant

Pass an installed decision model to `OllamaDecision` and give it to the same
`Session` or baseline `run` used for any participant. The model receives the
role, observation and objective in `state`. The question carries the instructions
and the ordered menu. Its response reports a probability for every offered choice.

```python
from framework_lab.ollama_decision import OllamaDecision
from framework_lab.objects import run

participant = OllamaDecision("kev:0.8b-q8_0", selection="argmax")
trace = run("C2", participant)
record = {"binding": participant.identity(), **trace, "wire": participant.wire}
```

The installed baseline CLI writes the full trace. Replay and study scripts run
from the source study directory, `prototypes/framework_lab`.

```console
cincog-lab objects C2 --ollama-s1 kev:0.8b-q8_0 --output football.json
python replay_live.py football.json
python -m studies.distribution plan --ollama-s1 kev:0.8b-q8_0
python -m studies.distribution run --ollama-s1 kev:0.8b-q8_0 --selection sample --output native-c4
python -m studies.distribution check --output native-c4
```

The four-arm study schedules eight decisions per clue. Its summaries report
the mean probability for every word, how many vectors contributed, counts of
sampled or highest-probability choices and the number of failed or missing assignments.

The adapter expands each finite action form separately to preserve its argument
constraints. For C4, the word itself names the full command. For C2, each
option describes a complete typed JSON command, including the explicit hold.
A decision with an open-ended field requires an experiment-defined finite
menu or a participant that can supply free text.

The default policy uses the model's reported highest-probability selection,
including its handling of ties. `--selection sample` draws locally from the
weights in catalogue order. The baseline CLI's `--model-seed` and the study's
assignment seeds control the local draws. The raw reply, returned model tag,
probabilities, confidence, reported winner and played selection are recorded
separately. The local server must return the requested tag.

The adapter checks for duplicate keys, non-finite or out-of-range weights,
missing or extra options, a total more than 0.000001 from one and an inconsistent
winner. A malformed reply gets one retry. HTTP and connection failures are
recorded as service failures. Unreadable or non-UTF-8 bodies retain the available
status and non-UTF-8 bytes are stored in `response_base64`. A public form the
participant cannot enumerate records `unsupported_form` before any request.
A valid choice still passes through host admission and the experiment's private
legality predicate before it can affect the game.

Interpret mean probabilities alongside the counts of planned assignments and
accepted vectors. Individual responses distinguish repeated uncertainty from
variation across decisive answers. A private host veto can leave valid native
vectors in the trace of a decision that produced no admitted action.

## Score a tool list

Save the role's public information and legal tools in a JSON file. Both scored participants accept this format. The following decision works as a complete spec.

```json
{
  "role": "keeper",
  "observation": {"lamp": "off"},
  "objective": {"metric": "light"},
  "instruction": "Choose whether to turn the lamp on.",
  "tools": [
    {"type": "function", "function": {"name": "switch", "parameters": {
      "type": "object", "properties": {"on": {"type": "boolean", "enum": [true, false]}},
      "required": ["on"], "additionalProperties": false
    }}}
  ],
  "display": {"top_k": 2}
}
```

Each function declares a closed object of required finite string, integer or boolean arguments. A tool may take no arguments. Use distinct forms of the same tool for correlated choices. Function and argument descriptions are optional and reach the participant. The author supplies only the role-visible observation, objective and instruction. In Python the same adapters accept any supported `Decision` through `Session.ask`, including decisions constructed during play.

Save the [three-strategy B example](elision-choice.json) as `elision-choice.json`, or supply your own spec. The example asks B for one elision choice. To measure its consequences, a study must apply the strategy to the word, deliver the resulting clue and obtain C's response.

```console
cincog-lab score elision-choice.json --ollama-s1 kev:0.8b-q8_0 --show "show me the top 10 choices" --output kev.json
cincog-lab score elision-choice.json --llama-model phi4-mini:3.8b --llama-port 8080 --show "show me choices with cumulative up to 60%" --output phi.json
cincog-lab show phi.json --show "cover 60%"
cincog-lab replay phi.json
```

Kev requires a local Ollama service with its native System One endpoint and the named model installed. Phi requires a local llama.cpp server with the matching model alias, chat-template, tokenize and full pre-sampling probability endpoints. With the Ollama-distributed Windows build and installed Phi weights, start it in a separate PowerShell window. Set the port to an available loopback port and use the same port with `score`.

```powershell
$runner = Join-Path (Split-Path (Get-Command ollama).Source) 'lib\ollama\llama-server.exe'
$weights = ((ollama show phi4-mini:3.8b --modelfile | Select-String '^FROM ' | Select-Object -First 1).Line -replace '^FROM\s+', '').Trim('"')
& $runner -m $weights --alias phi4-mini:3.8b --host 127.0.0.1 --port 8080 -c 2048 -np 1
```

### Read the probabilities

Kev returns native weights over its offered menu. Phi receives a list of decimal codes paired with legal typed commands. The adapter applies the loaded model's chat template and verifies that every code adds one distinct token to the exact answer prefix. It takes one next-token readout across the vocabulary and calculates `P(code) / sum(P(offered codes))`. Phi supplies no written confidence, explanation or probability. The response includes the raw vocabulary mass of the offered codes as `menu_mass`. A high conditional score can accompany a small raw menu mass. Code assignments and ordering are part of the experimental stimulus. Preserve them for matched comparisons.

The adapters return the same ranked row format with an option, its typed command and its probability. Each attempt records the source of the scores, the selection played, whether it was admitted, and the shown and omitted mass. A private veto can reject a scored attempt. Failed calls carry a status and no probabilities. An open field, insufficient slot context or a code that splits across tokens can make a readout unsupported. Tokenizer preflight retains its local service receipts and requires zero completions. The Phi record includes the template fingerprint, server build, model alias and metadata. If the weight filename is an Ollama content digest, that name is recorded. For a plain GGUF path, authors should record the weight checksum alongside their study.

### Choose how much to show

| Researcher request | CLI option | Result |
|---|---|---|
| “show me the top 10 choices” | `--top-k 10` | At most ten rows, sorted by probability. |
| “show me choices with cumulative up to 60%” | `--top-k-prob .60` | The longest ranked prefix whose total stays at or below .60. It can be empty. |
| “cover 60%” | `--cover-prob .60` | The shortest ranked prefix reaching .60, including the crossing choice. |

Use a supported phrase with `--show`, explicit flags, or an optional spec `display` object with `top_k`, `top_k_prob` or `cover_prob`. Explicit flags replace the spec or saved display settings. A count may cap either cumulative view. When the count prevents coverage, `coverage_met` is false. Ties display in menu order. A study may separately choose `--selection sample --model-seed 19` for a seeded draw from the complete vector, or use the default argmax.

The display preserves each original probability and the complete evidence. Change it after a run with `show`, which verifies the raw receipts offline before ranking. A lower display threshold saves reading time. Phi still scores the entire menu and obtains the same vocabulary readout. Measure latency separately if speed is part of the hypothesis.

For models whose tokenizers split two-digit numbers, add `--codebook ascii64` to a `--llama-model` command (or pass `codebook="ascii64"` to `LlamaCppDecision`). It assigns the same ordered alphabet of 64 case-sensitive labels to every menu: A–Z, a–z, 0–9, ! and ?. Every label must extend the model’s actual answer prefix by one distinct token with the matching bytes. If the tokenizer combines the template’s final space with the next character, all labels must qualify at that shared boundary, including the space in their token bytes. The receipt records this condition. The checked codebook, including its order, is part of the stimulus. Report the raw offered-code mass alongside the conditional word probabilities when comparing checkpoints.

### Model-specific prompt edits

The normal ASCII64 scorer uses the versioned rules in `framework_lab.model_prompts` after llama.cpp renders the chat template and before it tokenizes the answer prefix. The first rule replaces the space after Baidu ERNIE-4.5-0.3B-PT’s final `Assistant:` with a newline. It checks the model dimensions, the original template fingerprint, and the exact final cue. Matching uses the reported Ollama content-addressed filename when present. For a plain GGUF, serve the model under `baidu-ernie-4.5-0.3b-pt` or `baidu/ERNIE-4.5-0.3B-PT`. Those aliases identify the participant as declared by the researcher.

The receipt retains the server’s original rendered text, the rule and outcome, and hashes of the rendered and effective prompts. The scorer still verifies every answer code at the effective prefix. A server using the previously qualified newline template records `already_compatible`. Use `--prompt-edits off` (or `prompt_edits="off"` in Python) for an original-template control. The Task 036 replication runner defaults to its historical control and accepts `--prompt-edits auto` for a fresh study directory.

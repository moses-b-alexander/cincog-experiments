"""External author example and targeted admission tests."""

import json
import unittest

from framework_lab.objects import Decision, Field, Form, Session, View


def lantern(provider, charged):
    """Third exercise. The charge is private and only admission may consult it."""
    view = View("keeper", {"role": "keeper"}, {"metric": "light"},
                "Choose light or wait.")
    decision = Decision(view, (Form("light"), Form("wait")),
                        legal=lambda command: command.name == "wait" or charged)
    session = Session(provider)
    choice = session.ask("lantern/keeper", decision)
    return session.trace({"lit": choice.name == "light" if choice else None})


class ObjectTests(unittest.TestCase):
    def test_malformed_author_names(self):
        with self.assertRaises(ValueError):
            Form(True)
        with self.assertRaises(ValueError):
            Field("", ("yes",))

    def test_failed_episodes_preserve_private_commitments(self):
        from framework_lab.objects import run
        def offline(request):
            raise ConnectionError
        a = [6] + [0] * 8
        b = a[::-1]
        first, second = [run("C2", offline, {"defense": defense}) for defense in (a, b)]
        self.assertEqual(first["decisions"], second["decisions"])
        self.assertEqual(first["conditions"]["defense"], a)
        self.assertEqual(second["conditions"]["defense"], b)
        a.clear()
        self.assertEqual(first["conditions"]["defense"][0], 6)

    def test_private_admission_and_effects(self):
        def provider(request):
            request["observation"]["role"] = "changed"
            return '{"action":"light","args":{}}'

        dark, lit = lantern(provider, False), lantern(provider, True)
        first_request = lambda trace: trace["decisions"][0]["attempts"][0]["request"]
        self.assertEqual(first_request(dark), first_request(lit))
        self.assertEqual(first_request(dark)["observation"], {"role": "keeper"})
        self.assertEqual(dark["decisions"][0]["status"], "exhausted")
        self.assertIsNone(dark["result"]["lit"])
        self.assertTrue(lit["result"]["lit"])

    def test_integer_wire_types_and_duplicate_keys(self):
        decision = Decision(View("x", {}, {}, ""), (Form("pick", (Field("n", (1, 2)),)),))
        for value in ("true", "1.0", "NaN", "3", '"1"', '1,"n":1'):
            with self.subTest(value=value):
                self.assertIsNone(decision.admit('{"action":"pick","args":{"n":' + value + '}}'))
        self.assertEqual(decision.admit('{"action":"pick","args":{"n":1}}').name, "pick")

    def test_retry_and_service_failure(self):
        responses = iter(["bad", '{"action":"wait","args":{}}'])
        result = lantern(lambda _: next(responses), False)
        entry = result["decisions"][0]
        self.assertEqual([a["raw"] for a in entry["attempts"]], ["bad", json.dumps(
            {"action": "wait", "args": {}}, separators=(",", ":"))])
        self.assertFalse(result["result"]["lit"])
        failed = lantern(lambda _: next(responses), True)["decisions"][0]
        self.assertEqual(failed["status"], "service_failure")
        self.assertEqual(len(failed["attempts"]), 1)
        self.assertIsNone(failed["action"])

    def test_effect_bound_once_per_turn_even_after_failure(self):
        effects = []
        session = Session(lambda request: '{"action":"wait","args":{}}')
        view = View("keeper", {}, {}, "")
        decision = Decision(view, (Form("wait"),))
        session.perform("lamp/1", decision, effects.append)
        with self.assertRaises(ValueError):
            session.perform("lamp/1", decision, effects.append)
        denied = Decision(view, (Form("wait"),), legal=lambda command: False)
        session.perform("lamp/2", denied, effects.append)
        self.assertEqual(len(effects), 1)

    def test_real_case_calibration_and_window_arithmetic(self):
        from framework_lab.objects import run
        from framework_lab import domain
        hold = {"action": "do_nothing", "args": {}}
        move = {"action": "move_person", "args": {"from_cell": 0, "to_cell": 1}}
        provider = lambda req: json.dumps(move if req["objective"]["metric"] == "exact_assigned_action" else hold)
        run_data = run("C2", provider, {"assigned_qb": hold, "shocks": [0] * 4})
        result = run_data["result"]
        self.assertIs(result["calibration"], False)
        self.assertEqual(result["calibration_effect"]["after"][:2], [1, 2])
        self.assertEqual(result["plays"][0]["after"], list(domain.OFFENSE))
        expected = domain.yards(domain.OFFENSE, domain.DEFENSE, 0)
        self.assertEqual([row["yards"] for row in result["plays"]], [expected] * 4)
        self.assertEqual(result["score"], float(4 * expected >= 10))

    def test_real_case_branch_channels(self):
        from framework_lab.objects import run
        from framework_lab.domain import WORDS
        word = WORDS[0]
        choose = lambda req: json.dumps({"action": "choose_word", "args": {"word": word}})
        result = run("C4", choose, {"assigned_word": WORDS[1]})["result"]
        self.assertIs(result["calibration"], False)
        self.assertEqual([arm["fragment"] for arm in result["arms"].values()],
                         [word, word[4:], word[:4]])
        self.assertTrue(all(arm["score"] for arm in result["arms"].values()))

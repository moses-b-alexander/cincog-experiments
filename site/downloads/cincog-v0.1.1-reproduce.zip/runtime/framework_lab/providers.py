"""Adapters usable with all three designs. Only deliberate local Ollama calls use the network."""

from __future__ import annotations

import json
import math
from urllib.request import Request, ProxyHandler, build_opener

def scripted(request: dict) -> str:
    """A transparent smoke-test policy. No hidden targets or arm identifiers are available."""
    obs = request["observation"]
    if request["role"] == "QB":
        reply = {"action": "do_nothing", "args": {}}
    else:
        from .domain import WORDS
        clue = obs.get("fragment", "firewood")
        word = next(w for w in WORDS if w.startswith(clue) or w.endswith(clue))
        reply = {"action": "choose_word", "args": {"word": word}}
    return json.dumps(reply)


class LocalOllama:
    def __init__(self, model: str, seed: int, *, temperature: float = 0):
        if type(temperature) not in (float, int) or not math.isfinite(temperature) or temperature < 0:
            raise ValueError("temperature must be finite and nonnegative")
        self.model = model
        self.seed = seed
        self.temperature = temperature
        self.wire = []
        self.http = build_opener(ProxyHandler({}))
        self.base = "http://127.0.0.1:11434"

    def _get(self, path):
        with self.http.open(self.base + path, timeout=10) as response:
            return json.load(response)

    def identity(self):
        models = self._get("/api/tags")["models"]
        item = next((m for m in models if m["name"] == self.model), None)
        if item is None:
            raise ValueError(f"model is not installed locally: {self.model}")
        return {"provider": "local_ollama", "model": self.model, "digest": item["digest"],
                "server": self._get("/api/version")["version"], "seed": self.seed,
                "temperature": self.temperature, "context": 8192, "output_tokens": 128}

    def body(self, request):
        prompt = {k: v for k, v in request.items() if k != "schema"}
        schema = request["schema"]
        return {"model": self.model, "stream": False, "format": schema,
                "options": {"seed": self.seed, "temperature": self.temperature, "num_ctx": 8192,
                            "num_predict": 128},
                "messages": [
                    {"role": "system", "content": "Return one JSON action matching this schema. "
                     + json.dumps(schema, separators=(",", ":"))},
                    {"role": "user", "content": json.dumps(prompt, separators=(",", ":"))}]}

    def content(self, response):
        envelope = json.loads(response)
        message = envelope["message"]
        if (envelope.get("done") is not True or envelope.get("model") != self.model
                or message.get("role") != "assistant" or message.get("tool_calls")
                or not isinstance(message.get("content"), str)):
            raise ValueError("unexpected provider envelope")
        return message["content"]

    def __call__(self, request):
        body = self.body(request)
        record = {"body": body}
        self.wire.append(record)
        call = Request(self.base + "/api/chat", data=json.dumps(body).encode(),
                       headers={"Content-Type": "application/json"})
        try:
            with self.http.open(call, timeout=150) as response:
                record["status"] = response.status
                record["response"] = response.read().decode("utf-8")
            return self.content(record["response"])
        except Exception as exc:
            record["error"] = f"{type(exc).__name__}: {exc}"
            raise

"""Offer finite action forms to a local Ollama System One participant and replay its native responses."""
import base64
from contextlib import contextmanager
from http.client import HTTPConnection, HTTPException
import json
import math
import random

from .choices import UnsupportedChoiceForm, action_catalog, select_option


def local_request(path, body=None, timeout=180):
    connection = HTTPConnection("127.0.0.1", 11434, timeout=timeout)
    try:
        if body is None:
            connection.request("GET", path)
        else:
            connection.request("POST", path, json.dumps(body).encode("utf8"),
                               {"Content-Type": "application/json"})
        response = connection.getresponse()
        try:
            data = response.read()
        except (OSError, HTTPException) as exc:
            return {"status": response.status, "transport_error": type(exc).__name__}
        try:
            return {"status": response.status, "response": data.decode("utf8")}
        except UnicodeDecodeError:
            return {"status": response.status, "response_base64": base64.b64encode(data).decode("ascii")}
    finally:
        connection.close()


def native_choice(body):
    try:
        return local_request("/v1/systemone", body)
    except (OSError, HTTPException) as exc:
        return {"transport_error": type(exc).__name__}


def _unique(pairs):
    result = dict(pairs)
    if len(result) != len(pairs):
        raise ValueError("duplicate response key")
    return result


def _invalid_number(token):
    raise ValueError(f"invalid JSON number {token}")


def _probability(value):
    return type(value) in (int, float) and 0 <= value <= 1


def _choice(raw, catalog, model):
    envelope = json.loads(raw, object_pairs_hook=_unique, parse_constant=_invalid_number)
    returned_model = envelope["model"]
    if not isinstance(returned_model, str) or not returned_model:
        raise ValueError("missing response model")
    if returned_model != model:
        raise ValueError("unexpected response model")
    answer = envelope["answers"]["decision"]
    probs = answer["probabilities"]
    if (answer["type"] != "choice" or not isinstance(probs, dict) or probs.keys() != catalog.keys()
            or not all(_probability(p) for p in probs.values())
            or not math.isclose(math.fsum(probs.values()), 1.0, rel_tol=0, abs_tol=1e-6)):
        raise ValueError("invalid choice probability distribution")
    if (answer["choice"] not in probs or probs[answer["choice"]] != max(probs.values())
            or not _probability(answer["confidence"])):
        raise ValueError("invalid reported choice or confidence")
    return returned_model, answer


class OllamaDecision:
    """Map a native Ollama choice distribution to a command for an object workflow."""

    def __init__(self, model, *, selection="argmax", seed=61101, transport=None):
        if not isinstance(model, str) or not model.strip():
            raise ValueError("supply a local Ollama decision model ID")
        if selection not in ("argmax", "sample") or type(seed) is not int:
            raise ValueError("expected argmax or sample selection and an integer seed")
        self.transport = native_choice if transport is None else transport
        self.model = model
        self.selection = selection
        self.seed = seed
        self.rng = random.Random(seed)
        self.wire = []

    def identity(self):
        return {"provider": "local_ollama_systemone", "model": self.model, "selection": self.selection,
                "selection_seed": self.seed if self.selection == "sample" else None}

    def criteria(self, catalog):
        # A word already identifies its command. Compound options also need their typed action and arguments.
        if (len({cmd["action"] for cmd in catalog.values()}) == 1
                and all(list(cmd["args"].values()) == [label] for label, cmd in catalog.items())):
            return dict.fromkeys(catalog)
        return {k: json.dumps(cmd, separators=(",", ":")) for k, cmd in catalog.items()}

    def __call__(self, request):
        catalog = action_catalog(request["schema"])
        body = {"model": self.model,
                "state": {k: request[k] for k in ("role", "observation", "objective")},
                "questions": {"decision": {"type": "choice", "instructions": request["instruction"],
                                          "criteria": self.criteria(catalog)}}}
        receipt = self.transport(body)
        wire = {"body": body, **receipt}
        self.wire.append(wire)
        if "transport_error" in receipt or receipt["status"] != 200:
            raise ConnectionError("local decision request failed; see the transport receipt")
        if "response_base64" in receipt:
            wire["invalid_response"] = "response is not UTF-8"
            return ""
        try:
            model, answer = _choice(receipt["response"], catalog, self.model)
        except (ValueError, TypeError, KeyError, RecursionError) as exc:
            wire["invalid_response"] = str(exc)
            return ""  # Session records an invalid attempt and applies its normal retry policy.
        selected = select_option(catalog, answer["probabilities"], answer["choice"], self.selection, self.rng)
        wire.update(resolved_model=model, reported_choice=answer["choice"], selected_option=selected,
                    probabilities=answer["probabilities"], confidence=answer["confidence"])
        return json.dumps(catalog[selected], separators=(",", ":"))


@contextmanager
def replaying(binding, wires):
    """Recreate a trace from the raw local decision receipts without model calls."""
    rows = iter(wires)
    mismatch = False

    def transport(body):
        nonlocal mismatch
        row = next(rows, None)
        # Order is an experimental input, including the order of the choice criteria.
        if row is None or json.dumps(body) != json.dumps(row["body"]):
            mismatch = True
            raise ValueError("local decision request differs from saved wire body")
        if "transport_error" in row:
            return {k: row[k] for k in ("transport_error", "status") if k in row}
        if "response_base64" in row:
            data = base64.b64decode(row["response_base64"], validate=True)
            try:
                raw = data.decode("utf-8")
            except UnicodeDecodeError:
                return {"status": row["status"], "response_base64": row["response_base64"]}
            return {"status": row["status"], "response": raw}
        return {"status": row["status"], "response": row["response"]}

    provider = OllamaDecision(binding["model"], selection=binding["selection"],
                              seed=binding["selection_seed"] if binding["selection"] == "sample" else 0,
                              transport=transport)
    if binding != provider.identity():
        raise ValueError("invalid local decision binding")
    yield provider
    if (mismatch or next(rows, None) is not None
            or json.dumps(provider.wire, sort_keys=True) != json.dumps(wires, sort_keys=True)):
        raise ValueError("local decision replay differs from transport evidence")


def replay(binding, wires, run):
    with replaying(binding, wires) as provider:
        return run(provider)

"""Compile a public decision spec into Candidate B's existing typed action forms."""
import json

from .objects import Decision, Field, Form, Session, View


def from_spec(spec):
    """Read an authorized view and a list of finite JSON-schema function tools."""
    public = {"role", "observation", "objective", "instruction", "tools"}
    if not isinstance(spec, dict) or set(spec) - public - {"display"} or not public <= spec.keys():
        raise ValueError("a spec requires role, observation, objective, instruction and tools")
    if not all(isinstance(spec[k], str) for k in ("role", "instruction")) or not all(
            isinstance(spec[k], dict) for k in ("observation", "objective")):
        raise ValueError("invalid role-visible decision view")
    if not isinstance(spec["tools"], list) or not spec["tools"]:
        raise ValueError("supply a nonempty list of finite function tools")
    forms, descriptions = [], []
    for tool in spec["tools"]:
        if not isinstance(tool, dict) or set(tool) != {"type", "function"} or tool["type"] != "function":
            raise ValueError("expected a function tool")
        fn = tool["function"]
        if not isinstance(fn, dict) or not {"name", "parameters"} <= fn.keys() or set(fn) - {"name", "parameters", "description"}:
            raise ValueError("a function tool requires name and parameters")
        params = fn["parameters"]
        if not isinstance(params, dict) or not isinstance(params.get("properties"), dict):
            raise ValueError("expected a closed object parameter schema")
        fields, notes = [], {}
        for key, prop in params["properties"].items():
            if not isinstance(prop, dict) or not isinstance(prop.get("enum"), list):
                raise ValueError("each tool argument needs a finite enum")
            field = Field(key, tuple(prop["enum"]))
            if {k: v for k, v in prop.items() if k != "description"} != field.schema():
                raise ValueError("unsupported argument schema or mismatched enum type")
            fields.append(field)
            if "description" in prop:
                notes[key] = prop["description"]
        form = Form(fn["name"], tuple(fields))
        if not isinstance(fn["name"], str) or not fn["name"]:
            raise ValueError("tool name must be a nonempty string")
        if (params.keys() != {"type", "properties", "required", "additionalProperties"}
                or params["type"] != "object" or params["additionalProperties"] is not False
                or not isinstance(params["required"], list)
                or sorted(params["required"]) != sorted(params["properties"])):
            raise ValueError("all tool arguments must be required in a closed object schema")
        if not all(isinstance(s, str) for s in [fn.get("description", ""), *notes.values()]):
            raise ValueError("descriptions must be strings")
        if "description" in fn or notes:
            descriptions.append({"tool": fn["name"], "description": fn.get("description", ""), "arguments": notes})
        forms.append(form)
    instruction = spec["instruction"]
    if descriptions:
        instruction += "\nTool descriptions: " + json.dumps(descriptions, ensure_ascii=False)
    return Decision(View(spec["role"], spec["observation"], spec["objective"], instruction), tuple(forms))


def run_spec(spec, provider):
    decision = from_spec(spec)
    session = Session(provider)
    command = session.ask("decision", decision)
    return session.trace({"action": command.as_dict() if command else None})

"""Score a finite Decision on a loopback llama.cpp server using native next-token probabilities."""
import base64
from contextlib import contextmanager
import gzip
import hashlib
from http.client import HTTPConnection, HTTPException
import json
import math
import random
import re

from .choices import UnsupportedChoiceForm, action_catalog, select_option
from . import model_prompts


class UnsupportedTokenMenu(UnsupportedChoiceForm):
    """The tokenizer or slot context cannot represent this particular menu."""
    has_preflight_receipt = True


def _http(port, path, body):
    conn = HTTPConnection("127.0.0.1", port, timeout=180)
    try:
        conn.request("GET" if body is None else "POST", path,
                     None if body is None else json.dumps(body).encode(), {"Content-Type": "application/json"})
        response = conn.getresponse()
        raw = response.read()
        if path == "/completion":
            return {"status": response.status, "gzip_base64": base64.b64encode(
                gzip.compress(raw, compresslevel=1, mtime=0)).decode("ascii")}
        return {"status": response.status, "text": raw.decode("utf-8")}
    except (OSError, HTTPException, UnicodeError) as exc:
        return {"transport_error": type(exc).__name__}
    finally:
        conn.close()


ASCII_CODES = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!?"


def _messages(request, catalog, codes, codebook):
    visible = {k: request[k] for k in ("role", "observation", "objective", "instruction")}
    visible["choices"] = dict(zip(codes, catalog.values(), strict=True))
    kind = "decimal" if codebook == "decimal" else "case-sensitive single-character"
    return [{"role": "system", "content": f"Choose an offered action. Answer with its assigned {kind} code alone."},
            {"role": "user", "content": json.dumps(visible, ensure_ascii=False, separators=(",", ":"))}]


def _distribution(scores, code_ids, codes, catalog, vocab, codebook, separator):
    labels = list(catalog)
    by_id = {tid: (label, (separator + code).encode("ascii")) for tid, label, code in zip(code_ids, labels, codes, strict=True)}
    logps = {}
    if len(scores) != vocab:
        raise ValueError("incomplete vocabulary readout from llama.cpp")
    seen = set()
    vocabulary_weights = []
    for row in scores:
        tid = row["id"]
        if type(tid) is not int or not 0 <= tid < vocab or tid in seen:
            raise ValueError("invalid or duplicate score token ID")
        seen.add(tid)
        lp = row["logprob"]
        if type(lp) not in (float, int) or not math.isfinite(lp) or lp > 0:
            raise ValueError("invalid vocabulary log probability")
        vocabulary_weights.append(math.exp(lp))
        if tid in by_id:
            label, piece = by_id[tid]
            if row["bytes"] != list(piece):
                kind = "decimal" if codebook == "decimal" else "assigned"
                raise ValueError(f"code token bytes disagree with its {kind} label")
            logps[label] = lp
    vocab_mass = math.fsum(vocabulary_weights)
    if not math.isclose(vocab_mass, 1.0, rel_tol=0, abs_tol=0.001):
        raise ValueError("reported vocabulary probabilities do not sum to one")
    if len(logps) != len(labels):
        raise ValueError("missing scores for offered actions")
    maximum = max(logps.values())
    weights = {label: math.exp(logps[label] - maximum) for label in labels}
    total = math.fsum(weights.values())
    log_mass = maximum + math.log(total)
    if log_mass > 0.001:
        raise ValueError("reported token probabilities exceed unit vocabulary mass")
    return {k: v / total for k, v in weights.items()}, log_mass, vocab_mass


class LlamaCppDecision:
    """Use one coded, finite readout for any public Decision's role, spec and tool forms."""

    def __init__(self, model, *, port=8080, selection="argmax", seed=61101, codebook="decimal",
                 canonical_echo=True, join_separator=True, prompt_edits="auto", transport=None):
        if not isinstance(model, str) or not model.strip() or type(port) is not int or not 1 <= port <= 65535:
            raise ValueError("supply a model alias and a loopback server port")
        if selection not in ("argmax", "sample") or type(seed) is not int:
            raise ValueError("expected argmax or sample and an integer seed")
        self.model = model
        if codebook not in ("decimal", "ascii64"):
            raise ValueError("unknown next-token codebook")
        self.codebook = codebook
        if prompt_edits not in ("auto", "off", model_prompts.POLICY_V1):
            raise ValueError("unknown model prompt edit policy")
        self.prompt_policy = model_prompts.POLICY_V1 if codebook == "ascii64" and prompt_edits != "off" else None
        self.canonical_echo = codebook == "ascii64" and canonical_echo
        self.join_separator = codebook == "ascii64" and join_separator
        self.port = port
        self.selection = selection
        self.seed = seed
        self.rng = random.Random(seed)
        self.transport = transport or (lambda path, body: _http(self.port, path, body))
        self.wire = []
        self.runtime = None

    def identity(self):
        return {"provider": "local_llama_next_token", "model": self.model, "port": self.port,
                **({"codebook": self.codebook} if self.codebook != "decimal" else {}),
                **({"canonical_echo": True} if self.canonical_echo else {}),
                **({"join_separator": True} if self.join_separator else {}),
                **({"prompt_policy": self.prompt_policy} if self.prompt_policy else {}),
                "selection": self.selection, "selection_seed": self.seed if self.selection == "sample" else None}

    def __call__(self, request):
        catalog = action_catalog(request["schema"])
        wire = {"calls": []}
        self.wire.append(wire)

        def query(path, body=None):
            receipt = self.transport(path, body)
            wire["calls"].append({"path": path, "body": body, "receipt": receipt})
            if receipt.get("status") != 200:
                raise ConnectionError(f"llama.cpp {path} failed: {receipt.get('status', receipt.get('transport_error'))}")
            if "gzip_base64" in receipt:
                return json.loads(gzip.decompress(base64.b64decode(receipt["gzip_base64"], validate=True)))
            return json.loads(receipt["text"])

        try:
            probs, log_mass, vocab_mass = self._score(query, request, catalog, wire)
        except UnsupportedTokenMenu as exc:
            wire["preflight_error"] = str(exc)
            raise
        except (ValueError, TypeError, KeyError, IndexError) as exc:
            wire["invalid_response"] = str(exc)
            return ""
        maximum = max(catalog, key=probs.__getitem__)
        selected = select_option(catalog, probs, maximum, self.selection, self.rng)
        wire.update(resolved_model=self.model, probabilities=probs, menu_mass=math.exp(log_mass),
                    log_menu_mass=log_mass, vocabulary_mass=vocab_mass, selected_option=selected)
        return json.dumps(catalog[selected], separators=(",", ":"))

    def _score(self, query, request, catalog, wire):
        models = query("/v1/models")["data"]
        model = next((m for m in models if m["id"] == self.model), None)
        if len(models) != 1 or model is None:
            raise ValueError("expected a single loaded llama.cpp model matching the specified alias")
        vocab = model["meta"]["n_vocab"]
        props = query("/props")
        ctx = props["default_generation_settings"]["n_ctx"]
        if type(vocab) is not int or vocab < 1 or type(ctx) is not int or ctx < 2:
            raise ValueError("server did not provide its vocabulary and slot context sizes")
        model_path = props["model_path"]
        blob = re.search(r"(?:^|[/\\\\])sha256-([a-fA-F0-9]{64})$", model_path)
        runtime = {"model_path": model_path, "blob_digest_from_name": blob[1] if blob else None,
                   "model_metadata": model["meta"], "build": props["build_info"],
                   "template_sha256": hashlib.sha256(props["chat_template"].encode()).hexdigest()}
        wire["runtime"] = runtime
        if self.runtime is None:
            self.runtime = runtime
        elif self.runtime != runtime:
            raise ValueError("model or tokenizer binding changed within this participant")
        if self.codebook == "ascii64" and len(catalog) > len(ASCII_CODES):
            raise UnsupportedTokenMenu("ascii64 supports at most 64 commands")
        codes = list(ASCII_CODES[:len(catalog)]) if self.codebook == "ascii64" else [str(i) for i in range(1, len(catalog) + 1)]
        prompt = query("/apply-template", {"messages": _messages(request, catalog, codes, self.codebook)})["prompt"]
        if not isinstance(prompt, str) or not prompt:
            raise ValueError("server returned no rendered prompt")
        if self.prompt_policy:
            prompt, edit = model_prompts.edit_rendered_prompt(self.model, runtime, prompt)
            if edit is not None:
                wire["prompt_edit"] = edit

        bos = props.get("bos_token")
        add_special = not (self.codebook == "ascii64" and bos and prompt.startswith(bos))

        def tokenize(text, *, special=add_special):
            return query("/tokenize", {"content": text, "add_special": special, "parse_special": True})["tokens"]

        prefix = tokenize(prompt)
        if self.codebook == "ascii64" and prompt.rstrip().endswith("<think>"):
            raise UnsupportedTokenMenu("rendered template opens a reasoning turn at the scoring position")
        if (not isinstance(prefix, list) or not prefix
                or any(type(t) is not int or not 0 <= t < vocab for t in prefix)):
            raise ValueError("invalid prompt token IDs")
        # Always tokenize the original rendered prompt plus each printed code. If a
        # tokenizer joins the final space to its answer, score that entire piece.
        def bind_codes(base_ids):
            code_ids = []
            for code in codes:
                joined = tokenize(prompt + code)
                if not isinstance(joined, list) or any(type(t) is not int or not 0 <= t < vocab for t in joined):
                    raise ValueError("invalid tokenization reply")
                if len(joined) != len(base_ids) + 1 or joined[:-1] != base_ids:
                    raise UnsupportedTokenMenu(f"code {code} is not a single token at the answer position")
                code_ids.append(joined[-1])
            return code_ids

        separator = ""
        try:
            if len(prefix) + 1 > ctx:
                raise UnsupportedTokenMenu("decision exceeds the model's slot context")
            code_ids = bind_codes(prefix)
        except UnsupportedTokenMenu:
            if not self.join_separator or not prompt.endswith(" "):
                raise
            prefix = tokenize(prompt[:-1])
            if not isinstance(prefix, list) or any(type(t) is not int or not 0 <= t < vocab for t in prefix):
                raise ValueError("invalid prompt token IDs")
            if not prefix or len(prefix) + 1 > ctx:
                raise UnsupportedTokenMenu("single-space boundary falls outside the slot context")
            code_ids = bind_codes(prefix)
            separator = " "
            wire["code_separator"] = separator
        scored_prompt = prompt[:-1] if separator else prompt
        if len(set(code_ids)) != len(code_ids):
            raise UnsupportedTokenMenu("codes must map to distinct vocabulary tokens")
        wire["code_token_ids"] = code_ids
        controls = {"n_predict": 1, "n_probs": vocab, "post_sampling_probs": False, "temperature": 1.0,
                    "top_k": 0, "top_p": 1.0, "min_p": 0.0, "repeat_penalty": 1.0,
                    "presence_penalty": 0.0, "frequency_penalty": 0.0, "dry_multiplier": 0.0,
                    "typical_p": 1.0, "mirostat": 0, "xtc_probability": 0.0,
                    "grammar": "", "logit_bias": [], "seed": 0}
        raw = query("/completion", {"prompt": prefix, **controls})
        effective = raw["generation_settings"]
        if any(k not in effective or effective[k] != v for k, v in controls.items()):
            raise ValueError("effective readout settings differ from the request")
        steps = raw["completion_probabilities"]
        exact_echo = raw["prompt"] == scored_prompt
        if not exact_echo and self.codebook == "ascii64":
            exact_echo = tokenize(raw["prompt"], special=False) == prefix
            if not exact_echo and self.canonical_echo:
                # Some tokenizers insert spaces when decoding around special tokens.
                canonical = query("/detokenize", {"tokens": prefix, "special": True})["content"]
                exact_echo = bool(canonical) and canonical == raw["prompt"]
        if (not exact_echo or raw["model"] != self.model or raw["truncated"] is not False or raw["tokens_predicted"] != 1
                or raw["tokens_evaluated"] != len(prefix) or len(steps) != 1):
            raise ValueError("model, context or output position differs from the requested decision")
        return _distribution(steps[0]["top_logprobs"], code_ids, codes, catalog, vocab, self.codebook, separator)


@contextmanager
def replaying(binding, wires):
    """Rebuild tokenization, codebook, scores and played actions without contacting a server."""
    calls = iter(call for wire in wires for call in wire["calls"])
    mismatch = False

    def transport(path, body):
        nonlocal mismatch
        call = next(calls, None)
        if call is None or call["path"] != path or json.dumps(call["body"]) != json.dumps(body):
            mismatch = True
            raise ValueError("next-token request differs from saved receipt")
        return call["receipt"]

    participant = LlamaCppDecision(binding["model"], port=binding["port"], selection=binding["selection"],
                                   seed=binding["selection_seed"] if binding["selection"] == "sample" else 0,
                                   codebook=binding.get("codebook", "decimal"),
                                   canonical_echo=binding.get("canonical_echo", False),
                                   join_separator=binding.get("join_separator", False),
                                   prompt_edits=binding.get("prompt_policy", "off"), transport=transport)
    if participant.identity() != binding:
        raise ValueError("invalid next-token binding")
    yield participant
    if (mismatch or next(calls, None) is not None
            or json.dumps(participant.wire, sort_keys=True) != json.dumps(wires, sort_keys=True)):
        raise ValueError("next-token replay differs from saved evidence")


def replay(binding, wires, run):
    with replaying(binding, wires) as participant:
        return run(participant)

"""Finite action catalogs and researcher-facing views of participant scores."""
from dataclasses import asdict, dataclass
from decimal import Decimal
from itertools import product
import json
import math
import re

from .objects import UnsupportedDecision


class UnsupportedChoiceForm(UnsupportedDecision):
    """The workflow offered an open-ended field to a finite-choice participant."""


def action_catalog(schema):
    """Expand each form separately so correlated arguments stay together."""
    commands = {}
    for form in schema["anyOf"]:
        properties = form["properties"]
        name = properties["action"]["const"]
        fields = properties["args"]["properties"]
        if any("enum" not in field for field in fields.values()):
            raise UnsupportedChoiceForm("A finite-choice participant requires a finite enumeration for every argument")
        for values in product(*(field["enum"] for field in fields.values())):
            command = {"action": name, "args": dict(zip(fields, values))}
            commands.setdefault(json.dumps(command, sort_keys=True), command)
    actions = list(commands.values())
    if not actions:
        raise ValueError("A finite-choice participant requires a nonempty catalog")
    if all(not cmd["args"] for cmd in actions):
        labels = [cmd["action"] for cmd in actions]
    elif len(schema["anyOf"]) == 1 and all(len(cmd["args"]) == 1 for cmd in actions):
        values = [next(iter(cmd["args"].values())) for cmd in actions]
        labels = values if all(type(v) is str and v for v in values) else None
    else:
        labels = None
    if labels is None:
        labels = [f"option_{i}" for i in range(1, len(actions) + 1)]
    return dict(zip(labels, actions))


def select_option(catalog, probabilities, maximum, selection, rng):
    if selection == "argmax":
        return maximum
    labels = list(catalog)
    return rng.choices(labels, weights=[probabilities[label] for label in labels], k=1)[0]


@dataclass(frozen=True)
class ChoiceView:
    """A display filter applied to a complete vector over the offered commands."""
    top_k: int | None = None
    top_k_prob: float | None = None
    cover_prob: float | None = None

    def __post_init__(self):
        if self.top_k is not None and (type(self.top_k) is not int or self.top_k < 1):
            raise ValueError("top_k must be a positive integer")
        if self.top_k_prob is not None and self.cover_prob is not None:
            raise ValueError("choose an upper bound or a coverage target")
        for p in (self.top_k_prob, self.cover_prob):
            if p is not None and (type(p) not in (int, float) or not 0 <= p <= 1):
                raise ValueError("cumulative probability must be between 0 and 1")

    @classmethod
    def from_prompt(cls, prompt):
        """Resolve supported display phrases without sending them to the participant."""
        text = " ".join(prompt.lower().strip().rstrip(".?!").split())
        if match := re.fullmatch(r"(?:show (?:me )?)?(?:the )?top (\d+)(?: (?:choices|options|actions))?", text):
            return cls(top_k=int(match[1]))
        match = re.fullmatch(
            r"(?:show (?:me )?)?(?:the )?(?:choices |options |actions )?(?:with )?(?:cumulative (?:probability )?)?"
            r"(up to|cover|covering|at least) (\d+(?:\.\d+)?)\s*%", text)
        if match:
            value = float(match[2]) / 100
            return cls(top_k_prob=value) if match[1] == "up to" else cls(cover_prob=value)
        raise ValueError("use 'show me the top 10 choices', 'choices with cumulative up to 60%', or 'cover 60%'")

    def config(self):
        return {k: v for k, v in asdict(self).items() if v is not None}

    def apply(self, catalog, probabilities):
        if (not catalog or catalog.keys() != probabilities.keys()
                or any(type(p) not in (int, float) or not 0 <= p <= 1 for p in probabilities.values())
                or not math.isclose(math.fsum(probabilities.values()), 1, rel_tol=0, abs_tol=1e-6)):
            raise ValueError("a view requires a complete unit-mass vector over the offered actions")
        order = sorted(catalog, key=probabilities.__getitem__, reverse=True)
        ceiling = Decimal(str(self.top_k_prob)) if self.top_k_prob is not None else None
        target = Decimal(str(self.cover_prob)) if self.cover_prob is not None else None
        cumulative = Decimal(0)
        choices = []
        for label in order[:self.top_k]:
            if target is not None and cumulative >= target:
                break
            p = probabilities[label]
            next_mass = cumulative + Decimal(str(p))
            if ceiling is not None and ceiling < 1 and next_mass > ceiling:
                break
            choices.append({"option": label, "command": catalog[label], "probability": p})
            cumulative = next_mass
        omitted = math.fsum(probabilities[k] for k in order[len(choices):])
        result = {"filter": self.config(), "offered_count": len(order), "choices": choices,
                  "shown_mass": math.fsum(r["probability"] for r in choices), "omitted_mass": omitted}
        if target is not None:
            result["coverage_met"] = cumulative >= target or omitted == 0
        return result


def choice_reports(record, view=ChoiceView()):
    """Project saved attempts, including scored attempts the study did not admit."""
    sources = {"local_ollama_systemone": "native_choice", "local_llama_next_token": "next_token_given_menu"}
    provider = record["binding"]["provider"]
    if provider not in sources:
        raise ValueError("this participant does not record probabilities over the offered actions")
    wires = iter(record["wire"])
    reports = []
    for event in record["decisions"]:
        for number, attempt in enumerate(event["attempts"], 1):
            wire = next(wires, None)
            if wire is None:
                raise ValueError("missing decision receipt")
            result = {"decision": event["id"], "status": event["status"], "attempt": number,
                      "score_source": sources[provider], "scored": "probabilities" in wire}
            if result["scored"]:
                catalog = action_catalog(attempt["request"]["schema"])
                result.update(view.apply(catalog, wire["probabilities"]))
                result["selected_option"] = wire["selected_option"]
                result["admitted"] = event["status"] == "accepted" and number == len(event["attempts"])
                if "menu_mass" in wire:
                    result["menu_mass"] = wire["menu_mass"]
            elif "invalid_response" in wire:
                result["error"] = wire["invalid_response"]
            elif "error" in attempt:
                result["error"] = attempt["error"]
            reports.append(result)
        if event.get("provider_preflight"):
            wire = next(wires, None)
            if wire is None or wire.get("preflight_error") != event["error"]:
                raise ValueError("missing or inconsistent tokenizer preflight receipt")
        if event["status"] == "unsupported_form":
            reports.append({"decision": event["id"], "status": event["status"], "scored": False,
                            "score_source": sources[provider], "error": event["error"]})
    if next(wires, None) is not None:
        raise ValueError("unused decision receipt")
    return reports

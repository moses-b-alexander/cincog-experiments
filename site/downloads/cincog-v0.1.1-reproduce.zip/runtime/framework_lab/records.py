"""Read strict JSON records from plain or compressed files."""
import gzip
from io import TextIOWrapper
import json
import math


def read_json(path):
    def unique(pairs):
        result = dict(pairs)
        if len(result) != len(pairs):
            raise ValueError("duplicate JSON key")
        return result

    def invalid(value):
        raise ValueError(f"invalid JSON number {value}")

    def finite(value):
        number = float(value)
        return number if math.isfinite(number) else invalid(value)

    with path.open("rb") as raw:
        # Older CLI versions allowed plain JSON to be saved under any filename.
        source = gzip.GzipFile(fileobj=raw) if raw.peek(2)[:2] == b"\x1f\x8b" else raw
        with TextIOWrapper(source, encoding="utf-8-sig") as stream:
            result = json.load(stream, object_pairs_hook=unique, parse_constant=invalid, parse_float=finite)
    if not isinstance(result, dict):
        raise ValueError("expected a JSON object")
    return result

"""Ordinary scripts implement both experiments; the recorder only decides."""

import json
import math
from copy import deepcopy

from framework_lab.domain import C2_RULES, WORDS, settings, shock, yards

from .recorder import Recorder, command


def exact_recovery(word, guess):
    return None if word is None or guess is None else word == guess


def window_rate(plays):
    """Score a completed list of plays using overlapping four-play windows."""
    if len(plays) < 4:
        raise ValueError("four completed plays required")
    totals = [math.fsum(p["yards"] for p in plays[i:i + 4]) for i in range(len(plays) - 3)]
    return sum(total >= 10 for total in totals) / len(totals)


def _words(rec, cfg):
    menu = [command("choose_word", word=word) for word in WORDS]
    rules = ("A selects a word from the bank. C sees either the whole word, its last "
             "four letters, or its first four letters and guesses the original bank word. ")
    objective = dict(metric="exact_recovery", direction="maximize", horizon=1)

    def choose(tag, role, obs, instruction, goal):
        action = rec.choose(tag, role=role, observation=obs, instruction=rules + instruction,
                            objective=goal, menu=menu)
        return action["args"]["word"] if action else None

    calibration = None
    if "assigned_word" in cfg:
        target = cfg["assigned_word"]
        picked = choose("C4/calibration", "A", {"role": "A"}, f"Choose {target}.",
                        dict(metric="exact_assigned_action", direction="maximize", horizon=1))
        calibration = exact_recovery(target, picked)
    word = choose("C4/A", "A", {"role": "A"}, "Choose the word to send.", objective)
    arms = {}
    for arm in cfg["arms"]:
        fragment = guess = None
        if word is not None:
            fragment = {"whole": word, "elide_first": word[-4:], "elide_second": word[:4]}[arm]
            guess = choose(f"C4/C/{arm}", "C", {"role": "C", "fragment": fragment},
                           "Guess the original word.", objective)
        arms[arm] = dict(fragment=fragment, guess=guess, score=exact_recovery(word, guess))
    return dict(word=word, arms=arms, calibration=calibration)


def _qb_menu(board):
    yield command("do_nothing")
    for source, count in enumerate(board):
        if count:
            for dest in range(len(board)):
                if source != dest:
                    yield command("move_person", from_cell=source, to_cell=dest)


def _football(rec, cfg):
    plays = []
    horizon = cfg["horizon"]

    def choose(tag, number, history, instruction, goal):
        board = list(cfg["offense"])
        obs = dict(role="QB", offense=board, defensive_appearance=list(cfg["appearance"]),
                   play=number, last_three_yards=history[-3:])
        return rec.choose(tag, role="QB", observation=obs, objective=goal,
                          instruction=C2_RULES + " " + instruction, menu=_qb_menu(board))

    def resolve(action, number):
        before = list(cfg["offense"])
        after = before.copy()
        if action["action"] == "move_person":
            args = action["args"]
            after[args["from_cell"]] -= 1
            after[args["to_cell"]] += 1
        z = cfg["shocks"][number - 1] if cfg["shocks"] is not None else shock(cfg["seed"], number)
        gain = yards(after, cfg["defense"], z)
        return dict(before=before, after=after, yards=gain, shock=z)

    calibration_effect = None
    calibration = None
    if "assigned_qb" in cfg:
        target = cfg["assigned_qb"]
        picked = choose("C2/calibration", 1, [], "Submit " + json.dumps(target) + ".",
                        dict(metric="exact_assigned_action", direction="maximize", horizon=1))
        if picked is not None:
            calibration = picked == target
            calibration_effect = resolve(picked, 1)
    goal = dict(metric="fraction_of_four_play_windows_at_least_10_yards", direction="maximize", horizon=horizon)
    for number in range(1, horizon + 1):
        action = choose(f"C2/free/{number}", number, [p["yards"] for p in plays],
                        "Choose one quarterback action. Maximize the fraction of overlapping four-play "
                        "windows with at least 10 total yards.", goal)
        if action is None:
            break
        plays.append(resolve(action, number))
    return dict(plays=plays, score=window_rate(plays) if len(plays) == horizon else None,
                calibration=calibration, calibration_effect=calibration_effect)


def run(case, provider, config=None):
    cfg = settings(case, config)
    rec = Recorder(provider)
    script = {"C2": _football, "C4": _words}[case]
    trace = rec.finish(script(rec, cfg))
    trace["conditions"] = {"case": case, "settings": deepcopy(cfg)}
    return trace

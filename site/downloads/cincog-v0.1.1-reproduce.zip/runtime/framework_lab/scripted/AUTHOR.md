# Authoring a script

An experiment is a Python function. It owns the world, turn order, public projections, legal command menu, effects, interventions and scores. Call a Recorder when an actor has a decision. The recorder shows the supplied finite menu as a JSON Schema enum, accepts one exact command, handles a single retry and saves attempts. A returned None means the script must decide which dependent work to skip.

    from framework_lab.scripted import Recorder, command

    def doors(provider):
        log = Recorder(provider)
        action = log.choose("doors/one", role="player", observation={"doors": 2},
                            objective={"metric": "find_coin", "horizon": 1,
                                       "direction": "maximize"},
                            instruction="Choose L or R. L contains a coin.",
                            menu=[command("open", door=d) for d in ("L", "R")])
        outcome = action["args"]["door"] == "L" if action else None
        return log.finish({"coin_found": outcome})

The provider takes one dictionary and returns JSON text. Its input is private to that call. The trace retains the original request and response. Service exceptions terminate a decision immediately. A provider returning a non-string violates its transport contract and uses up an attempt.

Use run("C4", provider, config) or run("C2", provider, config) for the baseline experiments. Each C4 sender decision feeds every selected channel arm. The script asks each receiver separately. C2 rebuilds its roster every play. Its scorer window_rate takes completed play records, so alternate analysis can reuse the saved yards. Changing what an actor seeks requires another run with the new objective in its decision request. The doors test demonstrates both operations.

Enumerating every action works for small finite menus. Authors must enforce disclosure through the public observation, instruction and menu, and must provide truthful objectives. The recorder has no access to the world and cannot independently detect private data leaks, invalid effects or incorrect scoring. Each baseline returns physical outcomes and admits no implicit fallback. The provider handles its own timeouts.

The private trace stores resolved baseline conditions under conditions.settings, even if the first provider call fails. These include the hidden defensive roster. Share only the public request with a participant.

JSON Schema considers 1, 1.0 and 1e0 numerically equal. This recorder also enforces integer wire syntax, as the schema description tells the participant. Use JSON objects with string keys, arrays, strings, booleans, null and integer tokens in authored menus. Float menu entries are rejected before a provider call.

Use an adapter that opens a fresh model conversation on every provider call and sends only the supplied request. A retry receives its retry instruction in that request. A shared stateful adapter can leak the sender's choice to the receiver or remember sibling arms despite identical request projections. The recorder cannot inspect provider memory.

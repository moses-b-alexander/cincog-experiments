"""A finite-menu decision boundary for ordinary Python game scripts."""

from copy import deepcopy
import json


def command(action, **args):
    return {"action": action, "args": args}


def _canonical(value):
    return json.dumps(value, allow_nan=False, sort_keys=True, separators=(",", ":"))


def _check_literal(value):
    if value is None or type(value) in (str, int, bool):
        return
    if type(value) is list:
        for item in value:
            _check_literal(item)
        return
    if type(value) is dict and all(type(key) is str for key in value):
        for item in value.values():
            _check_literal(item)
        return
    raise ValueError("menu literals must use JSON values and integer number tokens")


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate property")
        result[key] = value
    return result


class Recorder:
    def __init__(self, provider):
        self._provider = provider
        self._decisions = {}

    def choose(self, decision_id, *, role, observation, objective, instruction, menu):
        """Return a fresh admitted command, or None after a recorded failure."""
        if decision_id in self._decisions:
            raise ValueError(f"duplicate decision id {decision_id}")
        choices = deepcopy(list(menu))
        if not choices:
            raise ValueError("empty command menu")
        for choice in choices:
            if (type(choice) is not dict or set(choice) != {"action", "args"}
                    or type(choice["action"]) is not str or type(choice["args"]) is not dict):
                raise ValueError("invalid menu entry")
            _check_literal(choice)
        admitted = {_canonical(choice) for choice in choices}
        if len(admitted) != len(choices):
            raise ValueError("duplicate menu entry")
        schema = {"type": "object", "enum": choices,
                  "description": "Use exact JSON scalar types. Write integers without a decimal point or exponent."}
        request = deepcopy(dict(role=role, observation=observation, objective=objective,
                                instruction=instruction, schema=schema))
        row = {"id": decision_id, "attempts": [], "action": None, "status": "exhausted"}
        self._decisions[decision_id] = row
        for index in range(2):
            if index:
                request["retry"] = "Return exactly one JSON object from the advertised enum."
            attempt = {"request": deepcopy(request), "raw": None}
            row["attempts"].append(attempt)
            try:
                raw = self._provider(deepcopy(request))
            except Exception as exc:
                row["status"] = "service_failure"
                attempt["error"] = type(exc).__name__
                return None
            if not isinstance(raw, str):
                attempt["error"] = "expected JSON text"
                continue
            attempt["raw"] = raw
            try:
                decision = json.loads(raw, object_pairs_hook=_unique_object)
                if _canonical(decision) not in admitted:
                    raise ValueError("command outside menu")
            except (ValueError, RecursionError) as exc:
                attempt["error"] = str(exc)
                continue
            row.update(status="accepted", action=deepcopy(decision))
            return decision
        return None

    def finish(self, result):
        return deepcopy({"decisions": list(self._decisions.values()), "result": result})

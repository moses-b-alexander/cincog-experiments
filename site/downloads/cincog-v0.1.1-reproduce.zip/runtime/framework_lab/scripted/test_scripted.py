"""The third script is an independent, two-door choice exercise."""

import json
import unittest

from . import Recorder, command, run
from framework_lab.domain import WORDS


def doors(provider, prize, goal):
    rec = Recorder(provider)
    picked = rec.choose("doors/seat", role="player", observation={"doors": ["L", "R"]},
                        objective={"metric": goal, "direction": "maximize", "horizon": 1},
                        instruction="Pick one door. The left door contains a coin.",
                        menu=[command("open", door=d) for d in ("L", "R")])
    contents = prize[picked["args"]["door"]] if picked else None
    return rec.finish({"contents": contents})


class ScriptTests(unittest.TestCase):
    def test_scoring_existing_trace_and_changing_goal(self):
        calls = []

        def provider(request):
            calls.append(request)
            door = "L" if request["objective"]["metric"] == "seek_coin" else "R"
            return json.dumps(command("open", door=door))

        prizes = {"L": "coin", "R": "empty"}
        a = doors(provider, prizes, "seek_coin")
        outcome = a["result"]["contents"]
        self.assertTrue(outcome == "coin")
        self.assertFalse(outcome == "empty")
        self.assertEqual(len(calls), 1)
        b = doors(provider, prizes, "avoid_coin")
        self.assertEqual(b["result"]["contents"], "empty")
        self.assertEqual(len(calls), 2)

    def test_exhausted_attempts(self):
        for raw in ('{"action":"go","args":{"n":true}}', '{"action":"go","args":{"n":1.0}}',
                    '{"action":"go","args":{"n":1,"n":1}}', '{"action":"go","args":{"n":NaN}}',
                    '{"action":"go","args":{"n":1},"x":1}', '[]', 'null'):
            with self.subTest(raw=raw):
                rec = Recorder(lambda request: raw)
                self.assertIsNone(rec.choose("id", role="X", observation={}, objective={},
                                             instruction="", menu=[command("go", n=1)]))
                row, = rec.finish(None)["decisions"]
                self.assertEqual(row["status"], "exhausted")
                self.assertEqual([a["raw"] for a in row["attempts"]], [raw, raw])

    def test_request_snapshot_and_retry(self):
        calls = []

        def provider(request):
            calls.append(request)
            request["observation"].clear()
            return "" if len(calls) == 1 else json.dumps(command("open", door="L"))

        trace = doors(provider, {"L": "coin"}, "seek_coin")
        first, second = trace["decisions"][0]["attempts"]
        self.assertEqual(first["request"]["observation"], {"doors": ["L", "R"]})
        self.assertEqual(first["request"]["observation"], second["request"]["observation"])
        self.assertEqual(first["raw"], "")
        self.assertEqual(trace["result"]["contents"], "coin")

    def test_shared_sender_and_receiver_failure(self):
        calls = []

        def provider(request):
            calls.append(request["role"])
            if len(calls) == 2:
                raise OSError()
            return json.dumps(command("choose_word", word=WORDS[0]))

        trace = run("C4", provider, {"arms": ["whole", "elide_first", "elide_second"]})
        self.assertEqual(calls, ["A", "C", "C", "C"])
        self.assertIsNone(trace["result"]["arms"]["whole"]["score"])
        self.assertTrue(trace["result"]["arms"]["elide_first"]["score"])
        self.assertEqual(trace["decisions"][1]["status"], "service_failure")

    def test_qb_stops_episode(self):
        calls = []

        def provider(request):
            calls.append(request)
            return json.dumps(command("do_nothing")) if len(calls) == 1 else "{}"

        trace = run("C2", provider)
        self.assertIsNone(trace["result"]["score"])
        self.assertEqual(len(trace["result"]["plays"]), 1)
        self.assertEqual(calls[-1]["observation"]["play"], 2)
        self.assertEqual(len(calls[-1]["observation"]["last_three_yards"]), 1)


    def test_calibration_resolves_actual_action_in_isolation(self):
        called = []
        move = command("move_person", from_cell=0, to_cell=5)

        def provider(request):
            called.append(request)
            return json.dumps(move if len(called) == 1 else command("do_nothing"))

        result = run("C2", provider, {"assigned_qb": command("do_nothing"), "shocks": [0]*4})["result"]
        self.assertFalse(result["calibration"])
        effect = result["calibration_effect"]
        self.assertEqual(effect["before"], result["plays"][0]["before"])
        self.assertEqual(effect["after"][5], 1)
        self.assertEqual(result["plays"][0]["after"][5], 0)
        self.assertEqual(called[1]["observation"]["last_three_yards"], [])
        self.assertEqual(called[0]["objective"]["metric"], "exact_assigned_action")
        self.assertEqual(called[1]["objective"]["metric"], "fraction_of_four_play_windows_at_least_10_yards")

    def test_private_settings_survive_early_failure(self):
        def offline(_):
            raise OSError()
        traces = [run("C2", offline, {"defense": defense})
                  for defense in ([6] + [0]*8, [0]*8 + [6])]
        self.assertNotEqual(traces[0]["conditions"], traces[1]["conditions"])
        self.assertEqual(traces[0]["decisions"], traces[1]["decisions"])
        self.assertEqual(traces[0]["conditions"]["settings"]["defense"], [6] + [0]*8)
        request = traces[0]["decisions"][0]["attempts"][0]["request"]
        self.assertEqual(set(request), {"role", "observation", "instruction", "objective", "schema"})

    def test_strict_wire_rule_is_visible_and_catalog_rejected_early(self):
        rec = Recorder(lambda _: self.fail("invalid author catalog reached provider"))
        with self.assertRaisesRegex(ValueError, "integer number tokens"):
            rec.choose("id", role="p", observation={}, objective={}, instruction="",
                       menu=[command("set", n=1.0)])
        rec = Recorder(lambda _: '{"action":"set","args":{"n":1e0}}')
        self.assertIsNone(rec.choose("id", role="p", observation={}, objective={}, instruction="",
                                     menu=[command("set", n=1)]))
        schema = rec.finish(None)["decisions"][0]["attempts"][0]["request"]["schema"]
        self.assertIn("without a decimal point or exponent", schema["description"])

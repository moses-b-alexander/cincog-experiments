"""Run baseline studies or one declared tool decision and inspect probability views offline."""
from __future__ import annotations

import argparse
import gzip
import importlib
from io import TextIOWrapper
import json
from pathlib import Path
import sys

from .choices import ChoiceView, choice_reports
from .decision_spec import run_spec
from .domain import settings
from .llama_decision import LlamaCppDecision
from .ollama_decision import OllamaDecision
from .providers import LocalOllama, scripted
from .records import read_json as _read_json

CANDIDATES = ("scripted", "objects", "recipes")


def _display_options(parser):
    parser.add_argument("--top-k", type=int, help="show at most K offered choices in probability order")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--top-k-prob", type=float, help="maximum cumulative mass to show, 0 to 1")
    group.add_argument("--cover-prob", type=float, help="show choices until this cumulative mass is reached")
    parser.add_argument("--show", help="display phrase, e.g. 'show me the top 10 choices'")


def _view(args, default):
    values = {k: getattr(args, k) for k in ("top_k", "top_k_prob", "cover_prob") if getattr(args, k) is not None}
    if args.show is not None:
        if values:
            raise ValueError("choose a display phrase or explicit display settings")
        return ChoiceView.from_prompt(args.show)
    cfg = values or default
    if cfg is None:
        return None
    if not isinstance(cfg, dict) or set(cfg) - {"top_k", "top_k_prob", "cover_prob"}:
        raise ValueError("unknown display settings")
    return ChoiceView(**cfg)


def replay_choice_record(record):
    from .objects import run
    from .llama_decision import replay as replay_llama
    from .ollama_decision import replay as replay_native
    methods = {"local_llama_next_token": replay_llama, "local_ollama_systemone": replay_native}
    if record["candidate"] != "objects" or record["binding"]["provider"] not in methods:
        raise ValueError("expected an object study with a finite-choice participant")
    def play(provider):
        if record["case"] == "spec":
            return run_spec(record["spec"], provider)
        return run(record["case"], provider, record["settings"])
    trace = methods[record["binding"]["provider"]](record["binding"], record["wire"], play)
    if any(json.dumps(value, sort_keys=True) != json.dumps(record[key], sort_keys=True) for key, value in trace.items()):
        raise ValueError("replayed trace differs from the saved decisions or result")
    return trace


def _inspect(argv, replaying):
    parser = argparse.ArgumentParser(prog="cincog-lab " + ("replay" if replaying else "show"))
    parser.add_argument("record", type=Path)
    if not replaying:
        _display_options(parser)
    args = parser.parse_args(argv)
    try:
        record = _read_json(args.record)
        trace = replay_choice_record(record)
        if replaying:
            print(json.dumps({"replayed": len(trace["decisions"]), "result": trace["result"]}))
        else:
            view = _view(args, record.get("choice_view") or {})
            print(json.dumps(choice_reports({**record, **trace}, view), allow_nan=False))
    except (ValueError, TypeError, KeyError, OSError, EOFError) as exc:
        parser.error(str(exc))
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] in (["show"], ["replay"]):
        return _inspect(argv[1:], argv[0] == "replay")
    one = argv[:1] == ["score"]
    parser = argparse.ArgumentParser(description=__doc__, epilog="Other commands: score SPEC, show RECORD, replay RECORD")
    if one:
        parser.prog = "cincog-lab score"
        parser.add_argument("spec", type=Path, help="JSON decision spec with a finite function-tool list")
    else:
        parser.add_argument("candidate", choices=CANDIDATES)
        parser.add_argument("case", choices=("C2", "C4"))
        parser.add_argument("--config", type=Path, help="baseline settings as JSON")
    providers = parser.add_mutually_exclusive_group(required=one)
    if not one:
        providers.add_argument("--ollama", metavar="LOCAL_MODEL", help="local chat action participant")
    providers.add_argument("--ollama-s1", metavar="MODEL", help="local Ollama native decision model")
    providers.add_argument("--llama-model", metavar="ALIAS", help="next-token scorer on a local llama.cpp server")
    parser.add_argument("--llama-port", type=int, help="loopback llama.cpp port (default 8080)")
    parser.add_argument("--codebook", choices=("decimal", "ascii64"), help="LLM answer labels (default: decimal)")
    parser.add_argument("--prompt-edits", choices=("auto", "off"), help="apply verified ASCII64 model prompt edits (default: auto)")
    parser.add_argument("--selection", choices=("argmax", "sample"), help="action policy for scored participants")
    parser.add_argument("--model-seed", type=int, default=61101)
    parser.add_argument("--output", type=Path, help="write the full trace to a new file (use .gz for gzip compression)")
    _display_options(parser)
    args = parser.parse_args(argv[1:] if one else argv)
    if args.output and args.output.exists():
        parser.error("choose a new output file")
    scored = args.ollama_s1 is not None or args.llama_model is not None
    candidate = "objects" if one else args.candidate
    case = "spec" if one else args.case
    try:
        spec = _read_json(args.spec) if one else None
        cfg = {} if one or not args.config else _read_json(args.config)
        default_view = spec.get("display", {}) if one else None
        view = _view(args, default_view)
        if (view or args.selection) and not scored:
            raise ValueError("a choice display or selection policy requires a scored participant")
        if args.llama_port is not None and args.llama_model is None:
            raise ValueError("--llama-port requires --llama-model")
        if args.codebook is not None and args.llama_model is None:
            raise ValueError("--codebook requires --llama-model")
        if args.prompt_edits is not None and args.llama_model is None:
            raise ValueError("--prompt-edits requires --llama-model")
        if scored and candidate != "objects":
            raise ValueError("choice adapters support candidate B (objects)")
        if args.llama_model is not None:
            provider = LlamaCppDecision(args.llama_model, port=8080 if args.llama_port is None else args.llama_port,
                                        selection=args.selection or "argmax", seed=args.model_seed,
                                        codebook=args.codebook or "decimal", prompt_edits=args.prompt_edits or "auto")
        elif args.ollama_s1 is not None:
            provider = OllamaDecision(args.ollama_s1, selection=args.selection or "argmax", seed=args.model_seed)
        elif args.ollama:
            provider = LocalOllama(args.ollama, args.model_seed)
        else:
            provider = scripted
        binding = provider.identity() if provider is not scripted else {"provider": "scripted"}
        record = {"version": 1, "candidate": candidate, "case": case, "binding": binding}
        if one:
            record.update(spec=spec, **run_spec(spec, provider))
        else:
            record["settings"] = settings(case, cfg)
            package = importlib.import_module(f"framework_lab.{candidate}")
            record.update(package.run(case, provider, cfg))
        if provider is not scripted:
            record["wire"] = provider.wire
        if view is not None:
            record["choice_view"] = view.config()
        if args.output:
            payload = json.dumps(record, indent=2, allow_nan=False) + "\n"
            raw = args.output.open("xb")
            try:
                with raw:
                    target = (gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=1, mtime=0)
                              if args.output.suffix.lower() == ".gz" else raw)
                    with TextIOWrapper(target, encoding="utf-8") as stream:
                        stream.write(payload)
            except OSError:
                args.output.unlink(missing_ok=True)
                raise
        rows = record["decisions"]
        summary = {"candidate": candidate, "case": case, "decisions": len(rows),
                   "attempts": sum(len(r["attempts"]) for r in rows),
                   "statuses": [r["status"] for r in rows], "result": record["result"]}
        if view is not None:
            summary["choice_reports"] = choice_reports(record, view)
        print(json.dumps(summary, allow_nan=False))
        return 0 if all(r["status"] == "accepted" for r in rows) else 2
    except (ValueError, TypeError, KeyError, OSError, EOFError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    raise SystemExit(main())

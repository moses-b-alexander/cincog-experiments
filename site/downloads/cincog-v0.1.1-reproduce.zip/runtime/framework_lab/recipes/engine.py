"""Interpret a finite recipe over explicitly registered Python operations."""
from copy import deepcopy
from dataclasses import dataclass
from inspect import signature
import json
from string import Formatter


@dataclass(frozen=True)
class Question:
    role: str
    observation: dict
    objective: dict
    instruction: str
    choices: tuple


def _object(pairs):
    value = dict(pairs)
    if len(value) != len(pairs):
        raise ValueError("duplicate member")
    return value


def _canonical(value):
    return json.dumps(value, allow_nan=False, sort_keys=True, separators=(",", ":"))


def _schema(choices):
    # An enum of full objects exposes correlations such as distinct source/destination.
    return {"type": "object", "required": ["action", "args"],
            "properties": {"action": {"type": "string"}, "args": {"type": "object"}},
            "additionalProperties": False, "enum": deepcopy(list(choices))}


def decide(question, ident, provider, trace):
    choices = {}
    for action in question.choices:
        if (not isinstance(action, dict) or set(action) != {"action", "args"}
                or not isinstance(action["action"], str) or not isinstance(action["args"], dict)):
            raise ValueError("each choice must have a string action and an args object")
        key = _canonical(action)
        if key in choices or json.loads(key) != action:
            raise ValueError("question choices must be unique JSON objects")
        choices[key] = action
    if not choices:
        raise ValueError("a decision needs at least one legal response")
    base = dict(role=question.role, observation=question.observation,
                objective=question.objective, instruction=question.instruction,
                schema=_schema(question.choices))
    entry = dict(id=ident, status="exhausted", attempts=[], action=None)
    trace.append(entry)
    for i in range(2):
        request = deepcopy(base)
        if i:
            request["retry"] = "Return one exact JSON object from the schema."
        attempt = dict(request=request, raw=None)
        entry["attempts"].append(attempt)
        try:
            raw = provider(deepcopy(request))
        except Exception as exc:
            entry["status"] = "service_failure"
            attempt["error"] = type(exc).__name__
            break
        if not isinstance(raw, str):
            attempt["error"] = "expected a JSON string"
            continue
        attempt["raw"] = raw
        try:
            response = json.loads(raw, object_pairs_hook=_object)
            action = choices[_canonical(response)]
        except (ValueError, KeyError, RecursionError):
            attempt["error"] = "invalid response"
            continue
        entry.update(action=deepcopy(action), status="accepted")
        return deepcopy(action)
    return None


def _read(frame, ref):
    root, *path = ref.split(".")
    value = frame[root]
    for key in path:
        value = value[key]
    return value


class Recipe:
    """Compile JSON-shaped step lists. Each binding is assigned once per frame."""

    def __init__(self, steps, operations):
        self._steps = deepcopy(steps)
        self._ops = dict(operations)
        names = self._check(self._steps, {"config"})
        if "result" not in names:
            raise ValueError("recipe must bind result")

    def _check(self, steps, scope):
        scope = set(scope)
        if not isinstance(steps, list):
            raise ValueError("steps must be a list")
        for step in steps:
            if not isinstance(step, list) or len(step) < 3:
                raise ValueError("expected a step with verb, output and inputs")
            verb, name, *args = step
            if not isinstance(name, str) or not name.isidentifier() or name in scope:
                raise ValueError(f"invalid or repeated binding {name!r}")

            def ref(value):
                if (not isinstance(value, str) or not all(k.isidentifier() for k in value.split("."))
                        or value.split(".")[0] not in scope):
                    raise ValueError(f"unknown input {value!r}")

            if verb == "call" and args and isinstance(args[0], str) and args[0] in self._ops:
                for value in args[1:]:
                    ref(value)
                try:
                    signature(self._ops[args[0]]).bind(*args[1:])
                except TypeError as exc:
                    raise ValueError(f"wrong arguments for {args[0]}") from exc
            elif verb == "ask" and len(args) == 2:
                ref(args[0])
                for _, key, spec, conversion in Formatter().parse(args[1]):
                    if key is not None and (not key.isidentifier() or key not in scope or spec or conversion):
                        raise ValueError(f"invalid decision id template {args[1]!r}")
            elif verb == "when" and len(args) == 3:
                ref(args[0])
                inner = self._check(args[1], scope)
                if args[2] not in inner:
                    raise ValueError("unknown conditional output")
            elif verb == "each" and len(args) == 4:
                ref(args[0])
                item = args[1]
                if not isinstance(item, str) or not item.isidentifier() or item in scope or item == name:
                    raise ValueError("loop item needs a fresh name")
                inner = self._check(args[2], scope | {item, name})
                if args[3] not in inner:
                    raise ValueError("unknown loop output")
            else:
                raise ValueError(f"unknown operation or malformed step {step[:3]!r}")
            scope.add(name)
        return scope

    def run(self, config, provider):
        trace = []
        frame = {"config": deepcopy(config)}
        self._execute(self._steps, frame, provider, trace, set())
        return deepcopy({"config": frame["config"], "decisions": trace, "result": frame["result"]})

    def _execute(self, steps, frame, provider, trace, issued):
        for verb, name, *args in steps:
            if verb == "call":
                value = self._ops[args[0]](*(deepcopy(_read(frame, r)) for r in args[1:]))
            elif verb == "ask":
                ident = args[1].format_map(frame)
                if ident in issued:
                    raise ValueError(f"decision id already issued: {ident}")
                issued.add(ident)
                value = decide(_read(frame, args[0]), ident, provider, trace)
            elif verb == "when":
                value = None
                if _read(frame, args[0]):
                    child = dict(frame)
                    self._execute(args[1], child, provider, trace, issued)
                    value = child[args[2]]
            elif verb == "each":
                value = []
                # Returning None ends the sequence; a missing independent arm is a row.
                for item in _read(frame, args[0]):
                    child = {**frame, name: deepcopy(value), args[1]: item}
                    self._execute(args[2], child, provider, trace, issued)
                    row = child[args[3]]
                    if row is None:
                        break
                    value.append(row)
            frame[name] = value

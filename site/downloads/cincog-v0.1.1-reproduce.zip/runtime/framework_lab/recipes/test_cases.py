"""Domain-level checks for paired information and episode boundaries."""
import json
import unittest

from framework_lab.domain import WORDS, yards
from . import run


class FixtureTests(unittest.TestCase):
    def test_calibration_and_paired_siblings(self):
        word = WORDS[0]
        assigned = WORDS[1]
        replies = iter([word, word, word, None, None, word])

        def provider(request):
            value = next(replies)
            if value is None:
                return "bad"
            return json.dumps({"action": "choose_word", "args": {"word": value}})

        trace = run("C4", provider, {"assigned_word": assigned,
                                     "arms": ["whole", "elide_first", "elide_second"]})
        result = trace["result"]
        self.assertFalse(result["calibration"])
        self.assertEqual(result["word"], word)
        arms = result["arms"]
        self.assertTrue(arms["whole"]["score"])
        self.assertEqual(arms["elide_first"], {"fragment": word[4:], "guess": None, "score": None})
        self.assertEqual(arms["elide_second"], {"fragment": word[:4], "guess": word, "score": True})
        for decision in trace["decisions"][2:]:
            request = decision["attempts"][0]["request"]
            self.assertEqual(set(request["observation"]), {"role", "fragment"})
            self.assertNotIn(decision["id"], json.dumps(request))

    def test_fixed_board_and_missing_score(self):
        noop = json.dumps({"action": "do_nothing", "args": {}})
        trace = run("C2", lambda _: noop, {"shocks": [0, 1, 2, 3]})
        plays = trace["result"]["plays"]
        for i, play in enumerate(plays):
            self.assertEqual(play["before"], play["after"])
            self.assertEqual(play["yards"], yards(play["after"], play["defense"], i))
            req = trace["decisions"][i]["attempts"][0]["request"]
            self.assertEqual(req["observation"]["last_three_yards"], [p["yards"] for p in plays[:i]])
        self.assertEqual(trace["result"]["score"], float(sum(p["yards"] for p in plays) >= 10))
        replies = iter([noop])
        partial = run("C2", lambda _: next(replies))
        self.assertIsNone(partial["result"]["score"])
        self.assertEqual(len(partial["result"]["plays"]), 1)
        self.assertEqual(partial["decisions"][-1]["status"], "service_failure")

    def test_calibration_applies_actual_legal_command_in_isolation(self):
        noop = {"action": "do_nothing", "args": {}}
        move = {"action": "move_person", "args": {"from_cell": 0, "to_cell": 1}}
        replies = iter([move, noop, noop, noop, noop])
        trace = run("C2", lambda _: json.dumps(next(replies)), {"assigned_qb": noop,
                                                               "shocks": [0.5]*4})
        result = trace["result"]
        self.assertFalse(result["calibration"])
        effect = result["calibration_effect"]
        self.assertEqual(effect["after"][:2], [1, 2])
        self.assertEqual(effect["yards"], yards(effect["after"], effect["defense"], 0.5))
        self.assertEqual(result["plays"][0]["before"][:2], [2, 1])
        self.assertEqual(trace["decisions"][0]["attempts"][0]["request"]["objective"],
                         {"metric": "exact_assigned_action", "direction": "maximize", "horizon": 1})

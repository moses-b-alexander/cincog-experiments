"""Domain operations and editable data recipes for the two comparison fixtures."""
import json
import math
from importlib.resources import files

from framework_lab.domain import C2_RULES, WORDS, settings, shock, yards
from .engine import Question, Recipe


def action(name, **arguments):
    return {"action": name, "args": arguments}


WORD_ACTIONS = tuple(action("choose_word", word=w) for w in WORDS)
CHANNEL = ("A chooses one eight-letter bank word. C receives the whole word, its first "
           "four letters, or its last four letters and guesses the original bank word.")
RECOVERY = {"metric": "exact_recovery", "direction": "maximize", "horizon": 1}


def sender(target=None):
    instruction = CHANNEL + " Choose one bank word for C to recover."
    objective = RECOVERY
    if target is not None:
        instruction = CHANNEL + f" Choose the assigned word {target}."
        objective = {"metric": "exact_assigned_action", "direction": "maximize", "horizon": 1}
    return Question("A", {"role": "A"}, objective, instruction, WORD_ACTIONS)


def chosen(reply):
    return reply["args"]["word"] if reply is not None else None


def clipped(word, arm):
    if word is None:
        return None
    return {"whole": word, "elide_first": word[4:], "elide_second": word[:4]}[arm]


def receiver(fragment):
    return Question("C", {"role": "C", "fragment": fragment}, RECOVERY,
                    CHANNEL + " Guess the word A chose.", WORD_ACTIONS)


def arm_row(arm, fragment, guess, word):
    return [arm, {"fragment": fragment, "guess": guess,
                  "score": None if guess is None else guess == word}]


def matched(value, target):
    return value == target if value is not None else None


def word_result(word, rows, calibration):
    return dict(word=word, arms=dict(rows), calibration=calibration)


def board_question(cfg, play, plays, target=None):
    board = cfg["offense"]
    choices = [action("do_nothing")]
    for src, population in enumerate(board):
        if population:
            choices.extend(action("move_person", from_cell=src, to_cell=dst)
                           for dst in range(len(board)) if dst != src)
    obs = dict(role="QB", offense=board, defensive_appearance=cfg["appearance"],
               play=play, last_three_yards=[p["yards"] for p in plays[-3:]])
    goal = {"metric": "fraction_of_four_play_windows_at_least_10_yards",
            "direction": "maximize", "horizon": cfg["horizon"]}
    instruction = C2_RULES + " Maximize the fraction of four-play windows totaling at least ten yards."
    if target is not None:
        goal = {"metric": "exact_assigned_action", "direction": "maximize", "horizon": 1}
        instruction = C2_RULES + f" Make this assigned action: {target}."
    return Question("QB", obs, goal, instruction, tuple(choices))


def resolve(cfg, play, reply):
    if reply is None:
        return None
    before = cfg["offense"]
    after = list(before)
    if reply["action"] == "move_person":
        args = reply["args"]
        after[args["from_cell"]] -= 1
        after[args["to_cell"]] += 1
    z = cfg["shocks"][play - 1] if cfg["shocks"] is not None else shock(cfg["seed"], play)
    return dict(play=play, before=before, after=after, shock=z, defense=cfg["defense"],
                yards=yards(after, cfg["defense"], z))


def window_score(plays, horizon):
    if len(plays) != horizon:
        return None
    totals = [math.fsum(p["yards"] for p in plays[i:i+4]) for i in range(horizon-3)]
    return sum(total >= 10 for total in totals) / len(totals)


WORD_OPS = dict(target=lambda cfg: cfg.get("assigned_word"), sender=sender,
                receiver=receiver, chosen=chosen, clipped=clipped,
                matched=matched, row=arm_row, result=word_result)
WORD_STEPS = json.loads(files(__package__).joinpath("word.json").read_text(encoding="utf-8"))

def calibration_row(cfg, reply, target):
    return {"match": matched(reply, target), "effect": resolve(cfg, 1, reply)}


def board_result(plays, score, calibration):
    report = calibration or {"match": None, "effect": None}
    return dict(plays=plays, score=score, calibration=report["match"],
                calibration_effect=report["effect"])


BOARD_OPS = dict(target=lambda cfg: cfg.get("assigned_qb"),
                 calibration=lambda cfg, target: board_question(cfg, 1, [], target),
                 question=board_question, calibration_row=calibration_row, resolve=resolve,
                 numbers=lambda horizon: list(range(1, horizon+1)), score=window_score,
                 result=board_result)
BOARD_STEPS = json.loads(files(__package__).joinpath("board.json").read_text(encoding="utf-8"))

CASES = {"C2": Recipe(BOARD_STEPS, BOARD_OPS), "C4": Recipe(WORD_STEPS, WORD_OPS)}


def run(case, provider, config=None):
    return CASES[case].run(settings(case, config), provider)

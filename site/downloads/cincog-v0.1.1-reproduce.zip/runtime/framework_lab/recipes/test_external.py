"""A third-party matching exercise written with just the public author API."""
import json
import unittest

from . import Question, Recipe


def question(color):
    choices = tuple({"action": "select", "args": {"color": c}} for c in ("red", "blue"))
    return Question("painter", {"swatch": color}, {"metric": "matches", "direction": "maximize",
                    "horizon": 1}, "Select the color of the public swatch.", choices)


def assess(color, reply):
    return {"shown": color, "correct": None if reply is None else color == reply["args"]["color"]}


SWATCHES = [
    ["each", "result", "config.colors", "color", [
        ["call", "question", "show", "color"],
        ["ask", "reply", "question", "swatch/{color}"],
        ["call", "outcome", "assess", "color", "reply"],
    ], "outcome"],
]


class ExternalRecipeTests(unittest.TestCase):
    def test_duplicate_runtime_ids_do_not_dispatch_twice(self):
        received = []
        def choose(request):
            received.append(request)
            return '{"action":"select","args":{"color":"red"}}'
        with self.assertRaisesRegex(ValueError, "already issued"):
            Recipe(SWATCHES, {"show": question, "assess": assess}).run(
                {"colors": ["red", "red"]}, choose)
        self.assertEqual(len(received), 1)

    def test_missing_swatch_does_not_hide_sibling(self):
        def provider(request):
            color = request["observation"].pop("swatch")
            if color == "red":
                raise RuntimeError("unavailable")
            return json.dumps({"action": "select", "args": {"color": color}})

        engine = Recipe(SWATCHES, {"show": question, "assess": assess})
        log = engine.run({"colors": ["red", "blue"]}, provider)
        self.assertEqual([r["correct"] for r in log["result"]], [None, True])
        self.assertEqual([d["status"] for d in log["decisions"]], ["service_failure", "accepted"])
        self.assertEqual(log["decisions"][0]["attempts"][0]["request"]["observation"], {"swatch": "red"})

    def test_invalid_recipe_rejected_before_provider_runs(self):
        for steps in ([["call", "result", "missing"]],
                      [["call", "result", "show", "typo"]],
                      [["call", "result", "show"]],
                      [["ask", "result", "config", "{secret}"]]):
            with self.subTest(steps=steps), self.assertRaises(ValueError):
                Recipe(steps, {"show": question})

    def test_retry_keeps_raw_replies(self):
        raw = '{"action":"select","args":{"color":"red","color":"blue"}}'
        good = ' { "args": {"color":"red"}, "action": "select" } '
        replies = iter([raw, good])
        log = Recipe(SWATCHES, {"show": question, "assess": assess}).run(
            {"colors": ["red"]}, lambda _: next(replies))
        attempts = log["decisions"][0]["attempts"]
        self.assertEqual([a["raw"] for a in attempts], [raw, good])
        self.assertEqual(attempts[0]["request"]["observation"], attempts[1]["request"]["observation"])


    def test_prior_rows_are_snapshots_and_item_is_distinct(self):
        previous = Recipe([["each", "result", "config.samples", "sample", [], "result"]], {})
        result = previous.run({"samples": [1, 2]}, None)["result"]
        self.assertEqual(result, [[], [[]]])
        json.dumps(result)
        with self.assertRaises(ValueError):
            Recipe([["each", "result", "config.samples", "result", [], "result"]], {})

    def test_malformed_choices_rejected_before_any_dispatch(self):
        from unittest.mock import Mock
        provider = Mock(return_value='{"action":"yes"}')
        for bad in ({"action": "yes"}, {"action": "yes", "args": {}, "extra": 0},
                    {"action": 1, "args": {}}, {"action": "yes", "args": []}):
            with self.subTest(bad=bad):
                q = Question("observer", {}, {}, "respond", (bad,))
                engine = Recipe([["call", "q", "make"], ["ask", "result", "q", "trial"]],
                                {"make": lambda: q})
                with self.assertRaises(ValueError):
                    engine.run({}, provider)
        provider.assert_not_called()

    def test_private_config_only_in_trace_and_isolated_from_caller(self):
        config = {"colors": ["red"], "secret": {"value": [12345]}}
        requests = []

        def provider(request):
            requests.append(request)
            request["observation"]["swatch"] = "blue"
            return '{"action":"select","args":{"color":"red"}}'

        log = Recipe(SWATCHES, {"show": question, "assess": assess}).run(config, provider)
        self.assertNotIn("secret", json.dumps(requests))
        self.assertEqual(log["config"], config)
        self.assertEqual(log["decisions"][0]["attempts"][0]["request"]["observation"]["swatch"], "red")
        config["secret"]["value"].clear()
        self.assertEqual(log["config"]["secret"]["value"], [12345])

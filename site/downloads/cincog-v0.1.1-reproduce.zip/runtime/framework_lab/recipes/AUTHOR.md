# Authoring a recipe

Import `Question` and `Recipe` from `framework_lab.recipes`. A recipe is an ordered list of JSON-compatible steps. Supply a registry of ordinary Python functions by name, then call `Recipe(steps, registry).run(config, provider)`. The final binding named `result` and the engine's decision records form the returned trace. The comparison adapter accepts `run("C2", provider, config)` and `run("C4", provider, config)`.

| Step | Behavior |
| --- | --- |
| `["call", out, operation, ...refs]` | Pass copies of the referenced values to a registered function and bind its return value. |
| `["ask", out, questionRef, idTemplate]` | Send the public question, admit an exact catalog choice, and bind the action or null. Braces in the ID interpolate a bound name. IDs stay private. |
| `["when", out, conditionRef, steps, innerName]` | Execute a nested scope when the condition is truthy. Otherwise bind null. |
| `["each", out, itemsRef, itemName, steps, innerName]` | Run a fresh scope per item. Inside that scope, `out` holds prior completed rows. A null row ends the loop. Return an object with null fields to retain an incomplete row and continue. |

References use `name` or `name.key`. Names cannot overwrite visible bindings. Compilation checks scope, verb, operation arity, ID interpolation and nested output names. Nested dictionary keys, operation return types and uniqueness of dynamically generated IDs are author responsibilities. Supply stable unique IDs to support joins across runs.

For a complete third exercise, read `test_external.py`. Its `SWATCHES` recipe displays each selected color, asks for a match, then scores the response. The exercise's two registered functions control visibility and scoring. The interpreter has no knowledge of colors. Its tests exercise a failed first swatch, independent continuation, duplicate JSON members, provider-side mutation, and compilation failures.

Edit the shipped `word.json` to change branching, or `board.json` to change the play sequence. For a private variant, read your own JSON file with `json.loads(path.read_text())`, replace the delivery operation in the registry with your own two-argument function, and pass the data and registry to `Recipe`. For example, `Recipe(steps, {**WORD_OPS, "clipped": my_channel}).run(config, provider)` reuses the complete word exercise with a different channel. Import `WORD_OPS` from `framework_lab.recipes.cases` and pass a normalized word configuration with an arms list. Question constructors own public disclosure and the finite legal-action catalog. Keep hidden state outside observations, instructions and choices. Each C4 arm receives a fragment from the single sampled sender choice. Each C2 play starts from the configured board with fresh controlled noise. Score and action are separate trace fields. Calibration gets its own question and result.

The executor processes one trial synchronously. A reproducible provider and controlled shocks are needed to reproduce a live trial. Stored request/reply pairs allow inspection without calling the provider. Registered operations are trusted Python and can access any arguments explicitly passed to them. Enumerating every legal response is inexpensive for these exercises and can be impractical for large or continuous action spaces.

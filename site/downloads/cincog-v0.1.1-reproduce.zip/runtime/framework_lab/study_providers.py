"""Live and evidence-backed participants for registered, trusted local studies."""
from contextlib import contextmanager
from copy import deepcopy
import json

from .objects import UnsupportedDecision


def same(a, b, *, ordered=False):
    # Printed property order matters on the actual model request. JSON scalar types always matter.
    return json.dumps(a, sort_keys=not ordered, allow_nan=False) == json.dumps(b, sort_keys=not ordered, allow_nan=False)


def provider_settings(spec, module):
    if not isinstance(spec, dict):
        raise ValueError("a provider must be an object")
    kind = spec.get("kind")
    defaults = {"first_legal": {}, "callable": {"seed": 61101}, "ollama_chat": {"temperature": 0, "seed": 61101},
                "systemone": {"selection": "argmax", "seed": 61101},
                "next_token": {"selection": "argmax", "seed": 61101, "port": 8080,
                               "codebook": "decimal", "prompt_edits": "off"}}
    required = {"first_legal": set(), "callable": {"factory"}, "ollama_chat": {"model"},
                "systemone": {"model"}, "next_token": {"model"}}
    if kind not in defaults or set(spec) - ({"kind"} | required[kind] | defaults[kind].keys()) or required[kind] - spec.keys():
        raise ValueError(f"unknown or incomplete provider settings for {kind!r}")
    cfg = {"kind": kind, **defaults[kind], **spec}
    if kind == "next_token" and "prompt_edits" not in spec and cfg["codebook"] == "ascii64":
        cfg["prompt_edits"] = "auto"
    if "seed" in cfg and type(cfg["seed"]) is not int:
        raise ValueError("participant seed must be an integer")
    if kind == "callable":
        if not isinstance(cfg["factory"], str) or not cfg["factory"].isidentifier() or not callable(getattr(module, cfg["factory"], None)):
            raise ValueError("a callable provider needs a factory in the study module")
    if kind in ("systemone", "next_token"):
        scored(cfg)  # Constructor validates settings without contacting a model.
    if kind == "ollama_chat":
        if not isinstance(cfg["model"], str) or not cfg["model"].strip():
            raise ValueError("ollama_chat needs a local model name")
        ChatParticipant(cfg)
    return cfg


def scored(cfg):
    opts = {k: v for k, v in cfg.items() if k != "kind"}
    if cfg["kind"] == "systemone":
        from .ollama_decision import OllamaDecision
        return OllamaDecision(**opts)
    from .llama_decision import LlamaCppDecision
    return LlamaCppDecision(**opts)


def first_action(request):
    fields = request["schema"]["anyOf"][0]["properties"]
    args = {name: field["enum"][0] if "enum" in field else ""
            for name, field in fields["args"]["properties"].items()}
    return json.dumps({"action": fields["action"]["const"], "args": args})


class TextParticipant:
    def __init__(self, call, binding):
        self.call = call
        self.binding = deepcopy(binding)
        self.wire = []

    def __call__(self, request):
        row = {"binding": self.binding, "request": deepcopy(request)}
        self.wire.append(row)
        try:
            answer = self.call(request)
        except UnsupportedDecision as exc:
            row["unsupported"] = str(exc)
            raise UnsupportedDecision(str(exc)) from exc
        except Exception as exc:
            row["failure"] = {"type": type(exc).__name__, "message": str(exc)}
            raise RuntimeError("participant failed") from exc
        if type(answer) is str:
            row["raw"] = answer
            return answer
        row["non_text"] = True
        return None


class ChatParticipant:
    def __init__(self, cfg, transport=None):
        from .providers import LocalOllama
        self.adapter = LocalOllama(cfg["model"], cfg["seed"], temperature=cfg["temperature"])
        self.transport = transport or self.send
        self.wire = []

    @staticmethod
    def send(body):
        from http.client import HTTPException
        from .ollama_decision import local_request
        try:
            return local_request("/api/chat", body, timeout=150)
        except (OSError, HTTPException) as exc:
            return {"transport_error": type(exc).__name__}

    def __call__(self, request):
        body = self.adapter.body(request)
        receipt = self.transport(body)
        self.wire.append({"body": body, "receipt": receipt})
        if "transport_error" in receipt or receipt.get("status") != 200:
            raise ConnectionError("local chat request failed")
        return self.adapter.content(receipt["response"])


def live(cfg, module):
    kind = cfg["kind"]
    if kind == "first_legal":
        return TextParticipant(first_action, cfg)
    if kind == "callable":
        call = getattr(module, cfg["factory"])(cfg["seed"])
        if not callable(call):
            raise ValueError("participant factory must return a callable")
        return TextParticipant(call, cfg)
    if kind == "ollama_chat":
        return ChatParticipant(cfg)
    return scored(cfg)


@contextmanager
def replay_participant(cfg, wire):
    if cfg["kind"] in ("systemone", "next_token"):
        if cfg["kind"] == "systemone":
            from .ollama_decision import replaying
        else:
            from .llama_decision import replaying
        with replaying(scored(cfg).identity(), wire) as participant:
            yield participant
        return
    rows = iter(wire)
    mismatch = False

    if cfg["kind"] == "ollama_chat":
        def transport(body):
            nonlocal mismatch
            row = next(rows, None)
            if not isinstance(row, dict) or not same(row.get("body"), body, ordered=True):
                mismatch = True
                raise ValueError("different chat request")
            return row["receipt"]
        participant = ChatParticipant(cfg, transport)
        yield participant
        if mismatch or next(rows, None) is not None or not same(participant.wire, wire):
            raise ValueError("chat request or receipt count differs")
        return

    def reply(request):
        nonlocal mismatch
        row = next(rows, None)
        if (not isinstance(row, dict) or not same(row.get("binding"), cfg)
                or not same(row.get("request"), request, ordered=True)):
            mismatch = True
            raise ValueError("different participant request")
        if cfg["kind"] == "first_legal" and row.get("raw") != first_action(request):
            mismatch = True
            raise ValueError("first-choice fixture response differs from its schema")
        if set(row) == {"binding", "request", "raw"} and type(row["raw"]) is str:
            return row["raw"]
        if set(row) == {"binding", "request", "non_text"} and row["non_text"] is True:
            return None
        if set(row) == {"binding", "request", "unsupported"} and type(row["unsupported"]) is str:
            raise UnsupportedDecision(row["unsupported"])
        if set(row) == {"binding", "request", "failure"} and isinstance(row["failure"], dict) and set(row["failure"]) == {"type", "message"} and all(isinstance(v, str) for v in row["failure"].values()):
            raise RuntimeError("saved participant failed")
        mismatch = True
        raise ValueError("invalid participant receipt")

    yield reply
    if mismatch or next(rows, None) is not None:
        raise ValueError("participant requests or receipt count differ")

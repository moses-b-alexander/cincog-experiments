"""Shared case data, input fixtures and football physics. No model I/O or trial runner."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Sequence
from importlib.resources import files
from statistics import NormalDist

WORDS = tuple(files(__package__).joinpath("words.txt").read_text(encoding="ascii").splitlines())
OFFENSE = (2, 1, 0, 0, 0, 0, 0, 0, 2)
DEFENSE = (0, 0, 0, 0, 0, 0, 0, 0, 6)
ARMS = ("whole", "elide_first", "elide_second")
C2_RULES = (
    "Cells 0..8 are row-major: short, intermediate, deep rows; left, center, right columns. "
    "Actual personnel shares determine yards. Depth and width use cumulative marginal "
    "distances divided by 2; joint distance is minimum Manhattan transport divided by 4. "
    "Mean = 10*(.25*depth + .25*width + .5*joint). For either roster let H=sum(share^2), "
    "C=(H-1/n)/(1-1/n) for n players, P=((C-.25)/(.25 if C<=.25 else .75))^2. "
    "Normal noise has SD .5+.75*(P_offense+P_defense); clip yards to [0,10]. "
    "Personnel reset each play. Moving one player requires an occupied source and a "
    "different destination. Explicit do_nothing also resolves a play."
)


def _roster(values: Sequence[int], n: int) -> list[int]:
    if not isinstance(values, (list, tuple)) or len(values) != 9:
        raise ValueError("a roster needs nine cells")
    if any(type(x) is not int or x < 0 for x in values) or sum(values) != n:
        raise ValueError(f"roster must contain {n} players in nonnegative integer cells")
    return list(values)


def settings(case: str, config: dict | None = None) -> dict:
    """Resolve baseline fixtures into detached values; no execution or policy here."""
    if config is None:
        config = {}
    if not isinstance(config, dict):
        raise ValueError("config must be an object")
    if case == "C4":
        if set(config) - {"arms", "assigned_word"}:
            raise ValueError("unknown C4 setting")
        arms = config.get("arms", ARMS)
        if not isinstance(arms, (list, tuple)) or not arms or any(a not in ARMS for a in arms):
            raise ValueError("invalid C4 arms")
        if len(set(arms)) != len(arms):
            raise ValueError("duplicate C4 arm")
        result = {"arms": list(arms)}
        if "assigned_word" in config:
            if config["assigned_word"] not in WORDS:
                raise ValueError("assigned word is outside the catalog")
            result["assigned_word"] = config["assigned_word"]
        return result
    if case != "C2":
        raise ValueError(f"unknown fixture {case!r}")
    if set(config) - {"offense", "defense", "appearance", "horizon", "seed", "shocks", "assigned_qb"}:
        raise ValueError("unknown C2 setting")
    horizon = config.get("horizon", 4)
    seed = config.get("seed", 91001)
    if type(horizon) is not int or not 4 <= horizon <= 10 or type(seed) is not int:
        raise ValueError("expected 4..10 plays and an integer seed")
    result = {
        "offense": _roster(config.get("offense", OFFENSE), 5),
        "defense": _roster(config.get("defense", DEFENSE), 6),
        "appearance": _roster(config.get("appearance", DEFENSE), 6),
        "horizon": horizon, "seed": seed, "shocks": None,
    }
    if config.get("shocks") is not None:
        tape = config["shocks"]
        if not isinstance(tape, (list, tuple)) or len(tape) != horizon:
            raise ValueError("supply one standard-normal shock per play")
        if any(type(v) not in (int, float) or not math.isfinite(v) for v in tape):
            raise ValueError("all shocks must be finite numbers")
        result["shocks"] = list(tape)
    if "assigned_qb" in config:
        value = config["assigned_qb"]
        if not isinstance(value, dict) or set(value) != {"action", "args"}:
            raise ValueError("expected a calibration action with arguments")
        args = value["args"]
        if value["action"] == "move_person" and isinstance(args, dict) and set(args) == {"from_cell", "to_cell"}:
            a, b = args["from_cell"], args["to_cell"]
            if any(type(x) is not int or not 0 <= x < 9 for x in (a, b)) or a == b or not result["offense"][a]:
                raise ValueError("unavailable calibration move")
        elif value["action"] != "do_nothing" or args != {}:
            raise ValueError("unavailable calibration action")
        result["assigned_qb"] = {"action": value["action"], "args": dict(args)}
    return result


def shock(seed: int, play: int) -> float:
    """A new independent keyed generator. Archived comparisons inject their actual shocks."""
    if type(seed) is not int or type(play) is not int or play < 1:
        raise ValueError("expected integer seed and positive play number")
    key = f"cincog-lab-v1|{seed}|{play}|yards".encode("ascii")
    bits = int.from_bytes(hashlib.sha256(key).digest()[:8], "big") >> 12
    return NormalDist().inv_cdf((bits + 0.5) / (1 << 52))


def _transport(balance: list[int]) -> int:
    """Minimum integer cell-steps on a 3x3 grid. Residual arcs allow rerouting."""
    # Each of the thirty equal units initially belongs to one offense and one defense share.
    source, sink = 9, 10
    graph = [[] for _ in range(11)]
    def edge(a, b, capacity, cost):
        graph[a].append([b, capacity, cost, len(graph[b])])
        graph[b].append([a, 0, -cost, len(graph[a]) - 1])
    for i, amount in enumerate(balance):
        if amount > 0:
            edge(source, i, amount, 0)
        elif amount < 0:
            edge(i, sink, -amount, 0)
        for neighbor in (i + 1, i + 3):
            if neighbor < 9 and (neighbor == i + 3 or i // 3 == neighbor // 3):
                edge(i, neighbor, 30, 1)
                edge(neighbor, i, 30, 1)
    cost = 0
    remaining = sum(max(0, x) for x in balance)
    while remaining:
        distances = [math.inf] * 11
        distances[source] = 0
        path = [None] * 11
        for _ in range(10):
            changed = False
            for a, arcs in enumerate(graph):
                for index, (b, capacity, weight, _) in enumerate(arcs):
                    if capacity and distances[a] + weight < distances[b]:
                        distances[b] = distances[a] + weight
                        path[b] = (a, index)
                        changed = True
            if not changed:
                break
        amount, node = remaining, sink
        while node != source:
            a, index = path[node]
            amount = min(amount, graph[a][index][1])
            node = a
        node = sink
        while node != source:
            a, index = path[node]
            arc = graph[a][index]
            arc[1] -= amount
            graph[node][arc[3]][1] += amount
            node = a
        cost += amount * distances[sink]
        remaining -= amount
    return cost


def _noise_departure(roster: list[int], n: int) -> float:
    concentration = (sum(x*x for x in roster) - n) / (n*n - n)
    scale = 0.25 if concentration <= 0.25 else 0.75
    return ((concentration - 0.25) / scale) ** 2


def yards(offense_after: Sequence[int], defensive_actual: Sequence[int], z: float) -> float:
    offense = _roster(offense_after, 5)
    defense = _roster(defensive_actual, 6)
    if type(z) not in (int, float) or not math.isfinite(z):
        raise ValueError("expected a finite standard-normal shock")
    balance = [6*a - 5*b for a, b in zip(offense, defense)]
    depth = (abs(sum(balance[:3])) + abs(sum(balance[:6]))) / 60
    width = (abs(sum(balance[0::3])) + abs(sum(balance[2::3]))) / 60
    joint = _transport(balance) / 120
    mean = 10 * (0.25*depth + 0.25*width + 0.5*joint)
    sigma = 0.5 + 0.75 * (_noise_departure(offense, 5) + _noise_departure(defense, 6))
    return min(10.0, max(0.0, mean + sigma*z))

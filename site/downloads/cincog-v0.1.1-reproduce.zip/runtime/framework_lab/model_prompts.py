"""Versioned edits to a model's rendered finite-choice prompt, before tokenization."""
import hashlib


POLICY_V1 = "model-edits-v1"
ERNIE_WEIGHTS = "9842768d0fa26c6565611161c2d6135e79275a3726141478719cfa191cc670dd"
ERNIE_ORIGINAL_TEMPLATE = "471fb571976770318fe6f27749e37940be8d29c0a7770558140f141f5906f2a2"
ERNIE_NEWLINE_TEMPLATE = "fed22dcf76e4374391b91e56f1a76f2c223aa51f9060d9800a5af521f48c78e2"


def _ernie_newline(prompt, template):
    cue = "\nAssistant:"
    if template == ERNIE_ORIGINAL_TEMPLATE and prompt.endswith(cue + " "):
        return prompt[:-1] + "\n", "applied"
    if template == ERNIE_NEWLINE_TEMPLATE and prompt.endswith(cue + "\n"):
        return prompt, "already_compatible"
    return prompt, "no_match"


def _model_validate(model, runtime):
    """Select only a qualified checkpoint or declared alias and matching model dimensions."""
    meta = runtime["model_metadata"]
    # The generic scorer can see an Ollama blob name or a researcher-assigned alias.
    # The latter alone is not a checksum of a local GGUF.
    digest = runtime["blob_digest_from_name"]
    identity = ({ERNIE_WEIGHTS: "baidu/ernie-4.5-0.3b-pt"}.get(digest.lower())
                if digest else model.casefold())
    match identity, meta.get("n_params"), meta.get("n_vocab"):
        case ("baidu-ernie-4.5-0.3b-pt" | "baidu/ernie-4.5-0.3b-pt"), 360748032, 103424:
            return "ernie-4.5-0.3b-pt-answer-newline-v1", _ernie_newline
    return None


def edit_rendered_prompt(model, runtime, prompt):
    """Apply the v1 ASCII64 rules and return an auditable change for a recognized model."""
    rule = _model_validate(model, runtime)
    if rule is None:
        return prompt, None
    name, editor = rule
    effective, status = editor(prompt, runtime["template_sha256"])
    return effective, {
        "rule": name,
        "status": status,
        "rendered_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
        "effective_sha256": hashlib.sha256(effective.encode()).hexdigest(),
    }

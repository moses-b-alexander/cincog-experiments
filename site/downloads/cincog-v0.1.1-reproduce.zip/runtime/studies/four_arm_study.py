"""External four-arm word study. Run with framework_lab on PYTHONPATH."""
import json

from framework_lab.domain import WORDS
from framework_lab.objects import Decision, Field, Form, Session, View
from framework_lab.recipes import Question, Recipe
from framework_lab.scripted import Recorder, command


ARMS = ("whole", "first", "last", "blank")
GOAL = {"metric": "exact_recovery", "direction": "maximize", "horizon": 1}
RULE = ("A chooses one word. C sees the whole word, first four letters, "
        "last four letters, or an empty string. C guesses A's original word.")
MENU = tuple({"action": "choose_word", "args": {"word": w}} for w in WORDS)


def delivery(word, arm):
    return {"whole": word, "first": word[:4], "last": word[4:], "blank": ""}[arm]


def selected(action):
    return action["args"]["word"] if action is not None else None


def row(arm, clue, guess, word):
    return dict(arm=arm, fragment=clue, guess=guess,
                score=None if guess is None else guess == word)


def question_data(clue=None):
    if clue is None:
        return "A", {"role": "A"}, GOAL, RULE + " Choose a word."
    return "C", {"role": "C", "fragment": clue}, GOAL, RULE + " Guess the original word."


def python_turns(ask):
    word = ask("sender", None)
    rows = []
    if word is not None:
        for arm in ARMS:
            clue = delivery(word, arm)
            rows.append(row(arm, clue, ask(f"receiver/{arm}", clue), word))
    return {"word": word, "rows": rows}


def script_study(provider):
    rec = Recorder(provider)
    menu = [command("choose_word", word=w) for w in WORDS]

    def ask(tag, clue):
        role, obs, objective, instruction = question_data(clue)
        return selected(rec.choose(tag, role=role, observation=obs, objective=objective,
                                   instruction=instruction, menu=menu))

    return rec.finish(python_turns(ask))


def object_study(provider):
    session = Session(provider)
    forms = (Form("choose_word", (Field("word", tuple(WORDS)),)),)

    def ask(tag, clue):
        decision = Decision(View(*question_data(clue)), forms)
        choice = session.ask(tag, decision)
        return None if choice is None else dict(choice.arguments)["word"]

    return session.trace(python_turns(ask))


STEPS = [
    ["call", "task", "question"],
    ["ask", "reply", "task", "sender"],
    ["call", "word", "selected", "reply"],
    ["when", "branches", "word", [
        ["each", "rows", "config.arms", "arm", [
            ["call", "clue", "delivery", "word", "arm"],
            ["call", "prompt", "question", "clue"],
            ["ask", "answer", "prompt", "receiver/{arm}"],
            ["call", "guess", "selected", "answer"],
            ["call", "row", "row", "arm", "clue", "guess", "word"],
        ], "row"],
    ], "rows"],
    ["call", "result", "assemble", "word", "branches"],
]


def recipe_study(provider):
    ops = {"question": lambda clue=None: Question(*question_data(clue), MENU),
           "selected": selected, "delivery": delivery, "row": row,
           "assemble": lambda word, branches: {"word": word, "rows": branches or []}}
    return Recipe(STEPS, ops).run({"arms": list(ARMS)}, provider)


def verify(run, fail_first=False):
    requests = []

    def provider(request):
        requests.append(request)
        clue = request["observation"].get("fragment")
        if fail_first and clue == "fire":
            raise RuntimeError("receiver unavailable")
        guess = "baseball" if clue == "" else "firewood"
        return json.dumps({"action": "choose_word", "args": {"word": guess}})

    trace = run(provider)
    expected = [None, "firewood", "fire", "wood", ""]
    assert [r["observation"] for r in requests] == [question_data(c)[1] for c in expected]
    assert [r["role"] for r in requests] == ["A", "C", "C", "C", "C"]
    assert all(r["instruction"] == question_data(c)[3] for r, c in zip(requests, expected))
    assert all(r["schema"] == requests[1]["schema"] for r in requests[1:])
    result = trace["result"]
    assert result["word"] == "firewood"
    assert [r["arm"] for r in result["rows"]] == list(ARMS)
    assert [r["fragment"] for r in result["rows"]] == expected[1:]
    assert [r["score"] for r in result["rows"]] == [True, None if fail_first else True, True, False]


if __name__ == "__main__":
    for candidate in (script_study, object_study, recipe_study):
        verify(candidate)
        verify(candidate, fail_first=True)
        print(candidate.__name__, "passed normal and single-receiver failure trials")

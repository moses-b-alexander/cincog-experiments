"""Serial, resumable C4 cross-backend durability study. Raw records belong in an ignored run directory."""
import argparse
from contextlib import contextmanager
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import random
import socket
import subprocess
import time
from urllib.request import build_opener, ProxyHandler

from framework_lab.__main__ import replay_choice_record
from framework_lab.decision_spec import run_spec
from framework_lab.domain import WORDS
from framework_lab.llama_decision import LlamaCppDecision
from framework_lab.model_prompts import POLICY_V1
from framework_lab.ollama_decision import OllamaDecision
from studies.distribution import decision, deliveries
from studies.native_s1_sweep import ARMS, SEED, alias_binding, check_runtime_usage

NATIVE = {
    "kev:0.8b-q8_0": "kev:0.8b-q8_0", "d3:2b": "d3:2b", "laya:421m-english-bf16": "laya:421m-english-bf16",
    "laya:421m-typed-decisions-bf16": "laya:421m-typed-decisions-bf16",
    "laya:322m-multilingual-bf16": "laya:322m-multilingual-bf16",
    "d3:4b-q8_0": "cincog-d3-4b:q8-4k", "kev:4b-q8_0": "cincog-kev-4b:q8-2k",
    "kev:9b-q4_K_M": "cincog-kev-9b:q4-2k", "tev1:0.8b-q8_0": "tev1:0.8b-q8_0",
    "tev1:4b-q4_K_M": "tev1:4b-q4_K_M", "nimble:9b-q4_K_M": "nimble:9b-q4_K_M",
}
LLMS = ["phi4-mini:3.8b", "llama3.2:3b", "granite3.3:2b", "gemma3:4b", "qwen2.5:3b", "qwen3:8b"]


def save(path, obj):
    tmp = path.with_suffix(path.suffix + ".tmp")
    with (gzip.open(tmp, "wt", encoding="utf-8", compresslevel=1) if path.suffix == ".gz"
          else tmp.open("w", encoding="utf-8")) as stream:
        json.dump(obj, stream, allow_nan=False, ensure_ascii=True, separators=(",", ":"))
    tmp.replace(path)


def load(path):
    with (gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open(encoding="utf-8")) as stream:
        return json.load(stream)


def pin(path, obj):
    if path.exists():
        if load(path) != obj:
            raise ValueError(f"changed study binding at {path}")
    else:
        save(path, obj)


def spec_for(clue):
    public = decision(clue).request()
    forms = public.pop("schema")["anyOf"]
    public["tools"] = [{"type": "function", "function": {
        "name": form["properties"]["action"]["const"], "parameters": form["properties"]["args"]}} for form in forms]
    return public


def plan(out):
    targets = random.Random(SEED).choices(WORDS, k=3)
    jobs = []
    for rep in range(1, 4):
        block = []
        for i, target in enumerate(targets):
            for j, arm in enumerate(ARMS):
                block.append({"id": f"r{rep}-w{i+1}-{arm}", "repeat": rep, "target": target, "arm": arm,
                              "clue": deliveries(target)[arm], "seed": SEED + (rep-1)*9 + i*3 + j})
        random.Random(SEED + rep).shuffle(block)
        jobs.extend(block)
    out.mkdir(parents=True, exist_ok=True)
    pin(out / "manifest.json", {"bank": list(WORDS), "targets": targets, "jobs": jobs, "role": "C",
                                "selection": "sample", "reference_seed": SEED, "public_example": spec_for("CLUE")})
    return jobs


def model_dir(out, model):
    parts = model.replace(":", "/").split("/")
    if (any(not part.strip(".") for part in parts)
            or any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-.:/" for ch in model)):
        raise ValueError("invalid model tag")
    return out / model.replace(":", "_").replace("/", "_")


def model_file(tag):
    store = Path(os.environ.get("OLLAMA_MODELS") or Path.home() / ".ollama/models")
    name, _, variant = tag.partition(":")
    name = name if "/" in name else "library/" + name
    manifest = store / "manifests/registry.ollama.ai" / name / (variant or "latest")
    data = load(manifest)
    layer, = [v for v in data["layers"] if v["mediaType"] == "application/vnd.ollama.image.model"]
    path = store / "blobs" / layer["digest"].replace(":", "-")
    if path.stat().st_size != layer["size"]:
        raise ValueError("weight size mismatch")
    return path


def weight_digest(path):
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            sha.update(block)
    digest = sha.hexdigest()
    if path.name.startswith("sha256-") and path.name[7:] != digest:
        raise ValueError("Ollama weight bytes differ from content address")
    return digest


def launch_signature(command):
    args = list(command)
    i = args.index("--port")
    del args[i:i + 2]
    return args


@contextmanager
def server(model, folder, weights, runner, extra):
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    command = [str(runner), "-m", str(weights), "--alias", model, "--host", "127.0.0.1", "--port", str(port),
               "-c", "4096", "-np", "1", "-ngl", "auto", "--no-webui", "--no-warmup",
               "--reasoning", "off", "--chat-template-kwargs", '{"enable_thinking":false}', *extra]
    launch = folder / "launch.json"
    if launch.exists() and launch_signature(load(launch)) != launch_signature(command):
        raise ValueError("study launch flags changed")
    signature = {"command": launch_signature(command), "weights_sha256": weight_digest(weights),
                 "backend_plugin": os.environ.get("GGML_BACKEND_PATH"), "codebook": "ascii64"}
    pin(folder / "launch-binding.json", signature)
    with (folder / "server.log").open("ab") as log:
        proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        try:
            client = build_opener(ProxyHandler({}))
            for _ in range(300):
                if proc.poll() is not None:
                    raise RuntimeError(f"server exited {proc.returncode}; see {folder / 'server.log'}")
                try:
                    with client.open(f"http://127.0.0.1:{port}/health", timeout=2) as res:
                        if res.status == 200:
                            break
                except OSError:
                    time.sleep(.5)
            else:
                raise TimeoutError("model startup timed out")
            if not launch.exists():
                save(launch, command)
            yield port
        finally:
            if proc.poll() is None:
                proc.terminate()
            proc.wait(timeout=30)


def run_cells(out, model, factory, binding=None):
    jobs = plan(out)
    folder = model_dir(out, model)
    folder.mkdir(exist_ok=True)
    if binding is not None:
        pin(folder / "origin.json", binding)
    pending = []
    def stable_binding(b):
        return {k: v for k, v in b.items() if k != "port"}
    for n, job in enumerate(jobs, 1):
        file = folder / (job["id"] + ".json.gz")
        spec = spec_for(job["clue"])
        participant = factory(job["seed"])
        if file.exists():
            earlier = load(file)
            if (earlier["assignment"] != job or earlier["spec"] != spec
                    or stable_binding(earlier["binding"]) != stable_binding(participant.identity())
                    or not all(e["status"] == "accepted" for e in earlier["decisions"])):
                raise ValueError(f"existing receipt has wrong assignment or binding: {file}")
            replay_choice_record(earlier)
            if "runtime" in earlier["wire"][-1]:
                pin(folder / "runtime.json", earlier["wire"][-1]["runtime"])
            continue
        pending.append((n, job, file, spec, participant))
    for index, (n, job, file, spec, participant) in enumerate(pending):
        started = time.monotonic()
        trace = run_spec(spec, participant)
        record = {"version": 1, "candidate": "objects", "case": "spec", "spec": spec, "binding": participant.identity(),
                  "wire": participant.wire, **trace, "assignment": job, "elapsed_s": time.monotonic() - started}
        row = trace["decisions"][0]
        if row["status"] != "accepted":
            previous = list(folder.glob(job["id"] + "*.failure.json.gz"))
            suffix = f".{len(previous) + 1}" if previous else ""
            save(folder / (job["id"] + suffix + ".failure.json.gz"), record)
            wire = participant.wire[-1] if participant.wire else {}
            raise RuntimeError(f"{row['status']}: {wire.get('invalid_response') or row.get('error') or str(wire.get('response',''))[:300]}")
        if row["attempts"][0]["request"]["schema"] != decision(job["clue"]).request()["schema"]:
            raise ValueError("published schema disagrees with historical C4")
        wire = participant.wire[-1]
        if binding:
            check_runtime_usage(wire, binding)
        if "runtime" in wire:
            pin(folder / "runtime.json", wire["runtime"])
        if set(wire["probabilities"]) != set(WORDS) or not math.isclose(math.fsum(wire["probabilities"].values()), 1, abs_tol=1e-6):
            raise ValueError("invalid word vector")
        if index == 0:
            replay_choice_record(record)
        save(file, record)
        if n in (1, 9, 18, 27):
            print(f"{model}: {n}/27", flush=True)


def resume_options(folder, requested):
    accepted = next((path for path in sorted(folder.glob("r*.json.gz"))
                     if not path.name.endswith(".failure.json.gz")), None)
    prior = accepted or next(folder.glob("*.failure.json.gz"), None)
    if prior is None:
        return {"prompt_edits": requested or "off"}

    saved = load(prior)["binding"]
    policy = saved.get("prompt_policy", "off")
    if requested is not None and (POLICY_V1 if requested == "auto" else requested) != policy:
        raise ValueError(f"select a new output directory to change the prompt policy for {folder.name}")
    options = {"prompt_edits": policy}
    if accepted:
        options.update({key: saved.get(key, False) for key in ("canonical_echo", "join_separator")})
    return options


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("route", choices=["native", "llm"])
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--model", action="append")
    parser.add_argument("--weights", type=Path, help="explicit GGUF for one model")
    parser.add_argument("--runner", type=Path, default=Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Ollama/lib/ollama/llama-server.exe")
    parser.add_argument("--runner-arg", action="append", default=[])
    parser.add_argument("--prompt-edits", choices=("auto", "off"), help="model prompt policy (default for this replication: off)")
    args = parser.parse_args()
    models = args.model or (list(NATIVE) if args.route == "native" else LLMS)
    if args.weights and len(models) != 1:
        parser.error("--weights requires exactly one --model")
    if args.prompt_edits and args.route != "llm":
        parser.error("--prompt-edits requires the llm route")
    out = args.out.resolve()
    # An incompatible resume must leave every requested model's evidence intact.
    options = {}
    if args.route == "llm":
        try:
            options = {model: resume_options(model_dir(out, model), args.prompt_edits) for model in models}
        except (ValueError, OSError, EOFError, KeyError, TypeError) as exc:
            parser.error(str(exc))
    plan(out)
    failures = []
    for model in models:
        folder = model_dir(out, model)
        folder.mkdir(exist_ok=True)
        try:
            if args.route == "native":
                runtime = NATIVE.get(model, model)
                bound = alias_binding(model, runtime)
                try:
                    run_cells(out, model, lambda seed: OllamaDecision(runtime, selection="sample", seed=seed), bound)
                finally:
                    subprocess.run(["ollama", "stop", runtime], capture_output=True, timeout=60)
            else:
                weights = args.weights or model_file(model)
                with server(model, folder, weights, args.runner, args.runner_arg) as port:
                    run_cells(out, model, lambda seed: LlamaCppDecision(model, port=port, selection="sample",
                                                                         seed=seed, codebook="ascii64", **options[model]))
        except (RuntimeError, ValueError, OSError, TimeoutError) as exc:
            print(f"{model}: FAILED {exc}", flush=True)
            save(folder / "unavailable.json", {"reason": str(exc)})
            failures.append([model, str(exc)])
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())

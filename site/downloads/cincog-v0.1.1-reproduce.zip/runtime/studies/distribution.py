"""Controlled C4 receiver guesses. Run or check a fixed local pilot from its manifest."""

import argparse
from collections import Counter
import json
from pathlib import Path

from framework_lab.domain import WORDS
from framework_lab.ollama_decision import OllamaDecision, replay as replay_decision
from framework_lab.objects import Decision, Field, Form, Session, View
from framework_lab.providers import LocalOllama


TARGET = "firewood"
MODELS = ("phi4-mini:3.8b", "granite3.3:2b")
SEEDS_PER_CELL = 8
TEMPERATURE = 0.7
FOCAL = ("fireball", "firewood", "firework")
INSTRUCTION = (
    "An eight-letter word was selected from the word bank. Your clue contains either "
    "the whole word, its first four letters, its last four letters, or its letters at "
    "positions 1, 3, 5 and 7 in that order (counting from 1). Choose the original "
    "word from the bank. Recovery succeeds when your guess matches it exactly."
)


def deliveries(word):
    return {"whole": word, "prefix": word[:4], "suffix": word[4:], "alternating": word[::2]}


def decision(fragment):
    view = View("C", {"fragment": fragment},
                {"metric": "exact_recovery", "direction": "maximize", "horizon": 1},
                INSTRUCTION)
    return Decision(view, (Form("choose_word", (Field("word", WORDS),)),))


def schedule(models=MODELS):
    """Rotate condition and model order by block. Every trial has its own seed and context."""
    rows = []
    fragments = deliveries(TARGET)
    arms = list(fragments)
    for block in range(SEEDS_PER_CELL):
        for model in (models if block % 2 == 0 else models[::-1]):
            for offset in range(len(arms)):
                arm = arms[(block + offset) % len(arms)]
                idx = len(rows) + 1
                rows.append({"id": f"trial-{idx:03}", "block": block + 1,
                             "model": model, "arm": arm, "fragment": fragments[arm],
                             "seed": 320000 + idx})
    return rows


def save(path, obj):
    pending = path.with_suffix(".tmp")
    pending.write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    pending.replace(path)


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def plan(decision_model=None, selection="argmax"):
    if selection not in ("argmax", "sample") or (decision_model is None and selection != "argmax"):
        raise ValueError("Native decision selection must be argmax or sample")
    if decision_model is not None and (not isinstance(decision_model, str) or not decision_model.strip()):
        raise ValueError("supply a local decision model ID")
    models = (decision_model,) if decision_model else MODELS
    settings = ({"provider": "local_ollama_systemone", "selection": selection} if decision_model
                else {"temperature": TEMPERATURE})
    return {"version": 1, "target": TARGET, "word_bank": list(WORDS),
            "prompt": INSTRUCTION, **settings, "models": list(models),
            "assignments_per_cell": SEEDS_PER_CELL, "assignments": schedule(models)}


def execute(row, provider):
    session = Session(provider)
    command = session.ask(row["id"], decision(row["fragment"]))
    guess = dict(command.arguments)["word"] if command else None
    return session.trace({"guess": guess, "exact": guess == TARGET if command else None})


def run(out, decision_model=None, selection="argmax", *, transport=None):
    manifest = plan(decision_model, selection)
    bindings = {}

    def participant(model, seed):
        if decision_model:
            return OllamaDecision(model, selection=selection, seed=seed, transport=transport)
        return LocalOllama(model, seed, temperature=TEMPERATURE)

    for model in manifest["models"]:
        descriptor = participant(model, 0).identity()
        bindings[model] = {k: v for k, v in descriptor.items() if k not in ("seed", "selection_seed")}
    out.mkdir(parents=True, exist_ok=False)
    save(out / "manifest.json", manifest)
    save(out / "models.json", bindings)
    for row in manifest["assignments"]:
        provider = participant(row["model"], row["seed"])
        if decision_model:
            binding = provider.identity()
        else:
            binding = {**bindings[row["model"]], "seed": row["seed"]}
        trace = execute(row, provider)
        save(out / (row["id"] + ".json"), {
            "assignment": row, "binding": binding,
            **trace, "wire": provider.wire,
        })
        if decision_model and any(w.get("status") in (401, 403, 429) for w in provider.wire):
            break
    return check(out)


def verify(row, record, binding):
    """Reconcile issued data, model settings, assistant text, admission and score offline."""
    if row != record["assignment"] or record["binding"] != {**binding, "seed": row["seed"]}:
        raise ValueError("assignment or binding mismatch")
    attempts = record["decisions"][0]["attempts"]
    wires = record["wire"]
    if len(attempts) != len(wires):
        raise ValueError("attempt and transport counts disagree")
    form = decision(row["fragment"])
    admitted = None
    status = "exhausted"
    if len(attempts) not in (1, 2):
        raise ValueError("expected one or two attempts")
    for index, (attempt, wire) in enumerate(zip(attempts, wires), 1):
        request = {**form.request(), "attempt": index}
        body = wire["body"]
        visible = {k: v for k, v in request.items() if k != "schema"}
        messages = [{"role": "system", "content": "Return one JSON action matching this schema. "
                     + json.dumps(request["schema"], separators=(",", ":"))},
                    {"role": "user", "content": json.dumps(visible, separators=(",", ":"))}]
        if (attempt["request"] != request or body["format"] != request["schema"]
                or body["messages"] != messages or body["model"] != row["model"]
                or body["options"] != {"seed": row["seed"], "temperature": TEMPERATURE,
                                       "num_ctx": binding["context"], "num_predict": binding["output_tokens"]}):
            raise ValueError("receiver prompt or wire options disagree")
        if "error" in wire:
            if index != len(wires) or attempt["raw"] is not None:
                raise ValueError("unexpected state after service error")
            status = "service_failure"
            break
        envelope = json.loads(wire["response"])
        content = envelope["message"]["content"]
        if (wire["status"] != 200 or envelope["model"] != row["model"]
                or envelope["done"] is not True or content != attempt["raw"]):
            raise ValueError("unexpected model receipt")
        admitted = form.admit(content)
        if admitted is not None:
            if index != len(wires):
                raise ValueError("retry after admission")
            status = "accepted"
            break
    if status == "exhausted" and len(wires) != 2:
        raise ValueError("exhaustion before allowed retry")
    event = record["decisions"][0]
    action = admitted.as_dict() if admitted else None
    guess = action["args"]["word"] if action else None
    expected_result = {"guess": guess, "exact": guess == TARGET if action else None}
    if (len(record["decisions"]) != 1 or event["id"] != row["id"] or event["status"] != status
            or event["action"] != action or record["result"] != expected_result):
        raise ValueError("admission or result mismatch")


def summarize(pairs):
    words = Counter()
    status = Counter()
    attempts = exact = 0
    for row, record in pairs:
        if record is None:
            status["not_started_or_unrecorded"] += 1
            continue
        event = record["decisions"][0]
        count = len(event["attempts"])
        attempts += count
        if event["status"] == "accepted":
            status["accepted_first" if count == 1 else "accepted_on_retry"] += 1
            words[record["result"]["guess"]] += 1
            exact += int(record["result"]["exact"])
        else:
            status[event["status"]] += 1
    failed = status["service_failure"] + status["exhausted"] + status["unsupported_form"]
    return {"planned": len(pairs), "attempts": attempts,
            "accepted_first": status["accepted_first"], "accepted_on_retry": status["accepted_on_retry"],
            "failed": failed, "exhausted": status["exhausted"], "service_failure": status["service_failure"],
            **({"unsupported_form": status["unsupported_form"]} if status["unsupported_form"] else {}),
            "not_started_or_unrecorded": status["not_started_or_unrecorded"],
            "guess_counts": dict(words.most_common()), "focal_counts": {w: words[w] for w in FOCAL},
            "other_valid": sum(n for w, n in words.items() if w not in FOCAL), "exact": exact}


def check(out):
    manifest = load(out / "manifest.json")
    native_decision = manifest.get("provider") == "local_ollama_systemone"
    expected = plan(manifest["models"][0], manifest["selection"]) if native_decision else plan()
    if manifest != expected:
        raise ValueError("manifest differs from this fixed study")
    bindings = load(out / "models.json")
    if native_decision:
        model = manifest["models"][0]
        if bindings != {model: {"provider": "local_ollama_systemone", "model": model,
                                "selection": manifest["selection"]}}:
            raise ValueError("provider bindings differ from the manifest")
    pairs = []
    for row in manifest["assignments"]:
        path = out / (row["id"] + ".json")
        record = load(path) if path.exists() else None
        if record is not None:
            try:
                if native_decision:
                    seed = row["seed"] if manifest["selection"] == "sample" else None
                    binding = {**bindings[row["model"]], "selection_seed": seed}
                    if record["assignment"] != row or record["binding"] != binding:
                        raise ValueError("assignment or binding mismatch")
                    trace = replay_decision(binding, record["wire"], lambda p: execute(row, p))
                    if any(json.dumps(v) != json.dumps(record[k]) for k, v in trace.items()):
                        raise ValueError("replayed trace differs from saved trace")
                else:
                    verify(row, record, bindings[row["model"]])
            except (ValueError, KeyError, IndexError) as exc:
                raise ValueError(f"{row['id']}: {exc}") from exc
        pairs.append((row, record))
    result = {"by_model": {}, "pooled_across_models": {}}
    for arm, fragment in deliveries(TARGET).items():
        matching = [(r, d) for r, d in pairs if r["arm"] == arm]
        result["pooled_across_models"][fragment] = summarize(matching)
        for model in manifest["models"]:
            subset = [(r, d) for r, d in matching if r["model"] == model]
            cell = summarize(subset)
            if native_decision:
                accepted = [d["wire"][-1] for _, d in subset
                            if d and d["decisions"][0]["status"] == "accepted"]
                cell["vector_count"] = len(accepted)
                cell["resolved_models"] = dict(Counter(w["resolved_model"] for w in accepted))
                cell["mean_probabilities"] = (
                    {word: sum(w["probabilities"][word] for w in accepted) / len(accepted)
                     for word in WORDS} if accepted else None)
            result["by_model"].setdefault(model, {})[fragment] = cell
    save(out / "summary.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["plan", "run", "check"])
    parser.add_argument("--output", type=Path)
    parser.add_argument("--ollama-s1", metavar="MODEL", help="use a native local Ollama decision model on the same four arms")
    parser.add_argument("--selection", choices=("argmax", "sample"))
    args = parser.parse_args()
    if args.selection and not args.ollama_s1:
        parser.error("--selection requires --ollama-s1")
    if args.mode == "plan":
        if args.output:
            parser.error("plan prints the manifest to standard output")
        print(json.dumps(plan(args.ollama_s1, args.selection or "argmax"), indent=2))
        raise SystemExit(0)
    if not args.output or (args.mode == "check" and args.ollama_s1):
        parser.error("supply --output; check reads provider settings from the saved manifest")
    try:
        summary = (run(args.output, args.ollama_s1, args.selection or "argmax")
                   if args.mode == "run" else check(args.output))
    except ValueError as exc:
        parser.exit(2, f"{exc}\n")
    print(json.dumps(summary["by_model"], indent=2))
    if args.mode == "run" and args.ollama_s1:
        cells = summary["by_model"][args.ollama_s1].values()
        raise SystemExit(2 if any(c["failed"] or c["not_started_or_unrecorded"] for c in cells) else 0)

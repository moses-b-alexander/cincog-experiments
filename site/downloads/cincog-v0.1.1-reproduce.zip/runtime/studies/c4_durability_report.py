"""Offline verification and analysis of a C4 durability panel."""
import argparse
from collections import defaultdict
import csv
import hashlib
from itertools import combinations
import json
import math
from pathlib import Path
from statistics import mean, median
from unittest.mock import patch
import socket

from framework_lab.__main__ import replay_choice_record
from framework_lab.choices import ChoiceView, choice_reports
from framework_lab.decision_spec import run_spec
from framework_lab.domain import WORDS
from framework_lab.ollama_decision import OllamaDecision
from studies.c4_durability import NATIVE, load, model_dir, plan, save, spec_for


def verify_condition(root, entry, jobs, reuse_checks=False):
    model = entry["model"]
    folder = model_dir(root, model)
    raw_files = [folder / (job["id"] + ".json.gz") for job in jobs]
    if not all(path.is_file() for path in raw_files):
        return None
    sums = [hashlib.sha256(path.read_bytes()).hexdigest() for path in raw_files]
    cached = folder / "verified.json"
    if reuse_checks and cached.exists():
        verified = load(cached)
        if verified["hashes"] == sums and verified["entry"] == entry and verified["jobs"] == jobs:
            return verified["rows"]
    rows = []
    for path, job in zip(raw_files, jobs, strict=True):
        record = load(path)
        expected_model = NATIVE.get(model, model)
        route = "local_ollama_systemone" if entry["route"] == "native" else "local_llama_next_token"
        binding = record["binding"]
        if (record["assignment"] != job or record["spec"] != spec_for(job["clue"])
                or record["case"] != "spec" or binding["provider"] != route or binding["model"] != expected_model
                or binding["selection"] != "sample" or binding["selection_seed"] != job["seed"]):
            raise ValueError(f"assignment or binding differs at {path}")
        if route == "local_llama_next_token" and binding.get("codebook") != "ascii64":
            raise ValueError(f"inconsistent codebook at {path}")
        trace = replay_choice_record(record)
        event, = trace["decisions"]
        reports = choice_reports({**record, **trace}, ChoiceView())
        row = reports[-1]
        wire = record["wire"][-1]
        probs = wire["probabilities"]
        if (not row["admitted"] or row["offered_count"] != 64 or set(probs) != set(WORDS)
                or any(r["command"] != {"action": "choose_word", "args": {"word": r["option"]}} for r in row["choices"])
                or row["selected_option"] != trace["result"]["action"]["args"]["word"]):
            raise ValueError(f"incomplete or misbound menu at {path}")
        result = {**job, "selected": row["selected_option"], "argmax": row["choices"][0]["option"],
                  "target_p": probs[job["target"]], "menu_mass": wire.get("menu_mass"),
                  "attempts": len(event["attempts"]), "elapsed_s": record["elapsed_s"], "probabilities": probs}
        if route == "local_llama_next_token":
            result["code_token_ids"] = wire["code_token_ids"]
            if wire["runtime"] != load(folder / "runtime.json"):
                raise ValueError(f"changed loaded checkpoint at {path}")
        rows.append(result)
    save(cached, {"entry": entry, "hashes": sums, "jobs": jobs, "rows": rows})
    return rows


def summarize(entry, rows):
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["target"], row["arm"]].append(row)
    group_rows = []
    for (word, arm), group in grouped.items():
        if sorted(r["repeat"] for r in group) != [1, 2, 3]:
            raise ValueError("expected three repeats")
        distances = [math.fsum(abs(a["probabilities"][w] - b["probabilities"][w]) for w in WORDS) / 2
                     for a, b in combinations(group, 2)]
        group_rows.append({"model": entry["model"], "target": word, "arm": arm, "clue": group[0]["clue"],
                           "mean_target_p": mean(r["target_p"] for r in group), "max_pair_tv": max(distances),
                           "min_target_p": min(r["target_p"] for r in group), "max_target_p": max(r["target_p"] for r in group),
                           "identical": max(distances) == 0, "argmax_stable": len({r["argmax"] for r in group}) == 1})
    raw_masses = [r["menu_mass"] for r in rows if r["menu_mass"] is not None]
    summary = {**entry, "accepted": len(rows), "first_attempts": sum(r["attempts"] == 1 for r in rows),
               "exact_groups": sum(g["identical"] for g in group_rows), "stable_argmax_groups": sum(g["argmax_stable"] for g in group_rows),
               "max_pair_tv": max(g["max_pair_tv"] for g in group_rows), "mean_target_p": mean(r["target_p"] for r in rows),
               "distinct_argmax": len({r["argmax"] for r in rows}),
               "sample_recoveries": sum(r["selected"] == r["target"] for r in rows),
               "median_menu_mass": median(raw_masses) if raw_masses else None, "min_menu_mass": min(raw_masses, default=None)}
    return summary, group_rows


def check_interface_control(rows):
    """Pass each observed LLM vector through a native-shaped test reply, entirely offline."""
    for row in rows:
        probs = row["probabilities"]
        def reply(body):
            if list(body["questions"]["decision"]["criteria"]) != list(WORDS):
                raise ValueError("different native interface menu order")
            answer = {"type": "choice", "choice": row["argmax"], "confidence": max(probs.values()), "probabilities": probs}
            return {"status": 200, "response": json.dumps({"model": "offline-control", "answers": {"decision": answer}})}
        participant = OllamaDecision("offline-control", selection="sample", seed=row["seed"], transport=reply)
        trace = run_spec(spec_for(row["clue"]), participant)
        control, = choice_reports({**trace, "binding": participant.identity(), "wire": participant.wire})
        expected = sorted(WORDS, key=probs.__getitem__, reverse=True)
        if (not control["admitted"] or control["selected_option"] != row["selected"]
                or [(c["option"], c["probability"], c["command"]) for c in control["choices"]]
                != [(word, probs[word], {"action": "choose_word", "args": {"word": word}}) for word in expected]):
            raise ValueError("provider-neutral interface control failed")


def write_csv(path, rows):
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def check(root, panel, reuse_checks=False):
    if not (root / "manifest.json").is_file():
        raise ValueError("missing study manifest")
    jobs = plan(root)
    summaries, groups, failures, trial_vectors = [], [], [], []
    for entry in panel:
        rows = verify_condition(root, entry, jobs, reuse_checks)
        if rows is None:
            folder = model_dir(root, entry["model"])
            reason = None
            def failure_order(path):
                parts = path.name.split(".")
                return (parts[0], int(parts[1]) if parts[1].isdigit() else 1)
            for path in sorted(folder.glob("*.failure.json.gz"), key=failure_order):
                record = load(path)
                trace = replay_choice_record(record)
                event = trace["decisions"][0]
                wire = record["wire"][-1] if record["wire"] else {}
                reason = wire.get("invalid_response") or event.get("error") or event["status"]
            if reason is None and (folder / "unavailable.json").exists():
                reason = load(folder / "unavailable.json")["reason"]
            failures.append({**entry, "saved": sum((folder / (job["id"] + ".json.gz")).exists() for job in jobs),
                             "reason": reason or "pending"})
            continue
        summary, group_rows = summarize(entry, rows)
        if entry["route"] == "llm":
            check_interface_control(rows)
        summary["interface_controls"] = len(rows) if entry["route"] == "llm" else 0
        summaries.append(summary)
        groups.extend(group_rows)
        for r in rows:
            trial_vectors.append({**entry, **{k: r[k] for k in ("target", "arm", "clue", "repeat", "seed", "selected",
                                                                "argmax", "target_p", "menu_mass")},
                                  **{w: r["probabilities"][w] for w in WORDS}})
        print(entry["model"], summary["accepted"], "verified", flush=True)
    return summaries, groups, failures, trial_vectors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--panel", type=Path, help="JSON array of model, developer, and route objects")
    parser.add_argument("--model", action="append", help="verify and cache a subset")
    parser.add_argument("--reuse-checks", action="store_true", help="reuse earlier local checks of identical receipt hashes")
    args = parser.parse_args()
    panel = load(args.panel or args.out / "panel.json")
    if args.model:
        panel = [e for e in panel if e["model"] in args.model]
    with patch.object(socket.socket, "connect", side_effect=AssertionError("offline verification attempted a connection")) as connect:
        summaries, groups, failures, trials = check(args.out, panel, args.reuse_checks)
        if connect.call_count:
            raise ValueError("offline check opened a connection")
    if not args.model:
        write_csv(args.out / "model-results.csv", summaries)
        write_csv(args.out / "clue-results.csv", groups)
        write_csv(args.out / "trial-vectors.csv", trials)
        save(args.out / "summary.json", {"models": summaries, "incomplete": failures, "groups": groups,
                                        "planned": 27 * len(panel), "scored": sum(r["accepted"] for r in summaries),
                                        "socket_connections": 0})
    print(len(summaries), "complete checkpoints;", len(failures), "incomplete", flush=True)


if __name__ == "__main__":
    main()

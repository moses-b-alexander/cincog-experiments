"""One sender choice paired across receiver conditions in the C4 word channel."""
from framework_lab import domain
from framework_lab.objects import Decision, Field, Form, View


DELIVERIES = {"whole": "all eight letters", "elide_first": "the last four letters",
              "elide_second": "the first four letters", "alternating": "letters at positions 1, 3, 5 and 7"}


def resolve(parameters):
    if set(parameters) - {"word_bank", "arms", "instruction"}:
        raise ValueError("unknown C4 study parameter")
    bank = parameters.get("word_bank", list(domain.WORDS))
    arms = parameters.get("arms", ["whole", "elide_first", "elide_second", "alternating"])
    if (not isinstance(bank, list) or not bank or any(not isinstance(w, str) or len(w) != 8
            or not w.isascii() or not w.isalpha() or not w.islower() for w in bank) or len(bank) != len(set(bank))):
        raise ValueError("C4 needs a unique ordered bank of eight-letter lowercase ASCII words")
    if (not isinstance(arms, list) or not arms or arms[0] != "whole" or len(arms) != len(set(arms))
            or set(arms) - DELIVERIES.keys()):
        raise ValueError("start C4 arms with whole, then select unique delivery alternates")
    instruction = parameters.get("instruction",
        "A chooses a word. C receives one of these clues: " + "; ".join(DELIVERIES[a] for a in arms)
        + ". C chooses a word from the same bank. Recovery succeeds when both choices match exactly.")
    if not isinstance(instruction, str) or not instruction.strip():
        raise ValueError("C4 instruction must be nonempty text")
    return {"word_bank": bank, "arms": arms, "instruction": instruction}


def delivery(word, arm):
    return {"whole": word, "elide_first": word[4:], "elide_second": word[:4], "alternating": word[::2]}[arm]


def decision(role, settings, clue=None):
    observation = {"role": role, "possible_deliveries": list(settings["arms"])}
    if role == "C":
        observation["fragment"] = clue
    return Decision(View(role, observation, {"metric": "exact_recovery", "direction": "maximize", "horizon": 1},
                         settings["instruction"]), (Form("choose_word", (Field("word", tuple(settings["word_bank"])),)),))


def describe(settings):
    example = settings["word_bank"][0]
    return {
        "state": {"sender_choices_per_assignment": 1, "ordered_bank": settings["word_bank"],
                  "host_only": ["target and condition identity at the receiver"]},
        "roles": {"A": {"request": decision("A", settings).request()},
                  "C": {"example_requests": {arm: decision("C", settings, delivery(example, arm)).request()
                                             for arm in settings["arms"]}}},
        "streams": {"shared": ["A"], **{arm: ["C"] for arm in settings["arms"]}},
        "interventions": {arm: {"example_target": example, "example_delivery": delivery(example, arm)}
                          for arm in settings["arms"]},
        "outcome": {"metric": "exact recovery", "unit": "one sender choice",
                    "comparison": "each alternate minus whole on jointly observed branches",
                    "missing": "Sender failure leaves every branch missing. A failed receiver contributes no score."},
    }


def run(session, settings):
    selected = session.ask("C4/A", decision("A", settings))
    word = dict(selected.arguments)["word"] if selected else None
    arms = {}
    for arm in settings["arms"]:
        clue = guess = None
        if word is not None:
            clue = delivery(word, arm)
            with session.stream(arm):
                command = session.ask(f"C4/C/{arm}", decision("C", settings, clue))
            if command:
                guess = dict(command.arguments)["word"]
        arms[arm] = {"fragment": clue, "guess": guess, "score": None if guess is None else guess == word}
    return {"word": word, "arms": arms}


def measure(result, settings):
    scores = {arm: row["score"] for arm, row in result["arms"].items()}
    whole = scores["whole"]
    metrics = {}
    for arm, score in scores.items():
        metrics[arm] = {"numerator": int(bool(score)), "observed": int(score is not None), "planned": 1}
        if arm != "whole":
            paired = whole is not None and score is not None
            metrics[arm + "_minus_whole"] = {"numerator": int(score) - int(whole) if paired else 0,
                                             "observed": int(paired), "planned": 1}
    return metrics


def respondent(seed):
    """Inspectable smoke participant, selecting a compatible word in bank order."""
    import json
    def answer(request):
        bank = request["schema"]["anyOf"][0]["properties"]["args"]["properties"]["word"]["enum"]
        clue = request["observation"].get("fragment")
        if clue is None:
            word = "firewood" if "firewood" in bank else bank[0]
        else:
            arms = request["observation"]["possible_deliveries"]
            word = next(w for w in bank if any(delivery(w, arm) == clue for arm in arms))
        return json.dumps({"action": "choose_word", "args": {"word": word}})
    return answer

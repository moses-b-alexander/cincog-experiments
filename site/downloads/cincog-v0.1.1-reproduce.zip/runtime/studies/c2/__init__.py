"""Paired C2 possessions with a fixed defense and two visible appearances."""
from framework_lab import domain
from framework_lab.objects.cases import _qb_decision, possession


def resolve(parameters):
    settings = dict(parameters)
    alternate = settings.pop("alternate_appearance", [6] + [0] * 8)
    if "defense" in settings:
        settings.setdefault("appearance", settings["defense"])
    control = domain.settings("C2", settings)
    changed = domain.settings("C2", {**control, "appearance": alternate})
    return {"control": control, "alternate": changed}


def describe(settings):
    return {
        "state": {"host": "Actual rosters reset each play. Both arms use the same keyed shocks or fixed shock tape."},
        "roles": {"QB": {"observes": ["offense", "defensive_appearance", "play", "last_three_yards"],
                         "initial_requests": {arm: _qb_decision(cfg, 1, []).request() for arm, cfg in settings.items()},
                         "calibration_requests": {arm: _qb_decision(cfg, 1, [], cfg["assigned_qb"]).request()
                                                  for arm, cfg in settings.items() if "assigned_qb" in cfg}}},
        "streams": {arm: ["QB"] for arm in settings},
        "interventions": {arm: {"visible_appearance": cfg["appearance"]} for arm, cfg in settings.items()},
        "outcome": {"metric": "fraction of overlapping four-play windows with at least ten yards",
                    "unit": "one completed possession", "comparison": "alternate minus control on jointly completed possessions",
                    "missing": "An interrupted possession has no episode score."},
    }


def run(session, settings):
    outcomes = {}
    for arm, cfg in settings.items():
        with session.stream(arm):
            outcomes[arm] = possession(session, cfg, prefix=f"C2/{arm}")
    return outcomes


def measure(result, settings):
    scores = {arm: episode["score"] for arm, episode in result.items()}
    pair = all(value is not None for value in scores.values())
    metrics = {arm: {"numerator": value or 0, "observed": int(value is not None), "planned": 1}
               for arm, value in scores.items()}
    metrics["paired_difference"] = {"numerator": scores["alternate"] - scores["control"] if pair else 0,
                                    "observed": int(pair), "planned": 1}
    return metrics

from framework_lab.study import main

if __name__ == "__main__":
    raise SystemExit(main("c2"))

"""Agent-authored repeated prisoner's dilemma with independently dispatched private moves."""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path

from framework_lab.objects import AsciiTextField, Decision, Form, Session, View
from framework_lab.providers import LocalOllama

SEATS = ("left", "right")
MODELS = ("phi4-mini:3.8b", "qwen2.5:3b")
REWARDS = {
    ("cooperate", "cooperate"): (3, 3), ("cooperate", "defect"): (0, 5),
    ("defect", "cooperate"): (5, 0), ("defect", "defect"): (1, 1),
}
SPEECH = (Form("send", (AsciiTextField("text", 16),)),)
MOVES = (Form("cooperate"), Form("defect"))
RULES = ("Each round both players privately choose cooperate or defect. Mutual cooperation "
         "pays 3 each; mutual defection pays 1 each. A lone defector gets 5 and the cooperator "
         "gets 0. Both players learn both moves and payoffs after the round. The speaker "
         "alternates each round, starting with left. Their message may be withheld. "
         "Only the recipient sees whether a message arrived. Messages are nonbinding.")


def run(providers, *, deliver, horizon=3, order=SEATS):
    if type(deliver) is not bool or type(horizon) is not int or horizon < 1:
        raise ValueError("expected a Boolean delivery condition and positive integer horizon")
    if set(providers) != set(SEATS) or tuple(order) not in (SEATS, SEATS[::-1]):
        raise ValueError("expected one provider per seat and a valid dispatch order")
    session = Session(lambda req: providers[req["role"]](req))
    histories = {seat: [] for seat in SEATS}
    rows = []
    total = dict.fromkeys(SEATS, 0)
    objective = {"metric": "own_total_points", "direction": "maximize", "horizon": horizon}
    def ask(seat, phase, instruction, forms, extra):
        observation = {"seat": seat, "round": turn, "speaker": speaker,
                       "history": deepcopy(histories[seat]), **extra}
        view = View(seat, observation, objective, RULES + " " + instruction)
        return session.ask(f"round/{turn}/{phase}/{seat}", Decision(view, forms))

    for turn in range(1, horizon + 1):
        speaker = SEATS[(turn - 1) % 2]
        msg = ask(speaker, "message", "Send zero to sixteen printable ASCII characters; "
                  "spaces count. An empty message is allowed.", SPEECH, {})
        row = {"round": turn, "speaker": speaker, "sent": None, "delivered": None,
               "actions": {}, "payoffs": None}
        rows.append(row)
        if msg is None:
            break
        sent = msg.as_dict()["args"]["text"]
        received = sent if deliver else None
        row.update(sent=sent, delivered=received)
        for seat in order:
            visible = {"sent": sent} if seat == speaker else {"received": received}
            move = ask(seat, "move", "Choose one private move to maximize your own total points.",
                       MOVES, visible)
            row["actions"][seat] = move.name if move is not None else None
        row["actions"] = {seat: row["actions"][seat] for seat in SEATS}
        if any(row["actions"][s] is None for s in SEATS):
            break
        points = dict(zip(SEATS, REWARDS[tuple(row["actions"][s] for s in SEATS)]))
        row["payoffs"] = points
        for seat in SEATS:
            total[seat] += points[seat]
            visible = {"sent": sent} if seat == speaker else {"received": received}
            histories[seat].append({"round": turn, "speaker": speaker, **visible,
                                    "actions": dict(row["actions"]), "payoffs": dict(points)})
    complete = len(rows) == horizon and rows[-1]["payoffs"] is not None
    return session.trace({"deliver": deliver, "horizon": horizon, "rounds": rows,
                          "complete": complete, "total_points": total if complete else None})


def live():
    trials = []
    for models in (MODELS, MODELS[::-1]):
        for deliver in (False, True):
            adapters = {s: LocalOllama(model, 63211) for s, model in zip(SEATS, models)}
            bindings = {s: client.identity() for s, client in adapters.items()}
            trace = run(adapters, deliver=deliver)
            trials.append({"bindings": bindings, "trace": trace,
                           "wire": {s: client.wire for s, client in adapters.items()}})
    return trials


def check(trials):
    """Replay this completed four-game pilot from each participant's saved wire receipts."""
    assignments = [(models, deliver) for models in (MODELS, MODELS[::-1])
                   for deliver in (False, True)]
    if len(trials) != len(assignments):
        raise ValueError("expected four games")
    for trial, (models, deliver) in zip(trials, assignments):
        remaining = {seat: iter(trial["wire"][seat]) for seat in SEATS}

        def replay(request):
            seat = request["role"]
            binding = trial["bindings"][seat]
            wire = next(remaining[seat])
            body = wire["body"]
            model = models[SEATS.index(seat)]
            visible = {key: value for key, value in request.items() if key != "schema"}
            envelope = json.loads(wire["response"])
            expected_messages = [
                {"role": "system", "content": "Return one JSON action matching this schema. "
                 + json.dumps(request["schema"], separators=(",", ":"))},
                {"role": "user", "content": json.dumps(visible, separators=(",", ":"))}]
            options = {"seed": binding["seed"], "temperature": binding["temperature"],
                       "num_ctx": binding["context"], "num_predict": binding["output_tokens"]}
            if (binding["model"] != model or not binding["digest"] or body["model"] != model
                    or body["options"] != options or options != {"seed": 63211, "temperature": 0,
                                                                 "num_ctx": 8192, "num_predict": 128}
                    or body["messages"] != expected_messages or body["format"] != request["schema"]
                    or wire["status"] != 200 or envelope["model"] != model or "error" in wire
                    or envelope["done"] is not True or envelope["message"]["role"] != "assistant"
                    or envelope["message"].get("tool_calls")):
                raise ValueError("receipt disagrees with experiment or model binding")
            return envelope["message"]["content"]

        rebuilt = run(dict.fromkeys(SEATS, replay), deliver=deliver)
        if (not rebuilt["result"]["complete"] or rebuilt != trial["trace"]
                or any(next(stream, None) is not None for stream in remaining.values())):
            raise ValueError("incomplete or inconsistent replay")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--check", action="store_true", help="replay the saved pilot offline")
    args = parser.parse_args()
    if args.check:
        trials = json.loads(args.output.read_text(encoding="utf8"))
        check(trials)
    else:
        if args.output.exists():
            parser.error("choose a fresh output file")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        trials = live()
        with args.output.open("x", encoding="utf8") as f:
            json.dump(trials, f, ensure_ascii=True, allow_nan=False)
    print([(t["trace"]["result"]["complete"], t["trace"]["result"]["total_points"]) for t in trials])

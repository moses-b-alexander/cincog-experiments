"""Paired C4 clue interventions on native Ollama decision models. No hosted calls."""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import random
import re
import sqlite3
import time

from framework_lab.ollama_decision import OllamaDecision, local_request
from framework_lab.domain import WORDS
from studies.distribution import decision, deliveries
from framework_lab.objects import Session


MODELS = ["kev:0.8b-q8_0", "d3:2b", "d3:4b-q8_0", "kev:4b-q8_0", "kev:9b-q4_K_M"]
ARMS = ["prefix", "suffix", "alternating"]
SEED = 20261123
PARAMS = "application/vnd.ollama.image.params"
WEIGHT_TYPES = {"application/vnd.ollama.image." + kind for kind in ("model", "projector", "adapter")}


def load_api(path, body=None):
    wire = local_request(path, body)
    if wire["status"] != 200:
        raise RuntimeError(str(wire)[:500])
    return json.loads(wire["response"])


def write(path, obj):
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, allow_nan=False), encoding="utf8")
    tmp.replace(path)


def initialize(out):
    out.mkdir(parents=True, exist_ok=True)
    draws = random.Random(SEED).choices(WORDS, k=1000)
    plan = {"version": 1, "models": MODELS, "arms": ARMS, "seed": SEED, "draws": draws,
            "word_bank": list(WORDS), "sampling": "uniform with replacement, shared across all cells",
            "selection": "one seeded categorical draw from each issued receipt",
            "receiver": decision("CLUE").request(), "arm_visible": False,
            "transport": "native local Ollama POST /v1/systemone",
            "cache_model_responses": False}
    dest = out / "manifest.json"
    if dest.exists():
        if json.loads(dest.read_text(encoding="utf8")) != plan:
            raise ValueError("saved manifest disagrees with the fixed design")
    else:
        write(dest, plan)
    return plan


def identity(model):
    tags = load_api("/api/tags")["models"]
    info = next((t for t in tags if t["name"] == model), None)
    if not info:
        raise RuntimeError(f"{model} is not installed")
    show = load_api("/api/show", {"model": model})
    return {"tag": model, "digest": info["digest"], "size_bytes": info["size"],
            "details": info["details"], "capabilities": show.get("capabilities"),
            "ollama_version": load_api("/api/version")["version"]}


def installed_manifest(tag, digest, store):
    """Collect the exact named manifest and the parameter blob it authenticates."""
    if not re.fullmatch(r"[\w.-]+:[\w.-]+", tag) or ".." in tag:
        raise ValueError("a runtime alias requires a local library model:tag")
    name, version = tag.split(":")
    raw = (store / "manifests-v2" / "ollama.com" / "library" / name / version).read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError(f"{tag}: named manifest SHA-256 differs from Ollama's reported digest")
    manifest = json.loads(raw)
    params = [layer for layer in manifest["layers"] if layer["mediaType"] == PARAMS]
    if len(params) != 1 or not re.fullmatch(r"sha256:[0-9a-f]{64}", params[0]["digest"]):
        raise ValueError(f"{tag}: expected one content-addressed parameter layer")
    layer = params[0]
    data = (store / "blobs" / layer["digest"].replace(":", "-")).read_bytes()
    if len(data) != layer["size"] or "sha256:" + hashlib.sha256(data).hexdigest() != layer["digest"]:
        raise ValueError(f"{tag}: parameter bytes disagree with their layer digest or size")
    return {"tag": tag, "digest": digest, "manifest": raw.decode(), "parameter_blob": data.decode(),
            "parameters": json.loads(data)}


def alias_binding(canonical, runtime, *, store=None):
    bound = identity(runtime)
    if runtime == canonical:
        return bound
    source = identity(canonical)
    store = store or Path(os.environ.get("OLLAMA_MODELS") or Path.home() / ".ollama" / "models")
    snapshots = [installed_manifest(info["tag"], info["digest"], store) for info in (source, bound)]
    manifests = [json.loads(snapshot["manifest"]) for snapshot in snapshots]
    def model_parts(manifest):
        # Ollama create rewrites layer origin labels. Contents, ordering and config must match.
        return {**manifest, "layers": [
            ({k: v for k, v in layer.items() if k not in ("digest", "size", "from")}
             if layer["mediaType"] == PARAMS else {k: v for k, v in layer.items() if k != "from"})
            for layer in manifest["layers"]]}
    if model_parts(manifests[0]) != model_parts(manifests[1]):
        raise ValueError("alias changed model config or a non-parameter layer")
    old, new = [s["parameters"] for s in snapshots]
    allowable = {"num_ctx", "num_batch"}
    unrelated = [{k: v for k, v in p.items() if k not in allowable} for p in (old, new)]
    if (json.dumps(unrelated[0], sort_keys=True) != json.dumps(unrelated[1], sort_keys=True)
            or type(new.get("num_ctx")) is not int or new["num_ctx"] < 1
            or any(type(new[k]) is not int or new[k] < 1 for k in allowable & new.keys())):
        raise ValueError("runtime alias may override only positive num_ctx and num_batch")
    weights = [{k: layer[k] for k in ("mediaType", "digest", "size")}
               for layer in manifests[0]["layers"] if layer["mediaType"] in WEIGHT_TYPES]
    if not any(layer["mediaType"].endswith(".model") for layer in weights):
        raise ValueError("missing model weight layer")
    return {**bound, "runtime_provenance": {"source": snapshots[0], "runtime": snapshots[1],
                                            "weight_layers": weights}}


def check_runtime_usage(wire, binding):
    if provenance := binding.get("runtime_provenance"):
        usage = json.loads(wire["response"]).get("usage", {})
        limit = provenance["runtime"]["parameters"]["num_ctx"]
        tokens = usage.get("input_tokens")
        if type(tokens) is not int or not 0 < tokens < limit or usage.get("output_tokens") != 0:
            raise ValueError(f"native decision does not show an input within the {limit}-token window")


def gpu_residency(model):
    row = next((r for r in load_api("/api/ps")["models"] if r["name"] == model or r["model"] == model), None)
    if row is None or not row["size"] or row["size_vram"] < 0.99 * row["size"]:
        raise RuntimeError(f"GPU residency failed for {model}: {row}")
    return {k: row[k] for k in ("name", "digest", "size", "size_vram", "context_length") if k in row}


def issue(model, clue, seed, key):
    participant = OllamaDecision(model, selection="sample", seed=seed)
    session = Session(participant)
    chosen = session.ask(key, decision(clue))
    wires = participant.wire
    if chosen is None:
        raise RuntimeError(str([{"status": w.get("status"), "invalid": w.get("invalid_response"),
                                "response": w.get("response", "")[:650],
                                "transport_error": w.get("transport_error")} for w in wires]))
    return chosen.as_dict()["args"]["word"], wires


def trial_schedule(draws):
    jobs = [(i, arm, target) for i, target in enumerate(draws, 1) for arm in ARMS]
    random.Random(SEED + 1).shuffle(jobs)
    return jobs


def run(out, index, runtime_tag=None):
    plan = initialize(out)
    model = plan["models"][index]
    runtime = runtime_tag or model
    binding = alias_binding(model, runtime)
    if runtime != model:
        probe = json.loads((out / f"probe-{index}.json").read_bytes())
        if probe["binding"] != binding or probe["gpu"]["digest"] != binding["digest"]:
            raise RuntimeError("alias requires a matching pre-run probe")
    db = sqlite3.connect(out / f"receipts-{index}.sqlite")
    db.execute("create table if not exists trials (trial integer, arm text, row text, wire text, primary key(trial,arm))")
    db.execute("create table if not exists settings (binding text)")
    saved = db.execute("select binding from settings").fetchone()
    if saved and json.loads(saved[0]) != binding:
        raise RuntimeError("model binding changed since previous run")
    if not saved:
        db.execute("insert into settings values (?)", (json.dumps(binding),))
        db.commit()
    present = set(db.execute("select trial,arm from trials"))
    start = time.monotonic()
    counts = len(present)
    resident = None
    for trial, arm, target in trial_schedule(plan["draws"]):
        if (trial, arm) in present:
            continue
        clue = deliveries(target)[arm]
        seed = SEED + index * 10000 + trial * 3 + ARMS.index(arm)
        word, wires = issue(runtime, clue, seed, f"{index}/{trial}/{arm}")
        check_runtime_usage(wires[-1], binding)
        if resident is None or counts % 100 == 0 or counts + 1 == len(plan["draws"]) * len(ARMS):
            resident = gpu_residency(runtime)
            if resident["digest"] != binding["digest"]:
                raise RuntimeError("loaded model digest mismatch")
            if runtime != model and resident["context_length"] != binding["runtime_provenance"]["runtime"]["parameters"]["num_ctx"]:
                raise RuntimeError("loaded alias context differs from its declared parameter")
        w = wires[-1]
        row = {"trial": trial, "arm": arm, "target": target, "clue": clue, "selected": word,
               "selection_seed": seed, "reported_choice": w["reported_choice"], "confidence": w["confidence"],
               "probabilities": w["probabilities"], "attempts": len(wires)}
        db.execute("insert into trials values (?,?,?,?)",
                   (trial, arm, json.dumps(row), json.dumps(wires, ensure_ascii=True)))
        db.commit()
        counts += 1
        if counts == len(present) + 1 or counts % 100 == 0:
            write(out / f"progress-{index}.json", {"model": model, "complete": counts, "gpu": resident,
                                                  "elapsed_seconds": time.monotonic()-start})
            print(model, counts, "of 3000", flush=True)
    path = out / "decisions"
    path.mkdir(exist_ok=True)
    tmp = path / f"{index}.tmp"
    with tmp.open("w", encoding="utf8") as stream:
        for (data,) in db.execute("select row from trials order by trial,arm"):
            stream.write(data + "\n")
    tmp.replace(path / f"{index}.jsonl")
    write(out / f"binding-{index}.json", binding)
    db.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["plan", "probe", "run"])
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--index", type=int, choices=range(len(MODELS)), default=0)
    parser.add_argument("--runtime-tag", help="use a local parameter-only alias for this model")
    args = parser.parse_args()
    if args.runtime_tag is not None and (args.mode == "plan" or not args.runtime_tag.strip()):
        parser.error("--runtime-tag requires a nonempty tag in probe or run mode")
    manifest = initialize(args.output)
    if args.mode == "plan":
        print(json.dumps({"models": MODELS, "target_counts": Counter(manifest["draws"]),
                          "manifest_sha256": hashlib.sha256((args.output/"manifest.json").read_bytes()).hexdigest()}))
    elif args.mode == "probe":
        model = MODELS[args.index]
        runtime = args.runtime_tag or model
        binding = alias_binding(model, runtime)
        probe_path = args.output / f"probe-{args.index}.json"
        if probe_path.exists() and json.loads(probe_path.read_bytes())["binding"] != binding:
            raise RuntimeError("existing probe has a different model binding")
        t = time.monotonic()
        word, wires = issue(runtime, "fire", SEED, "probe")
        elapsed = time.monotonic() - t
        check_runtime_usage(wires[-1], binding)
        gpu = gpu_residency(runtime)
        if gpu["digest"] != binding["digest"] or (runtime != model and
                gpu["context_length"] != binding["runtime_provenance"]["runtime"]["parameters"]["num_ctx"]):
            raise RuntimeError("loaded probe model does not match its binding")
        write(probe_path, {"binding": binding, "gpu": gpu, "wire": wires,
                                                         "selected": word, "elapsed": elapsed})
        print(model, word, len(wires[-1]["probabilities"]), gpu, elapsed)
    else:
        run(args.output, args.index, args.runtime_tag)

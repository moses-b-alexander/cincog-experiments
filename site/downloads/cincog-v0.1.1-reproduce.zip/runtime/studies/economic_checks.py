"""Author-side measurements. Run via python -m studies.economic_checks from the lab."""
import json
from dataclasses import replace
from importlib import import_module
from statistics import mean

from framework_lab.__main__ import CANDIDATES
from framework_lab.recipes import Recipe
from framework_lab.recipes.cases import BOARD_OPS, BOARD_STEPS
from framework_lab.domain import C2_RULES, settings

MOVE = {"action": "move_person", "args": {"from_cell": 8, "to_cell": 0}}
HOLD = {"action": "do_nothing", "args": {}}


def totals(trace, unit_cost=0):
    gains = [p["yards"] for p in trace["result"]["plays"]]
    if trace["result"]["score"] is None:
        return None
    moves = sum(d["action"]["action"] == "move_person" for d in trace["decisions"]
                if d["id"].startswith("C2/free/"))
    return sum(gains) - moves * unit_cost


def attrition(run):
    controls, complete, differences, short_success = [], [], [], []
    for seed in range(12):
        config = {"seed": seed}
        def intervention(request):
            view = request["observation"]
            if view["play"] == 2 and view["last_three_yards"][0] < 5:
                return "{}"
            return json.dumps(HOLD)
        a, b = run("C2", lambda _: json.dumps(HOLD), config), run("C2", intervention, config)
        controls.append(totals(a))
        short_success.append(sum(p["yards"] for p in a["result"]["plays"][:2]) >= 10)
        for x, y in zip(a["result"]["plays"], b["result"]["plays"]):
            assert x["shock"] == y["shock"]
        if totals(b) is not None:
            complete.append(totals(b))
            differences.append(totals(b) - totals(a))
    assert len(complete) == 10 and differences == [0] * 10
    return {"assigned_pairs": len(controls), "complete_pairs": len(complete),
            "unmatched_mean_difference": mean(complete) - mean(controls),
            "complete_pair_mean_difference": mean(differences),
            "first_two_play_successes": sum(short_success)}


def price_trial(price):
    # Domain question implementation and workflow data are explicitly selected by this author.
    original = BOARD_OPS["question"]
    def question(*args):
        q = original(*args)
        return replace(q, objective={"metric": "net_yards", "direction": "maximize",
                                     "horizon": 4, "move_charge": price},
                       instruction=C2_RULES + " Maximize net yards. Each move costs " + str(price)
                                   + " yard-equivalents; holds are free.")
    def responsive(q):
        return json.dumps(MOVE if q["objective"]["move_charge"] == 0 else HOLD)
    engine = Recipe(BOARD_STEPS, {**BOARD_OPS, "question": question})
    return engine.run(settings("C2", {"shocks": [0]*4}), responsive)


if __name__ == "__main__":
    for candidate in CANDIDATES:
        run = import_module("framework_lab." + candidate).run
        trace = run("C2", lambda _: json.dumps(MOVE), {"shocks": [0]*4})
        assert [p["yards"] for p in trace["result"]["plays"]] == [7.5]*4
        assert (totals(trace), totals(trace, 2)) == (30, 22)
        print(candidate, attrition(run))
    original, announced = price_trial(0), price_trial(3)
    print("Gross, archived net at price 3, fresh net at announced price 3:",
          totals(original), totals(original, 3), totals(announced, 3))
    assert (totals(original), totals(original, 3), totals(announced, 3)) == (30, 18, 22)

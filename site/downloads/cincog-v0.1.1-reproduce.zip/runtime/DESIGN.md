# Three ways to author a coordinated task

## Decision to make

Choose an API that lets an experiment author run an original workflow in an installed package, specify what each participant sees and can do, and inspect its scientific record. The comparison uses three independent implementations. None imports the existing Cincog engine or either of its siblings. The shared domain module supplies the reference word catalog, football physics, and validation of the two baseline fixtures. The CLI and comparison tests are clients of the packages.

## Common obligations

* C4 has one sender choice per trial. Three independent receiver decisions get the full eight-letter word, the last four letters, or the first four letters. Each receiver sees its own fragment, the common bank and public rules. Its score is exact recovery. Arm order may change. A receiver's failure leaves its siblings runnable. A missing sender leaves all dependent outcomes missing.
* C2 recommits five offensive and six defensive personnel on a nine-cell board every play. The model observes the offense, the defensive appearance, the play number and the last three public yardages. It may move one person from an occupied cell to another cell or explicitly hold. The private defense and realized shock determine physical yardage. Four to ten plays are allowed. Score the fraction of overlapping four-play windows totaling at least ten yards. An incomplete episode has a missing score. Optional assigned-action calibrations in either case are independent of free decisions.
* A provider receives an exact public request with role, observation, objective, instructions and current legal-action schema. It returns raw JSON with exactly one action and argument object. Strict admission, one retry on an invalid reply, terminal service failure, and recording of each attempt are required. A legal undesired choice counts. There is no physical action on a failed decision.
* A user can supply a different workflow outside the package. Decision IDs and private conditions belong in the audit record. Agent feedback, recorded world facts, measurements and participant objectives have distinct meanings. Mathematical yardage equality uses a small floating-point tolerance. A historical semantic replay checks decisions and outcomes using published raw response contents and standard-normal shocks. It does not reproduce prompt bytes or sample new model replies.

## Candidate A — Scripted

An author writes a Python function that explicitly calls a recorder with a public projection and a finite list of complete legal commands. The recorder handles provider calls, admission, retry and evidence. The script owns scheduling, action effects and scoring. Inspect [the public API](framework_lab/scripted/AUTHOR.md) and [the case scripts](framework_lab/scripted/cases.py).

## Candidate B — Objects

An author writes a Python workflow that constructs views and action forms, then asks a session to issue a typed decision. A form describes arguments and the host rechecks them. The author supplies domain effects and scoring through Python. Inspect [the public API](framework_lab/objects/AUTHOR.md) and [the case workflows](framework_lab/objects/cases.py).

## Candidate C — Recipes

An author binds names to ordinary domain operations and writes the control flow in a JSON recipe. A compiler checks operation references and the shape and scope of the steps before the interpreter runs them. The recipe owns order, optional branches and collections. The registered operations own domain knowledge, projections and effects. Inspect [the public API](framework_lab/recipes/AUTHOR.md) and [the baseline operations](framework_lab/recipes/cases.py).

## Questions for a reader

Where can a researcher inspect the transmitted data, legal menu, physical result and measurement independently? Can they distinguish an absent response from an explicit hold or a wrong but valid guess? Can they change a measurement over a saved trace without rerunning the policy? Does an advertised schema reveal private state? Which errors does the framework catch before execution, at admission, at application, or only in a fixture test? What changes for a genuinely new workflow?

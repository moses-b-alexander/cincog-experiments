"""Replay the complete public requests, raw replies and outcomes of the local smoke trials."""
import argparse
from collections import Counter
from importlib import import_module
import json
from pathlib import Path
from zipfile import ZipFile
from framework_lab.__main__ import replay_choice_record


def require(condition, description):
    if not condition:
        raise ValueError(f"live replay mismatch: {description}")


def verify(record):
    if record["binding"]["provider"] in ("local_ollama_systemone", "local_llama_next_token"):
        trace = replay_choice_record(record)
        return Counter(row["status"] for row in trace["decisions"])
    require(record["binding"]["provider"] == "local_ollama", "unsupported provider binding")
    # LocalOllama sends this exact schema in both Ollama format and the system message.
    calls = iter(zip(record["wire"],
                     (a for d in record["decisions"] for a in d["attempts"]), strict=True))
    def provider(request):
        wire, attempt = next(calls)
        body = wire["body"]
        require(request == attempt["request"], "public request")
        require(body["format"] == request["schema"], "Ollama format")
        require(json.loads(body["messages"][1]["content"]) == {
            k: v for k, v in request.items() if k != "schema"}, "visible user message")
        require(body["messages"][0]["content"] == ("Return one JSON action matching this schema. "
                + json.dumps(request["schema"], separators=(",", ":"))), "system message")
        require(body["model"] == record["binding"]["model"], "model")
        binding = record["binding"]
        require(body["options"] == {"seed": binding["seed"], "temperature": binding["temperature"],
                "num_ctx": binding["context"], "num_predict": binding["output_tokens"]}, "options")
        require(wire["status"] == 200, "HTTP status")
        envelope = json.loads(wire["response"])
        require(envelope["done"] is True and envelope["model"] == body["model"], "model receipt")
        require(envelope["message"]["content"] == attempt["raw"], "reply")
        return attempt["raw"]
    trace = import_module("framework_lab." + record["candidate"]).run(
        record["case"], provider, record["settings"])
    require(next(calls, None) is None, "unused calls")
    for key in trace:
        # Canonical JSON also distinguishes 1 from true, unlike Python container equality.
        require(json.dumps(trace[key], sort_keys=True) == json.dumps(record[key], sort_keys=True), key)
    return Counter(r["status"] for r in trace["decisions"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    counts = Counter()
    path = parser.parse_args().archive
    if path.suffix.lower() == ".json":
        counts.update(verify(json.loads(path.read_text(encoding="utf-8"))))
    else:
        with ZipFile(path) as bundle:
            for name in bundle.namelist():
                record = json.loads(bundle.read(name))
                counts.update(verify(record))
                print(name, "OK")
    print(dict(counts))

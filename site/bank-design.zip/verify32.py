"""Verify the 32-target disclosure bank and its two lexicon-wide upper bounds.

Run python verify32.py from an extracted bank-design.zip. Only the Python
standard library is needed. Targets and the three deletion rules have
independent uniform priors. Equally probable MAP actions share credit.
"""
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
LABELS = ("delete_first", "delete_middle", "delete_last")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(name):
    return json.loads((HERE / name).read_bytes())


def clues(word):
    pairs = (word[:2], word[2:4], word[4:])
    return tuple("".join(pairs[:i] + pairs[i+1:]) for i in range(3))


def check_number(actual, expected, field):
    require(math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12), field)


def verify_bank(bank, pool, anchors):
    words = bank["words"]
    require(len(words) == len(set(words)) == 32, "Expected 32 distinct targets")
    require(set(anchors) <= set(words) <= pool, "Inconsistent bank membership")
    require(tuple(bank["rules"]) == LABELS, "Unexpected deletion rules")
    cells = defaultdict(lambda: [[], [], []])
    for word in words:
        for r, clue in enumerate(clues(word)):
            cells[clue][r].append(word)
    records = {(row["word"], row["rule"]): row for row in bank["atoms"]}
    require(len(records) == len(bank["atoms"]) == bank["assignments"] == 96,
            "Expected exactly one record per word and rule")
    hidden_correct, shown_correct = [Fraction(0)] * 3, [Fraction(0)] * 3
    changed, total_bits = [0] * 3, [0.] * 3
    changed_by_word = Counter()
    genuine_clues = [set(), set(), set()]
    cross_slots = [0, 0, 0]
    cross_sources = {}
    hidden_target_entropy = shown_target_entropy = hidden_rule_entropy = shown_rule_entropy = 0.
    for clue, groups in sorted(cells.items()):
        frequencies = Counter(word for group in groups for word in group)
        mass = sum(frequencies.values())
        max_count = max(frequencies.values())
        leaders = {word for word, count in frequencies.items() if count == max_count}
        sources = [(word, LABELS[r]) for r, group in enumerate(groups) for word in group]
        if any(word != other and label != other_label for word, label in sources
               for other, other_label in sources):
            cross_sources[clue] = sorted(sources)
        for r, group in enumerate(groups):
            if not group:
                continue
            posterior_changes = any(Fraction(count, mass) != Fraction(int(word in group), len(group))
                                    for word, count in frequencies.items())
            changed[r] += len(group) * posterior_changes
            if posterior_changes:
                genuine_clues[r].add(clue)
                changed_by_word.update(group)
            for word in group:
                cross_slots[r] += any(other != word and label != LABELS[r] for other, label in sources)
                row = records[word, LABELS[r]]
                require(row["clue"] == clue, f"Clue mismatch for {word} / {LABELS[r]}")
                require(sorted(row["hidden_source_words"]) == sorted(frequencies), "Hidden candidates")
                require(sorted(row["shown_source_words"]) == sorted(group), "Disclosed candidates")
                hidden_target = Fraction(frequencies[word], mass)
                shown_target = Fraction(1, len(group))
                gain = math.log2(shown_target / hidden_target)
                hidden_map = Fraction(int(word in leaders), len(leaders))
                check_number(row["hidden_p_target"], hidden_target, "Hidden posterior")
                check_number(row["shown_p_target"], shown_target, "Shown posterior")
                check_number(row["log2_target_gain"], gain, "Target log gain")
                check_number(row["hidden_expected_top_one"], hidden_map, "Hidden MAP tie credit")
                check_number(row["shown_expected_top_one"], shown_target, "Shown MAP tie credit")
                total_bits[r] += gain
                hidden_correct[r] += hidden_map
                shown_correct[r] += shown_target
                hidden_target_entropy -= math.log2(hidden_target)
                shown_target_entropy -= math.log2(shown_target)
                hidden_rule_entropy += math.log2(mass / len(group))
                shown_rule_entropy += math.log2(frequencies[word])
    n = len(words)
    for r, label in enumerate(LABELS):
        report = bank["per_rule"][label]
        check_number(report["expected_KL_bits"], total_bits[r]/n, f"{label} gain")
        check_number(report["hidden_top_one"], hidden_correct[r]/n, f"{label} hidden MAP")
        check_number(report["shown_top_one"], shown_correct[r]/n, f"{label} shown MAP")
        check_number(report["top_one_gain"], (shown_correct[r]-hidden_correct[r])/n, f"{label} MAP gain")
        require(report["cross_rule_other_word_assignments"] == cross_slots[r], f"{label} cross-rule slots")
        require(set(report["genuine_clues"]) == genuine_clues[r], f"{label} altered posteriors")
        require(report["posterior_changed_assignments"] == changed[r], f"{label} changed assignments")
    pooled = sum(total_bits) / (3*n)
    worst = min(total_bits) / n
    check_number(bank["disclosure_bits"], pooled, "Pooled gain")
    check_number(bank["worst_rule_bits"], worst, "Minimum gain")
    check_number(bank["shown_top_one"], sum(shown_correct)/(3*n), "Pooled shown MAP")
    check_number(bank["hidden_top_one"], sum(hidden_correct)/(3*n), "Pooled hidden MAP")
    check_number(bank["top_one_gain"], (sum(shown_correct)-sum(hidden_correct))/(3*n), "Pooled MAP gain")
    check_number(bank["hidden_correct_equivalent"], sum(hidden_correct), "Hidden correct-equivalent count")
    check_number(bank["shown_correct_equivalent"], sum(shown_correct), "Shown correct-equivalent count")
    check_number(bank["H_target_given_clue"], hidden_target_entropy/(3*n), "Hidden target entropy")
    check_number(bank["H_target_given_clue_rule"], shown_target_entropy/(3*n), "Shown target entropy")
    check_number(bank["H_rule_given_clue"], hidden_rule_entropy/(3*n), "Rule entropy given clue")
    check_number(bank["H_rule_given_clue_word"], shown_rule_entropy/(3*n), "Rule entropy given clue and word")
    require(len(cross_sources) == bank["cross_rule_clues"], "Cross-rule clue count")
    require(sum(map(len, cross_sources.values())) == bank["cross_rule_assignments"], "Cross-rule slots")
    require(len({w for rows in cross_sources.values() for w,_ in rows}) == bank["cross_rule_words"],
            "Cross-rule target count")
    require(cross_sources == {y: sorted(map(tuple, rows)) for y,rows in bank["cross_rule_sources"].items()},
            "Cross-rule source groups")
    stratified = Counter(changed_by_word[w] for w in words)
    require({str(n):stratified[n] for n in range(4)} == bank["targets_by_number_of_rules_changing_posterior"],
            "Targets grouped by number of affected rules")
    require(len(cells) == bank["unique_clues"] == 51, "Distinct clues")
    require(sum(hidden_correct) == 51 and sum(shown_correct) == 84, "Expected MAP counts")
    print(f"32 words, 96 assignments, 51 clues. Hidden MAP 51/96, disclosed MAP 84/96.")
    print(f"Deletion gains {', '.join(f'{v/n:.9f}' for v in total_bits)} bits.")
    print(f"Minimum {worst:.9f}, pooled {pooled:.9f} bits. Changed assignments {changed}.")


def verify_cap(cert, raw, words, required_anchors, claimed):
    # For clue y, q(.|y) is an arbitrary fitted probability distribution.
    # Conditional entropy H(R|Y) is at most average -log2 q(R|Y).
    # H(R|W,Y) is exactly average log2 d(W,Y), where d counts rules
    # producing the same clue on one target. Their difference is I(W;R|Y).
    require(hashlib.sha256(raw).hexdigest() == cert["lexicon_sha256"], "Lexicon SHA-256")
    require(len(words) == len(set(words)) == cert["word_count"] == 8255, "Frozen lexicon size")
    require(all(w.isascii() and w.isalpha() and w.islower() and len(w) == 6 for w in words),
            "Lexicon format")
    require(cert["bank_size"] == 32 and set(cert["anchors"]) == required_anchors, "Certificate scope")
    require(required_anchors <= set(words), "Unknown anchor")
    cap = Fraction(cert["certified_bound_bits"])
    require(cap == claimed, "Published cap")
    denominator = cert["denominator"]
    require(type(denominator) is int and denominator > 0, "Certificate denominator")
    support = defaultdict(set)
    for word in words:
        for r, clue in enumerate(clues(word)):
            support[clue].add(r)
    q = cert["multirule_clue_numerators"]
    require(set(q) == {y for y, rules in support.items() if len(rules) > 1}, "Multirule support")
    for y, row in q.items():
        require(len(row) == 3 and all(type(k) is int and k >= 0 for k in row)
                and sum(row) == denominator and {r for r,k in enumerate(row) if k} == support[y],
                f"Invalid distribution at {y}")
    product = {}
    for w in words:
        outputs = clues(w)
        product[w] = math.prod((q[y][r] if y in q else denominator) * outputs.count(y)
                               for r, y in enumerate(outputs))
    # Minimizing the product maximizes the cross-entropy bound over all banks.
    extras = sorted(product[w] for w in product.keys() - required_anchors)
    smallest = math.prod(product[w] for w in required_anchors) * math.prod(extras[:32-len(required_anchors)])
    scaled = 96 * cap
    require(denominator ** (96 * scaled.denominator)
            <= (1 << scaled.numerator) * smallest ** scaled.denominator, "Exact integer inequality")
    print(f"Proved pooled and minimum gain <= {float(cap):.4f} bits for 32-word banks "
          f"with {len(required_anchors)} required targets from the frozen pool.")


def main():
    raw = (HERE / "lexicon.txt").read_bytes()
    words = raw.decode("utf8").split()
    anchors = set(read("six-bank.json")["bank"]["words"])
    require(len(anchors) == 16, "Expected 16 original targets")
    verify_bank(read("six-bank-32.json")["bank"], set(words), anchors)
    verify_cap(read("32-upper-anchored.json"), raw, words, anchors, Fraction(9479, 10000))
    verify_cap(read("32-upper-free.json"), raw, words, set(), Fraction(609, 625))


if __name__ == "__main__":
    main()
